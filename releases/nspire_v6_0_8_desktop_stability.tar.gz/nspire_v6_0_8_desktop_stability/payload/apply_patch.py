#!/usr/bin/env python3
"""Apply and verify the NSPIRE V6.0.8 desktop visibility patch safely."""

from __future__ import annotations

import argparse
import os
import re
import stat
import tempfile
from pathlib import Path

VERSION = "6.0.8"
CACHE_KEY = "608"
START = "/* NSPIRE V6.0.8 DESKTOP VISIBILITY START */"
END = "/* NSPIRE V6.0.8 DESKTOP VISIBILITY END */"
LEGACY = "/* NSPIRE desktop emergency recovery */"

CANONICAL_BLOCK = f"""{START}
#homeView.is-active {{
  display: block !important;
  visibility: visible !important;
  opacity: 1 !important;
  min-height: calc(100vh - var(--bar-height, 54px)) !important;
}}

#homeView.is-active .home-heading {{
  display: flex !important;
  visibility: visible !important;
  opacity: 1 !important;
}}

#homeView.is-active .app-grid {{
  display: grid !important;
  visibility: visible !important;
  opacity: 1 !important;
}}

#homeView.is-active .app-tile {{
  display: flex !important;
  visibility: visible !important;
  opacity: 1 !important;
}}

.view:not(.is-active) {{
  display: none !important;
}}
{END}
"""

VERSION_RE = re.compile(r'(?m)^(\s*__version__\s*=\s*)["\'][^"\']+["\'](\s*)$')
MANAGED_RE = re.compile(re.escape(START) + r".*?" + re.escape(END) + r"\s*", re.S)
CSS_HREF_RE = re.compile(r'(?P<prefix>href=["\']/app\.css)(?:\?v=[^"\']*)?(?P<suffix>["\'])')


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def atomic_write(path: Path, text: str) -> None:
    st = path.stat()
    fd, tmp_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as handle:
            handle.write(text)
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(tmp_name, stat.S_IMODE(st.st_mode))
        try:
            os.chown(tmp_name, st.st_uid, st.st_gid)
        except PermissionError:
            pass
        os.replace(tmp_name, path)
        dir_fd = os.open(path.parent, os.O_DIRECTORY)
        try:
            os.fsync(dir_fd)
        finally:
            os.close(dir_fd)
    finally:
        if os.path.exists(tmp_name):
            os.unlink(tmp_name)


def validate_source(init_text: str, css_text: str, index_text: str, js_text: str) -> None:
    if len(VERSION_RE.findall(init_text)) != 1:
        raise ValueError("runtime-tiedostossa ei ole yksikäsitteistä __version__-riviä")
    required_css = (".view", "display: none", ".view-home", ".app-grid", ".app-tile")
    for marker in required_css:
        if marker not in css_text:
            raise ValueError(f"CSS-rakenne ei vastaa odotettua: {marker} puuttuu")
    required_index = ('id="homeView"', "view-home", "is-active", 'class="app-grid"', 'class="app-tile"')
    for marker in required_index:
        if marker not in index_text:
            raise ValueError(f"etusivun rakenne ei vastaa odotettua: {marker} puuttuu")
    if index_text.count('class="app-tile"') < 8:
        raise ValueError("etusivulla on odotettua vähemmän sovelluslaattoja")
    for marker in ("showHome", "homeView", "app-tile"):
        if marker not in js_text:
            raise ValueError(f"app.js-rakenne ei vastaa odotettua: {marker} puuttuu")


def strip_old_blocks(css_text: str) -> str:
    css_text = MANAGED_RE.sub("", css_text)
    if LEGACY in css_text:
        if css_text.count(LEGACY) != 1:
            raise ValueError("vanha hätäkorjaus esiintyy CSS:ssä useammin kuin kerran")
        pos = css_text.index(LEGACY)
        tail = css_text[pos:]
        if pos < max(0, len(css_text) - 3000):
            raise ValueError("vanha hätäkorjaus ei sijaitse turvallisesti CSS-tiedoston lopussa")
        expected = (
            "#homeView.is-active",
            "#homeView.is-active .home-heading",
            "#homeView.is-active .app-grid",
            "#homeView.is-active .app-tile",
            ".view:not(.is-active)",
        )
        if any(marker not in tail for marker in expected):
            raise ValueError("vanhan hätäkorjauksen sisältö ei vastaa tunnettua rakennetta")
        if tail.count("{") != 5 or tail.count("}") != 5:
            raise ValueError("vanhan hätäkorjauksen lohkorakenne ei ole yksikäsitteinen")
        css_text = css_text[:pos]
    return css_text.rstrip() + "\n\n"


def build_patched(init_text: str, css_text: str, index_text: str) -> tuple[str, str, str]:
    patched_init, count = VERSION_RE.subn(rf'\1"{VERSION}"\2', init_text, count=1)
    if count != 1:
        raise ValueError("runtime-version päivitys epäonnistui")

    patched_css = strip_old_blocks(css_text) + CANONICAL_BLOCK

    patched_index, count = CSS_HREF_RE.subn(
        lambda m: f"{m.group('prefix')}?v={CACHE_KEY}{m.group('suffix')}", index_text, count=1
    )
    if count != 1:
        raise ValueError("app.css-linkkiä ei löytynyt yksikäsitteisesti index.html-tiedostosta")
    if CSS_HREF_RE.search(patched_index) is None:
        raise ValueError("app.css-linkin tarkistus epäonnistui")
    return patched_init, patched_css, patched_index


def verify_final(init_text: str, css_text: str, index_text: str, js_text: str) -> None:
    validate_source(init_text, css_text, index_text, js_text)
    match = VERSION_RE.search(init_text)
    if not match or VERSION not in match.group(0):
        raise ValueError("runtime-versiona ei ole V6.0.8")
    if css_text.count(START) != 1 or css_text.count(END) != 1:
        raise ValueError("hallittu CSS-korjauslohko ei esiinny täsmälleen kerran")
    if LEGACY in css_text:
        raise ValueError("vanha hätäkorjaus jäi CSS-tiedostoon")
    for marker in (
        "#homeView.is-active",
        "#homeView.is-active .home-heading",
        "#homeView.is-active .app-grid",
        "#homeView.is-active .app-tile",
        ".view:not(.is-active)",
    ):
        if marker not in css_text:
            raise ValueError(f"korjauslohko on puutteellinen: {marker}")
    if f'/app.css?v={CACHE_KEY}' not in index_text:
        raise ValueError("index.html ei käytä V6.0.8 CSS-välimuistiavainta")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=("apply", "verify"))
    parser.add_argument("--init", required=True, type=Path)
    parser.add_argument("--css", required=True, type=Path)
    parser.add_argument("--index", required=True, type=Path)
    parser.add_argument("--js", required=True, type=Path)
    args = parser.parse_args()

    for path in (args.init, args.css, args.index, args.js):
        if not path.is_file():
            raise SystemExit(f"tiedosto puuttuu: {path}")

    init_text = read_text(args.init)
    css_text = read_text(args.css)
    index_text = read_text(args.index)
    js_text = read_text(args.js)

    if args.mode == "apply":
        validate_source(init_text, css_text, index_text, js_text)
        patched_init, patched_css, patched_index = build_patched(init_text, css_text, index_text)
        # Validate all generated content before replacing the first live file.
        verify_final(patched_init, patched_css, patched_index, js_text)
        atomic_write(args.init, patched_init)
        atomic_write(args.css, patched_css)
        atomic_write(args.index, patched_index)
        init_text, css_text, index_text = patched_init, patched_css, patched_index

    verify_final(init_text, css_text, index_text, js_text)
    print("V6.0.8 frontend patch OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
