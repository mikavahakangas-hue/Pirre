# NSPIRE V6.0.8 – työpöydän vakautus

Tämä päivitys tekee toimivaksi todetun työpöydän näkyvyyskorjauksen pysyväksi. Päivitys muuttaa vain runtime-version, `static/app.css`-tiedoston hallitun korjauslohkon sekä CSS-tiedoston välimuistiversion `static/index.html`-tiedostossa.

Päivitys ei poista Cog/WPE WebKitin käyttäjätilaa, ei koske näyttörotaatioon, kosketukseen, VNC:hen, verkkoon tai sovellusten sisältöön. Ennen muutoksia kaikki muokattavat tiedostot varmuuskopioidaan ja palautetaan automaattisesti, jos backendin, etusivun, CSS:n tai kioskin tarkistus epäonnistuu.
