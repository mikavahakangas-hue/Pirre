#!/usr/bin/env bash
set -Eeuo pipefail
umask 022
export PYTHONDONTWRITEBYTECODE=1

PKG_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
VERSION="6.0.8"
LIVE="${NSPIRE_LIVE:-/opt/nspire-v6}"
STATIC="$LIVE/static"
INIT="$LIVE/nspire/__init__.py"
CSS="$STATIC/app.css"
INDEX="$STATIC/index.html"
APPJS="$STATIC/app.js"
BACKUP_ROOT="${NSPIRE_BACKUP_ROOT:-/root/nspire-backup}"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="$BACKUP_ROOT/v6_0_8_desktop_before_${STAMP}"
LOG="${NSPIRE_LOG:-/var/log/nspire-v6-update.log}"
SYSTEMCTL="${SYSTEMCTL:-systemctl}"
CURL="${CURL:-curl}"
SLEEP="${SLEEP:-sleep}"
SUCCESS=0
BACKEND_WAS_ACTIVE=0
KIOSK_WAS_ACTIVE=0
CURRENT_VERSION="tuntematon"
PHASE="alustus"
ROOT_TMP=""
CSS_TMP=""

say(){ printf '%s [%s] %s\n' "$(date -Is)" "$PHASE" "$*" | tee -a "$LOG"; }
fail(){ say "VIRHE: $*"; return 1; }

[[ ${EUID:-$(id -u)} -eq 0 ]] || { echo "Aja asennin root-oikeuksilla." >&2; exit 1; }
for cmd in python3 sha256sum cp mkdir rm mv awk grep tee "$SYSTEMCTL" "$CURL" "$SLEEP"; do
  command -v "$cmd" >/dev/null 2>&1 || { echo "Komento puuttuu: $cmd" >&2; exit 1; }
done
for file in "$INIT" "$CSS" "$INDEX" "$APPJS"; do
  [[ -f "$file" ]] || { echo "Tiedosto puuttuu: $file" >&2; exit 1; }
done
mkdir -p "$(dirname "$LOG")" "$BACKUP_ROOT"

cd "$PKG_DIR"
PHASE="paketin tarkistus"
sha256sum -c SHA256SUMS
bash -n install.sh
python3 -m py_compile payload/apply_patch.py

CURRENT_VERSION="$(python3 - "$INIT" <<'PY'
from pathlib import Path
import re, sys
text=Path(sys.argv[1]).read_text(encoding='utf-8')
m=re.search(r'(?m)^\s*__version__\s*=\s*["\']([^"\']+)["\']', text)
print(m.group(1) if m else '')
PY
)"
case "$CURRENT_VERSION" in
  6.0.4|6.0.5|6.0.6|6.0.7|6.0.8) ;;
  *) fail "Päivitys vaatii V6.0.4–V6.0.8:n. Nykyinen: ${CURRENT_VERSION:-tuntematon}" ;;
esac

"$SYSTEMCTL" is-active --quiet nspire-v6.service && BACKEND_WAS_ACTIVE=1 || true
"$SYSTEMCTL" is-active --quiet nspire-kiosk.service && KIOSK_WAS_ACTIVE=1 || true
mkdir -p "$BACKUP"
cp -a "$INIT" "$BACKUP/__init__.py"
cp -a "$CSS" "$BACKUP/app.css"
cp -a "$INDEX" "$BACKUP/index.html"
cp -a "$APPJS" "$BACKUP/app.js"
sha256sum "$INIT" "$CSS" "$INDEX" "$APPJS" > "$BACKUP/before.sha256"

stop_unit(){
  local unit="$1"
  "$SYSTEMCTL" stop "$unit" >/dev/null 2>&1 || true
  for _ in $(seq 1 20); do
    "$SYSTEMCTL" is-active --quiet "$unit" || return 0
    "$SLEEP" 0.5
  done
  "$SYSTEMCTL" kill --kill-who=all --signal=SIGKILL "$unit" >/dev/null 2>&1 || true
  "$SYSTEMCTL" stop "$unit" >/dev/null 2>&1 || true
  "$SYSTEMCTL" is-active --quiet "$unit" && return 1 || return 0
}

restore(){
  local code=$?
  [[ "$SUCCESS" -eq 1 ]] && return 0
  trap - ERR INT TERM EXIT
  rm -f "${ROOT_TMP:-}" "${CSS_TMP:-}" >/dev/null 2>&1 || true
  PHASE="palautus"
  say "Asennus epäonnistui — palautetaan V$CURRENT_VERSION"
  stop_unit nspire-kiosk.service || true
  stop_unit nspire-v6.service || true
  cp -a "$BACKUP/__init__.py" "$INIT"
  cp -a "$BACKUP/app.css" "$CSS"
  cp -a "$BACKUP/index.html" "$INDEX"
  cp -a "$BACKUP/app.js" "$APPJS"
  rm -rf "$LIVE/nspire/__pycache__" >/dev/null 2>&1 || true
  "$SYSTEMCTL" daemon-reload >/dev/null 2>&1 || true
  "$SYSTEMCTL" reset-failed nspire-v6.service nspire-kiosk.service >/dev/null 2>&1 || true
  [[ "$BACKEND_WAS_ACTIVE" -eq 1 ]] && "$SYSTEMCTL" start nspire-v6.service >/dev/null 2>&1 || true
  [[ "$KIOSK_WAS_ACTIVE" -eq 1 ]] && "$SYSTEMCTL" start nspire-kiosk.service >/dev/null 2>&1 || true
  say "Palautus valmis: $BACKUP"
  exit "$code"
}
trap restore ERR INT TERM EXIT

PHASE="palvelujen pysäytys"
say "Pysäytetään kioski ja backend hallitusti"
[[ "$KIOSK_WAS_ACTIVE" -eq 1 ]] && stop_unit nspire-kiosk.service || true
[[ "$BACKEND_WAS_ACTIVE" -eq 1 ]] && stop_unit nspire-v6.service || true

PHASE="tiedostopäivitys"
python3 "$PKG_DIR/payload/apply_patch.py" apply \
  --init "$INIT" --css "$CSS" --index "$INDEX" --js "$APPJS"
rm -rf "$LIVE/nspire/__pycache__" >/dev/null 2>&1 || true
python3 -m py_compile "$INIT"
python3 "$PKG_DIR/payload/apply_patch.py" verify \
  --init "$INIT" --css "$CSS" --index "$INDEX" --js "$APPJS"

PHASE="backendin käynnistys"
"$SYSTEMCTL" daemon-reload
"$SYSTEMCTL" reset-failed nspire-v6.service nspire-kiosk.service >/dev/null 2>&1 || true
"$SYSTEMCTL" start nspire-v6.service
for _ in $(seq 1 60); do
  if "$SYSTEMCTL" is-active --quiet nspire-v6.service && \
     "$CURL" -fsS --noproxy '*' --connect-timeout 2 --max-time 5 http://127.0.0.1:8765/api/health >/dev/null 2>&1; then
    break
  fi
  "$SLEEP" 1
done
"$SYSTEMCTL" is-active --quiet nspire-v6.service || fail "Backend ei käynnistynyt"
health_json="$("$CURL" -fsS --noproxy '*' --connect-timeout 2 --max-time 6 http://127.0.0.1:8765/api/health)" || fail "Health-vastausta ei saatu"
printf '%s' "$health_json" | python3 -c 'import json,sys; d=json.load(sys.stdin); sys.exit(0 if d.get("ok") is True and str(d.get("version")) == "6.0.8" else 1)' \
  || fail "Backend ei ilmoita versiota V6.0.8"

PHASE="frontendin tarkistus"
ROOT_TMP="$(mktemp)"
CSS_TMP="$(mktemp)"
"$CURL" -fsS --noproxy '*' --connect-timeout 2 --max-time 8 http://127.0.0.1:8765/ > "$ROOT_TMP" || fail "Etusivua ei saatu"
"$CURL" -fsS --noproxy '*' --connect-timeout 2 --max-time 8 'http://127.0.0.1:8765/app.css?v=608' > "$CSS_TMP" || fail "Korjattua CSS-tiedostoa ei saatu"
python3 - "$ROOT_TMP" "$CSS_TMP" <<'PY'
from html.parser import HTMLParser
from pathlib import Path
import sys

class Probe(HTMLParser):
    def __init__(self):
        super().__init__()
        self.home_active=False
        self.grids=0
        self.tiles=0
        self.css_ok=False
    def handle_starttag(self, tag, attrs):
        a=dict(attrs)
        classes=set(a.get('class','').split())
        if tag == 'main' and a.get('id') == 'homeView':
            self.home_active={'view','view-home','is-active'}.issubset(classes)
        if 'app-grid' in classes:
            self.grids += 1
        if 'app-tile' in classes:
            self.tiles += 1
        if tag == 'link' and a.get('href') == '/app.css?v=608':
            self.css_ok=True

html=Path(sys.argv[1]).read_text(encoding='utf-8', errors='replace')
css=Path(sys.argv[2]).read_text(encoding='utf-8', errors='replace')
p=Probe(); p.feed(html)
assert p.home_active, 'homeView ei ole aktiivinen'
assert p.grids >= 1, 'app-grid puuttuu'
assert p.tiles >= 8, f'sovelluslaattoja vain {p.tiles}'
assert p.css_ok, 'CSS-välimuistiavain ei ole 608'
assert css.count('/* NSPIRE V6.0.8 DESKTOP VISIBILITY START */') == 1
assert css.count('/* NSPIRE V6.0.8 DESKTOP VISIBILITY END */') == 1
for marker in ('#homeView.is-active', '#homeView.is-active .app-grid', '#homeView.is-active .app-tile'):
    assert marker in css, marker
print('V6.0.8 HTTP FRONTEND CHECK OK')
PY
rm -f "$ROOT_TMP" "$CSS_TMP"
ROOT_TMP=""
CSS_TMP=""

PHASE="kioskin käynnistys"
if [[ "$KIOSK_WAS_ACTIVE" -eq 1 ]]; then
  "$SYSTEMCTL" start nspire-kiosk.service
  for _ in $(seq 1 40); do
    "$SYSTEMCTL" is-active --quiet nspire-kiosk.service && break
    "$SLEEP" 1
  done
  "$SYSTEMCTL" is-active --quiet nspire-kiosk.service || fail "Cog-kioski ei käynnistynyt"
fi

PHASE="vakaustarkistus"
for _ in 1 2 3 4; do
  "$SYSTEMCTL" is-active --quiet nspire-v6.service || fail "Backend pysähtyi vakaustarkistuksessa"
  "$CURL" -fsS --noproxy '*' --connect-timeout 2 --max-time 5 http://127.0.0.1:8765/api/health \
    | python3 -c 'import json,sys; d=json.load(sys.stdin); sys.exit(0 if str(d.get("version")) == "6.0.8" else 1)' \
    || fail "Health epäonnistui vakaustarkistuksessa"
  [[ "$KIOSK_WAS_ACTIVE" -eq 0 ]] || "$SYSTEMCTL" is-active --quiet nspire-kiosk.service || fail "Kioski pysähtyi vakaustarkistuksessa"
  "$SLEEP" 5
done

sha256sum "$INIT" "$CSS" "$INDEX" "$APPJS" > "$BACKUP/after.sha256"
SUCCESS=1
trap - ERR INT TERM EXIT
PHASE="valmis"
say "V6.0.8 asennus OK · työpöytäkorjaus pysyvä · lähtöversio V$CURRENT_VERSION · varmuuskopio=$BACKUP"
