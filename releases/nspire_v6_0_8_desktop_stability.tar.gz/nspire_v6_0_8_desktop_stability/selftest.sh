#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"
sha256sum -c SHA256SUMS
bash -n install.sh
python3 -m py_compile payload/apply_patch.py
python3 - "$ROOT" <<'PY'
from pathlib import Path
import hashlib
import importlib.util
import tempfile
import sys

root=Path(sys.argv[1])
spec=importlib.util.spec_from_file_location('patch', root/'payload/apply_patch.py')
mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)

base_css='''body { color: white; }\n.view { display: none; height: calc(100% - 54px); }\n.view-home { overflow-y: auto; }\n.app-grid { display: grid; }\n.app-tile { display: flex; }\n'''
legacy='''/* NSPIRE desktop emergency recovery */
#homeView.is-active {
  display: block !important;
  visibility: visible !important;
  opacity: 1 !important;
  min-height: calc(100vh - var(--bar-height, 54px)) !important;
}

#homeView.is-active .home-heading {
  display: flex !important;
  visibility: visible !important;
  opacity: 1 !important;
}

#homeView.is-active .app-grid {
  display: grid !important;
  visibility: visible !important;
  opacity: 1 !important;
}

#homeView.is-active .app-tile {
  display: flex !important;
  visibility: visible !important;
  opacity: 1 !important;
}

.view:not(.is-active) {
  display: none !important;
}
'''
index='''<!doctype html><link rel="stylesheet" href="/app.css?v=603"><main id="homeView" class="view view-home is-active"><section class="app-grid">''' + ''.join('<button class="app-tile"></button>' for _ in range(10)) + '''</section></main>'''
js='function showHome(){ homeView.classList.add("is-active"); } document.querySelectorAll(".app-tile");'
init='__version__ = "6.0.4"\n'

for css in (base_css, base_css+legacy):
    a,b,c=mod.build_patched(init,css,index)
    mod.verify_final(a,b,c,js)
    assert mod.LEGACY not in b
    assert b.count(mod.START) == b.count(mod.END) == 1
    # Idempotence: applying the transform again must not change any file.
    a2,b2,c2=mod.build_patched(a,b,c)
    assert (a,b,c)==(a2,b2,c2)

bad=base_css+legacy+'\n.extra { display:block; }\n'
try:
    mod.build_patched(init,bad,index)
except ValueError:
    pass
else:
    raise AssertionError('epäselvä legacy-lohko hyväksyttiin')

installer=(root/'install.sh').read_text(encoding='utf-8')
for marker in ('/api/health', 'app.css?v=608', 'V6.0.8 asennus OK', 'before.sha256', 'after.sha256'):
    assert marker in installer, marker
assert '/api/update' not in installer
print('V6.0.8 PACKAGE SELFTEST OK')
PY
