#!/usr/bin/env bash
set -Eeuo pipefail
umask 077

VERSION="7.1.1"
REF="db05190b496f18b8eafe40dc24d6be25a351cd46"
URL="https://raw.githubusercontent.com/mikavahakangas-hue/Pirre/${REF}/releases/nspire_v7_1_0_v42_rebuild.tar.gz"
EXPECTED="68ca0732f09ee35766379bc4399489bef154f5108496a39adde19e9f267e6b7b"
CURL="${CURL:-curl}"
WORK="$(mktemp -d /tmp/nspire-v711-bootstrap.XXXXXX)"
LOG="${NSPIRE_LOG:-/var/log/nspire-v6-update.log}"
PHASE="alustus"

say(){ printf '%s [V%s bootstrap · %s] %s\n' "$(date -Is)" "$VERSION" "$PHASE" "$*" | tee -a "$LOG"; }
cleanup(){ rm -rf "$WORK"; }
trap cleanup EXIT INT TERM

[[ ${EUID:-$(id -u)} -eq 0 ]] || { echo "Aja päivitys root-oikeuksilla." >&2; exit 1; }
for cmd in "$CURL" sha256sum tar python3 sed grep tee date mktemp rm chmod bash; do command -v "$cmd" >/dev/null 2>&1 || { echo "Komento puuttuu: $cmd" >&2; exit 1; }; done
mkdir -p "$(dirname "$LOG")" "$WORK/extract"

PHASE="lataus"
say "Ladataan varmennettu V7.1-pohjapaketti"
"$CURL" -fL --retry 3 --retry-delay 2 --connect-timeout 10 --max-time 180 -o "$WORK/base.tar.gz" "$URL"
printf '%s  %s\n' "$EXPECTED" "$WORK/base.tar.gz" | sha256sum -c -

tar -xzf "$WORK/base.tar.gz" -C "$WORK/extract"
PKG="$WORK/extract/nspire_v7_1_0_v42_rebuild"
[[ -x "$PKG/install.sh" && -x "$PKG/selftest.sh" ]] || { echo "Pohjapaketin rakenne on virheellinen." >&2; exit 1; }

PHASE="versiokorjaus"
say "Luodaan V7.1.1 ja pakotetaan updaterin sekä selaimen välimuistin päivitys"
printf '7.1.1\n' > "$PKG/VERSION"
sed -i '1s/V7\.1\.0/V7.1.1/' "$PKG/README.md" "$PKG/CHANGELOG.txt"
sed -i 's/__version__ = "7\.1\.0"/__version__ = "7.1.1"/' "$PKG/payload/__init__.py"
sed -i 's/V7\.1\.0 käynnistyi/V7.1.1 käynnistyi/; s/NSPIRE V7\.1\.0 V4\.2 IDEAS REBUILD/NSPIRE V7.1.1 V4.2 IDEAS REBUILD/g' "$PKG/payload/app.js"
sed -i 's/NSPIRE V7\.1\.0 V4\.2 IDEAS REBUILD/NSPIRE V7.1.1 V4.2 IDEAS REBUILD/g' "$PKG/payload/app.css"
sed -i 's/app\.css?v=710/app.css?v=711/g; s/app\.js?v=710/app.js?v=711/g' "$PKG/payload/index.html" "$PKG/payload/screensaver.html"
sed -i \
  -e 's/VERSION="7\.1\.0"/VERSION="7.1.1"/' \
  -e 's/v7_1_0_v42_rebuild_before_/v7_1_1_v42_rebuild_before_/' \
  -e 's/6\.1\.2|6\.2\.0|7\.0\.0|7\.1\.0/6.1.2|6.2.0|7.0.0|7.1.0|7.1.1/' \
  -e 's/V6\.1\.2–V7\.1\.0/V6.1.2–V7.1.1/' \
  -e 's/NSPIRE V7\.1\.0 V4\.2 IDEAS REBUILD/NSPIRE V7.1.1 V4.2 IDEAS REBUILD/g' \
  -e 's/=="7\.1\.0"/=="7.1.1"/' \
  -e 's/versiota V7\.1\.0/versiota V7.1.1/' \
  -e 's/V7\.1\.0 asennus OK/V7.1.1 asennus OK/' \
  -e 's/app\.css?v=710/app.css?v=711/g' \
  -e 's/app\.js?v=710/app.js?v=711/g' \
  "$PKG/install.sh"
sed -i \
  -e 's/NSPIRE V7\.1\.0 PACKAGE SELFTEST OK/NSPIRE V7.1.1 PACKAGE SELFTEST OK/' \
  -e 's/app\.js?v=710/app.js?v=711/g' \
  -e 's|/tmp/nspire-v710-saver.js|/tmp/nspire-v711-saver.js|g' \
  "$PKG/selftest.sh"

(
  cd "$PKG"
  {
    sha256sum VERSION CHANGELOG.txt README.md
    sha256sum payload/__init__.py payload/server.py payload/app.css payload/index.html payload/app.js payload/screensaver.html
  } > SHA256SUMS
  chmod 0755 install.sh selftest.sh payload/server.py
  ./selftest.sh
)

PHASE="asennus"
exec "$PKG/install.sh"
