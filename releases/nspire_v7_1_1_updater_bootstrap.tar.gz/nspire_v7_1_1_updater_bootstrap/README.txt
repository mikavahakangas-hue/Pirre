NSPIRE V7.1.1 updater bootstrap. Downloads the verified V7.1.0 rebuild, converts it deterministically to V7.1.1, runs package selftests, then installs with automatic rollback.
