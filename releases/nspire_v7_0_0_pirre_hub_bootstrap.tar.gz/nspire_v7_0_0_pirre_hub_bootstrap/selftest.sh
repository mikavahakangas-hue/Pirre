#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"
sha256sum -c SHA256SUMS
bash -n install.sh
for marker in \
  '74c74808362c2e1b3ace464596aa802cbde03854' \
  '6cebd526d25b734370b80d2052ae1f9caaeb1b54c14b90ed93d08ead2cd2e946' \
  '621519aa3c89673f0f0499127d8f37837a6a253cdaefa84637af742ff1624ec8' \
  'NSPIRE_BOOTSTRAP_VERIFY_ONLY' \
  'PART_NAMES' \
  'Arkistoauditointi OK'; do
  grep -Fq "$marker" install.sh
 done
[[ "$(grep -cE '^[[:space:]]+[0-9a-f]{64}$' install.sh)" -eq 9 ]]
echo 'V7.0.0 BOOTSTRAP SELFTEST OK'
