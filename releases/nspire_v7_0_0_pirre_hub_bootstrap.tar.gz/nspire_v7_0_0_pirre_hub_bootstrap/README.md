# NSPIRE V7.0.0 Pirre Hub – varmennettu bootstrap

Bootstrap lataa yhdeksän tavutasolla varmennettua tekstiosaa lukitusta GitHub-commitista,
kokoaa täyden V7.0.0-paketin, tarkistaa jokaisen osan, koko base64-aineiston ja
varsinaisen paketin SHA-256:n, auditoi arkiston ja suorittaa sisäpaketin selftestin
ennen asennusta.
