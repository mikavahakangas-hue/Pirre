#!/usr/bin/env bash
set -Eeuo pipefail
umask 022

DEFAULT_PARTS_BASE_URL="https://raw.githubusercontent.com/mikavahakangas-hue/Pirre/74c74808362c2e1b3ace464596aa802cbde03854/releases/v7.0.0-exact"
BASE_URL="${NSPIRE_PARTS_BASE_URL:-$DEFAULT_PARTS_BASE_URL}"
INNER_SHA256="6cebd526d25b734370b80d2052ae1f9caaeb1b54c14b90ed93d08ead2cd2e946"
B64_SHA256="621519aa3c89673f0f0499127d8f37837a6a253cdaefa84637af742ff1624ec8"
EXPECTED_B64_SIZE=59392
PART_NAMES=(part00a part00b part01 part02 part03 part04 part05 part06 part07)
PART_SHA256=(
  26b265884ff7b93dcb17dd4656b730397cf44bb944336ba64dd05437f71aa3a8
  8f1454d58f5e15376d4fbef464fc8fc34250a9a6ae5f137cd52cf7f7ea963cb8
  24cc8f8044c24530b3459e2a3386de9055867575d4af020338c1534a50430a1b
  ab6c35546b4fc88bf1a6700c926ea8187e6f9250933728c4306a6f8dab072f67
  f7cd27b6d35f21b8b527058599fd3ea84966fb7d986e463bcd08756ccbcf97d4
  0afe60923938875bf359abb97a7d363ff9a2aa99cc0a06c07e34707f2b524f08
  e17cb558eb5a06d247a2d3bf8dcab41d2cfae3c62fa75a8db8f6b2307cba5e5f
  d0d989b6837c965b41580f02fdd647a0ba46fbd4b84cddf0a18d1b0767632048
  a0a900720636133317cbb5de74a93c6072bf8af57f3239f37865fe7db848fa60
)
TMP_ROOT="$(mktemp -d /tmp/nspire-v700-bootstrap.XXXXXX)"
B64_FILE="$TMP_ROOT/nspire_v7_0_0_pirre_hub.tar.gz.b64"
ARCHIVE="$TMP_ROOT/nspire_v7_0_0_pirre_hub.tar.gz"
EXTRACT="$TMP_ROOT/extract"
CURL_BIN="${CURL:-curl}"

cleanup(){ rm -rf "$TMP_ROOT"; }
trap cleanup EXIT INT TERM

[[ ${EUID:-$(id -u)} -eq 0 ]] || { echo "Aja asennin root-oikeuksilla." >&2; exit 1; }
for cmd in "$CURL_BIN" base64 sha256sum tar bash mkdir mktemp rm cat wc python3; do
  command -v "$cmd" >/dev/null 2>&1 || { echo "Komento puuttuu: $cmd" >&2; exit 1; }
done
[[ ${#PART_NAMES[@]} -eq ${#PART_SHA256[@]} ]] || { echo "Osaluettelon rakennevirhe." >&2; exit 1; }

: > "$B64_FILE"
for i in "${!PART_NAMES[@]}"; do
  name="${PART_NAMES[$i]}"
  part="$TMP_ROOT/${name}.txt"
  echo "V7.0.0: ladataan ja tarkistetaan osa $((i+1))/${#PART_NAMES[@]}"
  "$CURL_BIN" -fsSL --retry 3 --retry-delay 1 --connect-timeout 10 --max-time 90 \
    "$BASE_URL/${name}.txt" -o "$part"
  printf '%s  %s\n' "${PART_SHA256[$i]}" "$part" | sha256sum -c -
  cat "$part" >> "$B64_FILE"
done

actual_size="$(wc -c < "$B64_FILE")"
[[ "$actual_size" == "$EXPECTED_B64_SIZE" ]] || {
  echo "Base64-aineiston koko ei täsmää: $actual_size / $EXPECTED_B64_SIZE" >&2
  exit 1
}
printf '%s  %s\n' "$B64_SHA256" "$B64_FILE" | sha256sum -c -
base64 --decode "$B64_FILE" > "$ARCHIVE"
printf '%s  %s\n' "$INNER_SHA256" "$ARCHIVE" | sha256sum -c -

python3 - "$ARCHIVE" <<'PY'
import sys, tarfile
from pathlib import PurePosixPath
archive = sys.argv[1]
expected_root = "nspire_v7_0_0_pirre_hub"
with tarfile.open(archive, "r:gz") as tf:
    members = tf.getmembers()
    if not members:
        raise SystemExit("Arkisto on tyhjä")
    for m in members:
        p = PurePosixPath(m.name)
        if p.is_absolute() or ".." in p.parts or not p.parts or p.parts[0] != expected_root:
            raise SystemExit(f"Turvaton arkistopolku: {m.name}")
        if m.issym() or m.islnk() or m.isdev():
            raise SystemExit(f"Kielletty arkistojäsen: {m.name}")
print("Arkistoauditointi OK")
PY

mkdir -p "$EXTRACT"
tar -xzf "$ARCHIVE" -C "$EXTRACT" --no-same-owner --no-same-permissions
INNER_DIR="$EXTRACT/nspire_v7_0_0_pirre_hub"
[[ -x "$INNER_DIR/install.sh" ]] || { echo "Varsinainen V7.0.0-asennin puuttuu." >&2; exit 1; }
(
  cd "$INNER_DIR"
  sha256sum -c SHA256SUMS
  ./selftest.sh
)

if [[ "${NSPIRE_BOOTSTRAP_VERIFY_ONLY:-0}" == "1" ]]; then
  echo "V7.0.0 bootstrap verification OK"
  exit 0
fi

exec bash "$INNER_DIR/install.sh"
