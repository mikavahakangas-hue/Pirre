#!/usr/bin/env bash
set -Eeuo pipefail

SELF="$(cd "$(dirname "$0")" && pwd)"
ROOT="${NSPIRE_ROOT:-}"
TEST_MODE="${NSPIRE_TEST_MODE:-0}"
PREFLIGHT_ONLY="${NSPIRE_PREFLIGHT_ONLY:-0}"
SOURCE_VERSION="4.42.7"
TARGET_VERSION="$(tr -d '[:space:]' < "$SELF/VERSION")"

UI_DIR="$ROOT/opt/nspire-ui/static/v4"
API_DIR="$ROOT/opt/nspire-v4"
API_FILE="$API_DIR/nspire_v4_api.py"
CONFIG_DIR="$ROOT/home/mavks/.config/nspire-v4"
CONFIG_FILE="$CONFIG_DIR/config.json"
STATE_DIR="$ROOT/home/mavks/.local/share/nspire-v4"
SYSTEMD_DIR="$ROOT/etc/systemd/system"
LOCAL_SBIN="$ROOT/usr/local/sbin"
KIOSK_UNIT="$SYSTEMD_DIR/kiosk-cog.service"
KIOSK_DISABLED="$SYSTEMD_DIR/kiosk-cog.service.disabled"
KIOSK_DROPIN="$SYSTEMD_DIR/kiosk-cog.service.d"

fail(){ echo "VIRHE: $*" >&2; exit 1; }
[[ "$TARGET_VERSION" == "4.42.8" ]] || fail "VERSION ei ole 4.42.8"
[[ -f "$UI_DIR/app.js" && -f "$UI_DIR/app.css" && -f "$API_FILE" ]] || fail "nykyiset ohjelmatiedostot puuttuvat"
[[ -f "$SELF/SHA256SUMS" ]] || fail "SHA256SUMS puuttuu"
(cd "$SELF" && sha256sum -c SHA256SUMS)
grep -Fq "APP_VERSION='$SOURCE_VERSION'" "$UI_DIR/app.js" || fail "laite ei ole V$SOURCE_VERSION"
grep -Fq "APP_VERSION = \"$SOURCE_VERSION\"" "$API_FILE" || fail "backend ei ole V$SOURCE_VERSION"

STAGE="$(mktemp -d -t nspire-v4428-stage-XXXXXX)"
cleanup(){ rm -rf "$STAGE"; }
trap cleanup EXIT
cp "$SELF/payload/app.js" "$STAGE/app.js"
cp "$SELF/payload/app.css" "$STAGE/app.css"
cp "$SELF/payload/nspire_v4_api.py" "$STAGE/nspire_v4_api.py"
node --check "$STAGE/app.js" >/dev/null
python3 -m py_compile "$STAGE/nspire_v4_api.py"
grep -Fq "APP_VERSION='$TARGET_VERSION'" "$STAGE/app.js" || fail "uuden JS-version tarkistus epäonnistui"
grep -Fq "APP_VERSION = \"$TARGET_VERSION\"" "$STAGE/nspire_v4_api.py" || fail "uuden backend-version tarkistus epäonnistui"
grep -Fq "125 % · VAKAA" "$STAGE/app.js" || fail "vakaa kokoasetus puuttuu"
! grep -Fq "scheduleAutomaticUpdatePoll" "$STAGE/app.js" || fail "selainajastin jäi pakettiin"

if [[ "$PREFLIGHT_ONLY" == "1" ]]; then
  echo "V$TARGET_VERSION esitarkistus OK"
  exit 0
fi

if [[ -z "$ROOT" && "$EUID" -ne 0 ]]; then
  fail "asenna sudo-komennolla"
fi

STAMP="$(date +%Y%m%d-%H%M%S)"
BACK="$ROOT/root/nspire-backup/ota_before_${TARGET_VERSION//./_}_$STAMP"
mkdir -p "$BACK/ui" "$BACK/api" "$BACK/config" "$BACK/systemd" "$BACK/bin"
cp -a "$UI_DIR/app.js" "$BACK/ui/app.js"
cp -a "$UI_DIR/app.css" "$BACK/ui/app.css"
cp -a "$API_FILE" "$BACK/api/nspire_v4_api.py"
[[ -f "$CONFIG_FILE" ]] && cp -a "$CONFIG_FILE" "$BACK/config/config.json"
[[ -e "$KIOSK_UNIT" || -L "$KIOSK_UNIT" ]] && cp -a "$KIOSK_UNIT" "$BACK/systemd/kiosk-cog.service"
[[ -e "$KIOSK_DISABLED" ]] && cp -a "$KIOSK_DISABLED" "$BACK/systemd/kiosk-cog.service.disabled"
[[ -d "$KIOSK_DROPIN" ]] && cp -a "$KIOSK_DROPIN" "$BACK/systemd/kiosk-cog.service.d"
for f in nspire-v4-auto-update.service nspire-v4-auto-update.timer; do
  [[ -f "$SYSTEMD_DIR/$f" ]] && cp -a "$SYSTEMD_DIR/$f" "$BACK/systemd/$f"
done
for f in nspire-v4-auto-update-check nspire-healthcheck; do
  [[ -f "$LOCAL_SBIN/$f" ]] && cp -a "$LOCAL_SBIN/$f" "$BACK/bin/$f"
done

ORIG_API_ACTIVE=0
ORIG_KIOSK_ACTIVE=0
ORIG_KIOSK_MASKED=0
if [[ "$TEST_MODE" != "1" ]]; then
  systemctl is-active --quiet nspire-v4.service && ORIG_API_ACTIVE=1 || true
  systemctl is-active --quiet kiosk-cog.service && ORIG_KIOSK_ACTIVE=1 || true
  [[ "$(systemctl is-enabled kiosk-cog.service 2>/dev/null || true)" == "masked" ]] && ORIG_KIOSK_MASKED=1 || true
fi

restore_backup(){
  set +e
  install -m 0644 "$BACK/ui/app.js" "$UI_DIR/app.js"
  install -m 0644 "$BACK/ui/app.css" "$UI_DIR/app.css"
  install -m 0644 "$BACK/api/nspire_v4_api.py" "$API_FILE"
  if [[ -f "$BACK/config/config.json" ]]; then
    mkdir -p "$CONFIG_DIR"; install -m 0644 "$BACK/config/config.json" "$CONFIG_FILE"
  fi
  rm -rf "$KIOSK_UNIT" "$KIOSK_DISABLED" "$KIOSK_DROPIN"
  [[ -e "$BACK/systemd/kiosk-cog.service" || -L "$BACK/systemd/kiosk-cog.service" ]] && cp -a "$BACK/systemd/kiosk-cog.service" "$KIOSK_UNIT"
  [[ -e "$BACK/systemd/kiosk-cog.service.disabled" ]] && cp -a "$BACK/systemd/kiosk-cog.service.disabled" "$KIOSK_DISABLED"
  [[ -d "$BACK/systemd/kiosk-cog.service.d" ]] && cp -a "$BACK/systemd/kiosk-cog.service.d" "$KIOSK_DROPIN"
  for f in nspire-v4-auto-update.service nspire-v4-auto-update.timer; do
    rm -f "$SYSTEMD_DIR/$f"; [[ -f "$BACK/systemd/$f" ]] && cp -a "$BACK/systemd/$f" "$SYSTEMD_DIR/$f"
  done
  for f in nspire-v4-auto-update-check nspire-healthcheck; do
    rm -f "$LOCAL_SBIN/$f"; [[ -f "$BACK/bin/$f" ]] && cp -a "$BACK/bin/$f" "$LOCAL_SBIN/$f"
  done
  if [[ "$TEST_MODE" != "1" ]]; then
    systemctl daemon-reload
    if [[ "$ORIG_KIOSK_MASKED" == "1" ]]; then
      systemctl stop kiosk-cog.service >/dev/null 2>&1 || true
    else
      [[ "$ORIG_API_ACTIVE" == "1" ]] && systemctl restart nspire-v4.service || true
      [[ "$ORIG_KIOSK_ACTIVE" == "1" ]] && systemctl start kiosk-cog.service || true
    fi
  fi
}
rollback(){
  rc=$?
  trap - ERR
  restore_backup
  echo "VIRHE: V$TARGET_VERSION epäonnistui; aiempi tila palautettiin" >&2
  exit "$rc"
}
trap rollback ERR

if [[ "$TEST_MODE" != "1" ]]; then
  systemctl stop nspire-watchdog.timer >/dev/null 2>&1 || true
  systemctl stop nspire-v4-auto-update.timer >/dev/null 2>&1 || true
  systemctl stop nspire-v4.service >/dev/null 2>&1 || true
  systemctl kill --kill-who=all --signal=KILL kiosk-cog.service >/dev/null 2>&1 || true
  systemctl stop kiosk-cog.service >/dev/null 2>&1 || true
fi

# Palauta käyttäjän tekemä huoltomaskaus hallitusti.
if [[ -L "$KIOSK_UNIT" && "$(readlink "$KIOSK_UNIT")" == "/dev/null" ]]; then
  rm -f "$KIOSK_UNIT"
  [[ -f "$KIOSK_DISABLED" ]] || fail "kioskin alkuperäinen palvelutiedosto puuttuu"
  mv "$KIOSK_DISABLED" "$KIOSK_UNIT"
elif [[ ! -f "$KIOSK_UNIT" && -f "$KIOSK_DISABLED" ]]; then
  mv "$KIOSK_DISABLED" "$KIOSK_UNIT"
fi
[[ -f "$KIOSK_UNIT" ]] || fail "kiosk-cog.service puuttuu"
# Poista väärään osioon aiemmin jääneet StartLimit-rivit; oikeat arvot tulevat drop-inistä.
sed -i '/^[[:space:]]*StartLimitIntervalSec=/d;/^[[:space:]]*StartLimitBurst=/d' "$KIOSK_UNIT"
rm -f "$KIOSK_DROPIN/stability.conf"
mkdir -p "$KIOSK_DROPIN"
install -m 0644 "$SELF/payload/kiosk-cog-stability.conf" "$KIOSK_DROPIN/20-v4428-stability.conf"

install -m 0644 "$STAGE/app.js" "$UI_DIR/app.js"
install -m 0644 "$STAGE/app.css" "$UI_DIR/app.css"
install -m 0644 "$STAGE/nspire_v4_api.py" "$API_FILE"
mkdir -p "$LOCAL_SBIN" "$SYSTEMD_DIR" "$CONFIG_DIR" "$STATE_DIR"
install -m 0755 "$SELF/payload/nspire-v4-auto-update-check" "$LOCAL_SBIN/nspire-v4-auto-update-check"
install -m 0755 "$SELF/payload/nspire-healthcheck" "$LOCAL_SBIN/nspire-healthcheck"
install -m 0644 "$SELF/payload/nspire-v4-auto-update.service" "$SYSTEMD_DIR/nspire-v4-auto-update.service"
install -m 0644 "$SELF/payload/nspire-v4-auto-update.timer" "$SYSTEMD_DIR/nspire-v4-auto-update.timer"

python3 - "$CONFIG_FILE" "$STATE_DIR" <<'PY'
import json, sys, time
from pathlib import Path
config_path=Path(sys.argv[1]); state_dir=Path(sys.argv[2])
config_path.parent.mkdir(parents=True, exist_ok=True)
try: cfg=json.loads(config_path.read_text(encoding='utf-8')) if config_path.exists() else {}
except Exception: cfg={}
if not isinstance(cfg,dict): cfg={}
cfg['ui_scale_pct']=125
cfg['update_auto_download']=False
cfg['update_auto_install']=False
cfg.setdefault('update_auto_check',True)
cfg.setdefault('update_check_interval_min',30)
cfg.setdefault('update_check_only_charging',True)
tmp=config_path.with_suffix('.json.tmp')
tmp.write_text(json.dumps(cfg,ensure_ascii=False,indent=2)+'\n',encoding='utf-8'); tmp.replace(config_path)
state_dir.mkdir(parents=True, exist_ok=True)
state_path=state_dir/'update-state.json'
try: state=json.loads(state_path.read_text(encoding='utf-8')) if state_path.exists() else {}
except Exception: state={}
if not isinstance(state,dict): state={}
downloaded=str(state.get('downloaded_path') or '')
if downloaded:
    try: Path(downloaded).unlink(missing_ok=True)
    except Exception: pass
state.update({'operation':'idle','operation_message':'','error':'','downloaded_path':'','downloaded_version':'','downloaded':False,'install_scheduled_ts':0,'install_path':''})
tmp=state_path.with_suffix('.json.tmp')
tmp.write_text(json.dumps(state,ensure_ascii=False,indent=2)+'\n',encoding='utf-8'); tmp.replace(state_path)
install_path=state_dir/'update-install-status.json'
status={'state':'idle','title':'','message':'','progress':0,'error':'','acknowledged':True,'acknowledged_ts':int(time.time())}
tmp=install_path.with_suffix('.json.tmp')
tmp.write_text(json.dumps(status,ensure_ascii=False,indent=2)+'\n',encoding='utf-8'); tmp.replace(install_path)
PY

node --check "$UI_DIR/app.js" >/dev/null
python3 -m py_compile "$API_FILE"

if [[ "$TEST_MODE" == "1" ]]; then
  grep -Fq "APP_VERSION='$TARGET_VERSION'" "$UI_DIR/app.js"
  grep -Fq "APP_VERSION = \"$TARGET_VERSION\"" "$API_FILE"
  [[ -f "$SYSTEMD_DIR/nspire-v4-auto-update.timer" ]]
  [[ -f "$KIOSK_DROPIN/20-v4428-stability.conf" ]]
  trap - ERR
  echo "V$TARGET_VERSION testi-asennus OK"
  exit 0
fi

systemctl daemon-reload
systemctl unmask kiosk-cog.service >/dev/null 2>&1 || true
systemctl enable kiosk-cog.service >/dev/null
systemctl enable nspire-v4-auto-update.timer >/dev/null
systemctl enable nspire-watchdog.timer >/dev/null 2>&1 || true
systemctl restart nspire-v4.service

health_ok=0
for _ in $(seq 1 20); do
  if curl -fsS --max-time 4 http://127.0.0.1:8093/health | python3 -c 'import json,sys; d=json.load(sys.stdin); assert d.get("ok") is True and str(d.get("version"))==sys.argv[1]' "$TARGET_VERSION" >/dev/null 2>&1; then
    health_ok=1; break
  fi
  sleep 1
done
[[ "$health_ok" == "1" ]] || fail "backend ei käynnistynyt terveenä"

systemctl start nspire-v4-auto-update.timer
systemctl start nspire-watchdog.timer >/dev/null 2>&1 || true
systemctl start kiosk-cog.service
sleep 8
systemctl is-active --quiet nspire-v4.service
systemctl is-active --quiet kiosk-cog.service
RESTARTS="$(systemctl show kiosk-cog.service -p NRestarts --value)"
[[ "${RESTARTS:-0}" -le 1 ]] || fail "kioski jäi uudelleenkäynnistyssilmukkaan"

trap - ERR
echo "V$TARGET_VERSION asennus OK · backend ja kioski aktiivisia · NRestarts=${RESTARTS:-0}"
