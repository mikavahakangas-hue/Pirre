#!/usr/bin/env python3
from pathlib import Path
import sys

if len(sys.argv) != 6:
    raise SystemExit('usage: patch.py index app.js app.css api.py target_version')
index_p, js_p, css_p, api_p, target = map(Path, sys.argv[:4]) + [sys.argv[4]] if False else (Path(sys.argv[1]),Path(sys.argv[2]),Path(sys.argv[3]),Path(sys.argv[4]),sys.argv[5])
source='4.42.4'

css=css_p.read_text(encoding='utf-8')
js=js_p.read_text(encoding='utf-8')
api=api_p.read_text(encoding='utf-8')

if f"APP_VERSION='{source}'" not in js:
    raise SystemExit('source JS version mismatch')
if f'APP_VERSION = "{source}"' not in api:
    raise SystemExit('source API version mismatch')
marker='/* NSPIRE UI V4.42.4 — contrast and component polish only */'
if marker not in css:
    raise SystemExit('V4.42.4 CSS marker missing')
css=css.split(marker,1)[0].rstrip()+"\n"

repls=[]
repls.append(('''.home-refresh,.home-live,.app-tile{background:var(--surface)!important;border-color:var(--line)!important;color:var(--text)!important}
.home-live strong,.app-tile strong{color:var(--text)!important}
.home-live small,.app-tile small,.home-title-block .eyebrow,.home-title-block p{color:var(--muted)!important}
.app-tile::before{background:color-mix(in srgb,var(--tile-color,var(--accent)) 14%,var(--surface2))!important;border-color:color-mix(in srgb,var(--tile-color,var(--accent)) 31%,var(--line))!important}
.app-tile:active{background:color-mix(in srgb,var(--tile-color,var(--accent)) 9%,var(--surface))!important}
''','''.home-refresh,.home-live,.app-tile{background:linear-gradient(150deg,var(--surface),var(--surface2))!important;border-color:color-mix(in srgb,var(--line) 82%,var(--text) 18%)!important;color:var(--text)!important}
.home-live{box-shadow:0 2px 8px color-mix(in srgb,var(--shadow) 38%,transparent)!important}
.home-live strong,.app-tile strong{color:var(--text)!important}
.home-live small,.app-tile small,.home-title-block .eyebrow,.home-title-block p{color:var(--muted)!important}
.app-tile{padding:9px 7px!important;box-shadow:0 2px 7px color-mix(in srgb,var(--shadow) 34%,transparent),inset 0 1px 0 color-mix(in srgb,var(--text) 8%,transparent)!important}
.app-tile svg{width:31px!important;height:31px!important;margin-bottom:7px!important;background:color-mix(in srgb,var(--tile-accent,var(--accent)) 12%,var(--surface2))!important;border-color:color-mix(in srgb,var(--tile-accent,var(--accent)) 48%,var(--line))!important;color:var(--tile-accent,var(--accent))!important;filter:none!important}
.app-tile strong{font-size:12px!important;font-weight:760!important;line-height:1.08!important}
.app-tile small{font-size:7.5px!important;line-height:1.2!important;margin-top:4px!important}
.app-tile::before{left:18px!important;right:18px!important;height:3px!important;background:var(--tile-accent,var(--accent))!important;border:0!important;opacity:.88!important;box-shadow:none!important}
.app-tile:active{background:color-mix(in srgb,var(--tile-accent,var(--accent)) 10%,var(--surface))!important;border-color:color-mix(in srgb,var(--tile-accent,var(--accent)) 68%,var(--line))!important;transform:translateY(1px)!important}
'''))
repls.append(('''.theme-swatch{background:var(--surface)!important;border-color:var(--line)!important;color:var(--text)!important}
.theme-swatch.active{border-color:var(--accent)!important;box-shadow:inset 0 0 0 2px var(--accent),0 0 0 1px color-mix(in srgb,var(--accent) 26%,transparent)!important}
''','''.theme-swatch{min-height:58px!important;position:relative!important;overflow:hidden!important;background:linear-gradient(115deg,var(--swatch-a) 0 38%,var(--swatch-b) 38% 72%,var(--swatch-c) 72% 100%)!important;border:2px solid color-mix(in srgb,var(--line) 76%,var(--text) 24%)!important;color:var(--text)!important;box-shadow:0 2px 6px color-mix(in srgb,var(--shadow) 36%,transparent)!important;text-shadow:0 1px 2px rgba(0,0,0,.72)!important}
.theme-swatch::before{content:"";position:absolute;inset:0;background:linear-gradient(180deg,transparent 18%,rgba(0,0,0,.68));pointer-events:none}
.theme-swatch.active{border-color:var(--accent)!important;box-shadow:inset 0 0 0 2px var(--surface),0 0 0 2px var(--accent),0 3px 8px color-mix(in srgb,var(--accent) 30%,transparent)!important}
.theme-swatch.active::after{content:"✓";position:absolute;right:6px;top:5px;width:18px;height:18px;border-radius:50%;display:grid;place-items:center;background:var(--accent);color:#fff;font-size:12px;font-weight:900;text-shadow:none}
'''))
repls.append(('.saver-sofa .sofa-date{font-size:14px!important;font-weight:650!important;letter-spacing:.10em!important;color:color-mix(in srgb,var(--text) 78%,var(--muted))!important}', '.saver-sofa .sofa-clock span{font-size:15px!important;font-weight:700!important;letter-spacing:.11em!important;color:color-mix(in srgb,var(--text) 84%,var(--muted))!important}'))
repls.append(('.saver-sofa .sofa-metric,.saver-sofa .sofa-battery,.saver-sofa .sofa-footer{border-color:var(--line)!important;background:color-mix(in srgb,var(--surface) 96%,transparent)!important;box-shadow:0 5px 16px color-mix(in srgb,var(--shadow) 55%,transparent)!important}', '.saver-sofa .sofa-metric,.saver-sofa .sofa-battery,.saver-sofa .sofa-footer{border-color:color-mix(in srgb,var(--line) 80%,var(--text) 20%)!important;background:color-mix(in srgb,var(--surface) 94%,var(--bg2))!important;box-shadow:0 5px 16px color-mix(in srgb,var(--shadow) 48%,transparent)!important}'))
repls.append(('.saver-sofa .sofa-metric>strong{font-size:64px!important;line-height:.92!important;font-weight:600!important;letter-spacing:-.045em!important;color:var(--text)!important}', '.saver-sofa .sofa-metric>strong{font-size:64px!important;line-height:.92!important;font-weight:560!important;letter-spacing:-.045em!important;color:var(--text)!important}'))
repls.append(('.saver-sofa .sofa-metric>div em{font-size:23px!important;font-weight:650!important;color:var(--humidity)!important}', '.saver-sofa .sofa-metric>div em{font-size:24px!important;font-weight:760!important;color:var(--humidity)!important}'))
for old,new in repls:
    if old not in css: raise SystemExit('required CSS source block missing')
    css=css.replace(old,new,1)

anchor='.ota-quick-buttons .primary{border-color:var(--accent);background:linear-gradient(135deg,color-mix(in srgb,var(--accent) 30%,var(--surface2)),color-mix(in srgb,var(--accent2) 15%,var(--surface)));color:var(--text);font-weight:950;letter-spacing:.04em}\n'
insert='''\n/* NSPIRE UI V4.42.5 — direct component rules */
.ota-hero,.ota-card>div,.ota-quick,.update-manifest-card{background:linear-gradient(145deg,var(--surface),var(--surface2))!important;border-color:color-mix(in srgb,var(--line) 82%,var(--text) 18%)!important;color:var(--text)!important;box-shadow:0 2px 8px color-mix(in srgb,var(--shadow) 38%,transparent)!important}
.ota-hero strong,.ota-card b,.update-manifest-card strong{color:var(--text)!important}
.ota-hero span,.ota-hero small,.ota-card span,.update-manifest-card small{color:var(--muted)!important}
.ota-hero.available{border-color:var(--success)!important;background:linear-gradient(145deg,color-mix(in srgb,var(--success) 10%,var(--surface)),var(--surface2))!important}
.ota-hero.error{border-color:var(--danger)!important;background:linear-gradient(145deg,color-mix(in srgb,var(--danger) 10%,var(--surface)),var(--surface2))!important}
.ota-quick-buttons button{background:var(--surface2)!important;color:var(--text)!important;border-color:var(--line)!important}
.ota-quick-buttons .primary{background:color-mix(in srgb,var(--accent) 18%,var(--surface))!important;border-color:var(--accent)!important;color:var(--text)!important}
.update-manifest-input,.update-manifest-preview{background:var(--bg)!important;color:var(--text)!important;border-color:var(--line)!important}
.settings-panel .setting-row{background:linear-gradient(145deg,var(--surface),var(--surface2))!important;border-color:color-mix(in srgb,var(--line) 82%,var(--text) 18%)!important;box-shadow:0 1px 4px color-mix(in srgb,var(--shadow) 32%,transparent)!important}
.settings-nav button{background:color-mix(in srgb,var(--surface) 95%,var(--bg2))!important;color:var(--text)!important;border-color:color-mix(in srgb,var(--line) 84%,var(--text) 16%)!important}
.settings-nav button.active{background:color-mix(in srgb,var(--accent) 14%,var(--surface))!important;border-color:var(--accent)!important;box-shadow:inset 4px 0 0 var(--accent)!important}
#app[data-theme^="light-"] .app-tile,#app[data-theme^="light-"] .home-live,#app[data-theme^="light-"] .setting-row,#app[data-theme^="light-"] .ota-hero,#app[data-theme^="light-"] .ota-card>div,#app[data-theme^="light-"] .ota-quick,#app[data-theme^="light-"] .update-manifest-card{box-shadow:0 2px 7px rgba(0,0,0,.10)!important;border-color:color-mix(in srgb,var(--line) 68%,var(--text) 32%)!important}
'''
if anchor not in css: raise SystemExit('OTA anchor missing')
css=css.replace(anchor,anchor+insert,1)

js=js.replace(f"var APP_VERSION='{source}';",f"var APP_VERSION='{target}';",1)
release="  {version:'4.42.5',date:'14.07.2026',title:'Suorat komponenttikorjaukset',items:['Etusivun todelliset app-tile- ja SVG-säännöt uudistettiin.','Teemaesikatselut näyttävät jälleen oikeat kolmen värin paletit.','Display- ja Updates-sivut käyttävät niiden todellisia komponenttiluokkia.','SOHVA-päivämäärä korjattiin oikeaan sofa-clock span -elementtiin.']},\n"
needle="  {version:'4.42.4',"
pos=js.find(needle)
if pos<0: raise SystemExit('release insertion point missing')
js=js[:pos]+release+js[pos:]
api=api.replace(f'APP_VERSION = "{source}"',f'APP_VERSION = "{target}"',1)
api=api.replace(f'Nspire V{source} API listening',f'Nspire V{target} API listening',1)

css_p.write_text(css,encoding='utf-8')
js_p.write_text(js,encoding='utf-8')
api_p.write_text(api,encoding='utf-8')
