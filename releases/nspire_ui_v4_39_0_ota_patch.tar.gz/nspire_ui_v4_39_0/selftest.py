#!/usr/bin/env python3
from __future__ import annotations

import subprocess
import sys
import tempfile
from pathlib import Path

PKG = Path(__file__).resolve().parent
PATCH = PKG / "install_patch.py"


def base_files(style: int) -> dict[str, str]:
    if style == 1:
        app_version = "var APP_VERSION='4.38.2';"
        releases = "var RELEASES=[\n  {version:'4.38.2',date:'13.07.2026',title:'Vanha',items:[]}\n];"
    else:
        app_version = 'const APP_VERSION = "4.38.2";'
        releases = "var RELEASES = [\n  {version:'4.38.2',date:'13.07.2026',title:'Vanha',items:[]}\n];"
    app = f"""{app_version}
{releases}
function otaQuickActionsHtml(){{return '<div><strong>V4.38.2 · PÄIVITYSKANAVA OK</strong><button>LATAA</button><button>ASENNA</button></div>';}}
function showSaver(){{}}
function hideSaver(){{}}
function activity(){{}}
"""
    return {
        "index.html": "<!doctype html><title>NSPIRE V4.38.2</title><main data-view=\"draw\"><canvas></canvas></main>",
        "app.css": ".settings-content{display:block}.screensaver{display:block}",
        "app.js": app,
        "nspire_v4_api.py": "APP_VERSION='4.38.2'\nprint('Nspire V4.38.2 API listening')\n",
    }


def run_patch(files: dict[str, str], root: Path) -> Path:
    for name, content in files.items():
        path = root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")
    out = root / "out"
    subprocess.run(
        [sys.executable, str(PATCH), str(root / "index.html"), str(root / "app.css"), str(root / "app.js"), str(root / "nspire_v4_api.py"), str(out)],
        check=True,
    )
    return out


def assertions(out: Path) -> None:
    index = (out / "index.html").read_text(encoding="utf-8")
    css = (out / "app.css").read_text(encoding="utf-8")
    app = (out / "app.js").read_text(encoding="utf-8")
    api = (out / "nspire_v4_api.py").read_text(encoding="utf-8")
    assert "NSPIRE V4.39.0" in index
    assert "APP_VERSION='4.39.0'" in app or 'APP_VERSION = "4.39.0"' in app
    assert "V4.39.0 · LATAA JA PÄIVITÄ" in app
    assert app.count("NSPIRE V4.39.0 reliability layer") == 1
    assert css.count("NSPIRE V4.39.0 stability fixes") == 1
    assert "nspireUpdateBusy" in app and "data-update-busy" in css
    assert "pointerdown" in app and "TYHJENNÄ" in app
    assert "APP_VERSION='4.39.0'" in api


def test_variant(style: int) -> None:
    with tempfile.TemporaryDirectory(prefix=f"nspire-v439-test{style}-") as tmp:
        out = run_patch(base_files(style), Path(tmp))
        assertions(out)
        if subprocess.run(["bash", "-lc", "command -v node >/dev/null 2>&1"], check=False).returncode == 0:
            subprocess.run(["node", "--check", str(out / "app.js")], check=True)
        subprocess.run([sys.executable, "-m", "py_compile", str(out / "nspire_v4_api.py")], check=True)


def test_idempotent() -> None:
    with tempfile.TemporaryDirectory(prefix="nspire-v439-idempotent-") as tmp:
        root = Path(tmp)
        first = run_patch(base_files(1), root)
        files = {name: (first / name).read_text(encoding="utf-8") for name in ["index.html", "app.css", "app.js", "nspire_v4_api.py"]}
        second_root = root / "second"
        second = run_patch(files, second_root)
        assertions(second)
        assert (second / "app.js").read_text(encoding="utf-8").count("Yhden painalluksen päivitys ja vakauskorjaukset") == 1


def main() -> int:
    test_variant(1)
    print("TESTI 1/3 OK: nykyinen var-muoto")
    test_variant(2)
    print("TESTI 2/3 OK: väljempi const/RELEASES-muoto")
    test_idempotent()
    print("TESTI 3/3 OK: uudelleenajo ei tuplaa muutoksia")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
