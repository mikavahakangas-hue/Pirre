#!/usr/bin/env bash
set -Eeuo pipefail

PKG="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VERSION="$(tr -d '[:space:]' < "$PKG/VERSION")"
[[ "$VERSION" == "4.39.0" ]] || { echo "VIRHE: väärä OTA-versio: $VERSION" >&2; exit 1; }

cd "$PKG"
sha256sum -c --quiet SHA256SUMS
python3 -m py_compile "$PKG/install_patch.py" "$PKG/selftest.py"
python3 "$PKG/selftest.py"

if [[ "${NSPIRE_PREFLIGHT_ONLY:-0}" == "1" ]]; then
  echo "V4.39.0 OTA-esitarkistus OK"
  exit 0
fi

ROOT="${NSPIRE_OTA_TEST_ROOT:-}"
STATIC="$ROOT/opt/nspire-ui/static"
V4STATIC="$STATIC/v4"
APPDIR="$ROOT/opt/nspire-v4"
BACKUP_ROOT="$ROOT/root/nspire-backup"
BACKUP="$BACKUP_ROOT/ota_before_4_39_0_$(date +%F-%H%M%S)"

if [[ -z "$ROOT" && "${EUID:-$(id -u)}" -ne 0 ]]; then
  exec sudo -E bash "$0"
fi

[[ -f "$STATIC/index.html" ]] || { echo "VIRHE: index.html puuttuu" >&2; exit 1; }
[[ -f "$V4STATIC/app.css" ]] || { echo "VIRHE: app.css puuttuu" >&2; exit 1; }
[[ -f "$V4STATIC/app.js" ]] || { echo "VIRHE: app.js puuttuu" >&2; exit 1; }
[[ -f "$APPDIR/nspire_v4_api.py" ]] || { echo "VIRHE: backend puuttuu" >&2; exit 1; }

grep -q '<title>NSPIRE V4.38.2</title>\|<title>NSPIRE V4.39.0</title>' "$STATIC/index.html" || {
  echo "VIRHE: V4.39.0 vaatii V4.38.2-pohjan" >&2; exit 1;
}

mkdir -p "$BACKUP"
cp -a "$STATIC/index.html" "$BACKUP/index.html"
cp -a "$V4STATIC/app.css" "$BACKUP/app.css"
cp -a "$V4STATIC/app.js" "$BACKUP/app.js"
cp -a "$APPDIR/nspire_v4_api.py" "$BACKUP/nspire_v4_api.py"

rollback(){
  local rc=$?
  if [[ $rc -ne 0 ]]; then
    echo "VIRHE: V4.39.0 OTA epäonnistui, palautetaan edellinen versio" >&2
    cp -a "$BACKUP/index.html" "$STATIC/index.html" 2>/dev/null || true
    cp -a "$BACKUP/app.css" "$V4STATIC/app.css" 2>/dev/null || true
    cp -a "$BACKUP/app.js" "$V4STATIC/app.js" 2>/dev/null || true
    cp -a "$BACKUP/nspire_v4_api.py" "$APPDIR/nspire_v4_api.py" 2>/dev/null || true
    if [[ -z "$ROOT" ]]; then
      systemctl restart nspire-v4.service 2>/dev/null || true
      systemctl restart kiosk-cog.service 2>/dev/null || true
    fi
  fi
  exit $rc
}
trap rollback ERR

TMP="$(mktemp -d -t nspire-ota439-files-XXXXXX)"
cleanup(){ rm -rf "$TMP"; }
trap cleanup EXIT

python3 "$PKG/install_patch.py" \
  "$STATIC/index.html" "$V4STATIC/app.css" "$V4STATIC/app.js" "$APPDIR/nspire_v4_api.py" "$TMP"
python3 -m py_compile "$TMP/nspire_v4_api.py"
if command -v node >/dev/null 2>&1; then node --check "$TMP/app.js"; fi

grep -q '<title>NSPIRE V4.39.0</title>' "$TMP/index.html"
grep -Eq "APP_VERSION[[:space:]]*=[[:space:]]*['\"]4\.39\.0['\"]" "$TMP/app.js"
grep -q 'V4.39.0 · LATAA JA PÄIVITÄ' "$TMP/app.js"
grep -q 'NSPIRE V4.39.0 reliability layer' "$TMP/app.js"
grep -q 'NSPIRE V4.39.0 stability fixes' "$TMP/app.css"
grep -q 'nspireUpdateBusy' "$TMP/app.js"
grep -q 'data-update-busy' "$TMP/app.css"
grep -Eq "^APP_VERSION[[:space:]]*=[[:space:]]*['\"]4\.39\.0['\"]" "$TMP/nspire_v4_api.py"

install -m 0644 "$TMP/index.html" "$STATIC/index.html"
install -m 0644 "$TMP/app.css" "$V4STATIC/app.css"
install -m 0644 "$TMP/app.js" "$V4STATIC/app.js"
install -m 0644 "$TMP/nspire_v4_api.py" "$APPDIR/nspire_v4_api.py"

if [[ -z "$ROOT" ]]; then
  systemctl restart nspire-v4.service
  ok=0
  for _ in $(seq 1 40); do
    if python3 - <<'PY' >/dev/null 2>&1
import json
import urllib.request
with urllib.request.urlopen('http://127.0.0.1:8093/health', timeout=2) as response:
    data = json.load(response)
assert data.get('ok') and data.get('version') == '4.39.0'
PY
    then
      ok=1
      break
    fi
    sleep 0.5
  done
  [[ "$ok" == "1" ]] || { echo "VIRHE: V4.39.0 backend ei käynnistynyt" >&2; exit 1; }
  systemctl restart kiosk-cog.service
fi

trap - ERR
trap cleanup EXIT
echo "V4.39.0 OTA-asennus OK"
