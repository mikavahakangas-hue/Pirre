#!/usr/bin/env python3
from __future__ import annotations

import re
import sys
from pathlib import Path

TARGET = "4.39.0"
ALLOWED_BASES = {"4.38.2", TARGET}
JS_MARKER = "/* NSPIRE V4.39.0 reliability layer */"
CSS_MARKER = "/* NSPIRE V4.39.0 stability fixes */"

JS_LAYER = r'''
/* NSPIRE V4.39.0 reliability layer */
(function(){
  'use strict';
  if(window.__NSPIRE_V4390__) return;
  window.__NSPIRE_V4390__=true;

  var updateState={busy:false,started:0,autoInstallClicked:false,poll:null,keepAlive:null};
  var wiredButtons=new WeakSet();
  var drawingRoots=new WeakSet();
  var drawingState=new WeakMap();

  function norm(value){return String(value||'').replace(/\s+/g,' ').trim().toUpperCase();}
  function visible(el){
    if(!el || el.hidden) return false;
    var style=window.getComputedStyle(el);
    return style.display!=='none' && style.visibility!=='hidden';
  }
  function updateText(){
    var roots=[].slice.call(document.querySelectorAll('[data-settings-tab="updates"], [data-view="updates"], #updates, .updates, .update-panel'));
    return norm(roots.map(function(el){return el.textContent||'';}).join(' '));
  }
  function allButtons(){return [].slice.call(document.querySelectorAll('button, [role="button"]'));}
  function isDownloadButton(button){
    var t=norm(button.textContent);
    if(button.dataset && (button.dataset.updateAction==='download' || button.dataset.otaAction==='download')) return true;
    return t.indexOf('LATAA')>=0 && t.indexOf('VARMUUS')<0 && t.indexOf('LOKI')<0;
  }
  function isInstallButton(button){
    var t=norm(button.textContent);
    if(button.dataset && (button.dataset.updateAction==='install' || button.dataset.otaAction==='install')) return true;
    return t.indexOf('ASENNA')>=0 || t.indexOf('PÄIVITÄ NYT')>=0;
  }
  function saverHide(){
    try{if(typeof window.hideSaver==='function') window.hideSaver();}catch(_e){}
    var saver=document.querySelector('#screensaver,#screenSaver,.screensaver,[data-saver-overlay],.saver-overlay');
    if(saver){saver.classList.remove('active','show','visible');}
  }
  function setUpdateBusy(on){
    on=!!on;
    if(updateState.busy===on) return;
    updateState.busy=on;
    document.documentElement.dataset.updateBusy=on?'1':'0';
    if(on){
      updateState.started=Date.now();
      saverHide();
      clearInterval(updateState.keepAlive);
      updateState.keepAlive=setInterval(saverHide,250);
    }else{
      clearInterval(updateState.keepAlive);
      updateState.keepAlive=null;
      clearInterval(updateState.poll);
      updateState.poll=null;
      updateState.autoInstallClicked=false;
      try{if(typeof window.activity==='function') window.activity();}catch(_e){}
    }
  }
  window.nspireUpdateBusy=function(){return updateState.busy;};

  function wrapSaver(){
    if(typeof window.showSaver==='function' && !window.showSaver.__v439Wrapped){
      var originalShow=window.showSaver;
      var wrapped=function(){if(updateState.busy){saverHide();return;}return originalShow.apply(this,arguments);};
      wrapped.__v439Wrapped=true;
      window.showSaver=wrapped;
    }
  }

  function terminalUpdateState(text){
    if(/VIRHE|EPÄONNIST|KESKEYT|TARKISTUSSUMMA.*EI|PERUTTU/.test(text)) return 'error';
    if(/KÄYNNISTETÄÄN UUDELLEEN|ASENNETAAN|PURETAAN|TARKISTETAAN PAKETTIA/.test(text)) return 'installing';
    if(/EI UUTTA PÄIVITYSTÄ|AJAN TASALLA/.test(text)) return 'idle';
    return '';
  }

  function beginAutoInstall(){
    setUpdateBusy(true);
    clearInterval(updateState.poll);
    updateState.poll=setInterval(function(){
      wireUpdateControls();
      wrapSaver();
      saverHide();
      var text=updateText();
      var terminal=terminalUpdateState(text);
      if(terminal==='error' || terminal==='idle') {setUpdateBusy(false);return;}
      var install=allButtons().find(function(button){return isInstallButton(button);});
      if(install && !install.disabled && !updateState.autoInstallClicked){
        var ready=/LADATTU|VALMIS ASENNETTAVAKSI|ASENNA|PAKETTI.*VALMIS/.test(text);
        var download=allButtons().find(function(button){return isDownloadButton(button) && button!==install;});
        if(ready || (download && download.disabled)){
          updateState.autoInstallClicked=true;
          install.click();
        }
      }
      if(Date.now()-updateState.started>5*60*1000) setUpdateBusy(false);
    },400);
  }

  function wireUpdateControls(){
    var buttons=allButtons();
    var download=buttons.find(function(button){return isDownloadButton(button) && !isInstallButton(button);});
    var install=buttons.find(function(button){return isInstallButton(button);});

    if(download){
      if(norm(download.textContent)!=='LATAA JA PÄIVITÄ') download.textContent='LATAA JA PÄIVITÄ';
      download.dataset.v439UnifiedUpdate='1';
      if(!wiredButtons.has(download)){
        wiredButtons.add(download);
        download.addEventListener('click',function(){
          updateState.autoInstallClicked=false;
          beginAutoInstall();
        },true);
      }
    }
    if(install && download && install!==download){
      install.dataset.v439SecondaryUpdate='1';
      install.setAttribute('aria-hidden','true');
      install.tabIndex=-1;
    }
  }

  function activeDrawRoot(){
    var roots=[].slice.call(document.querySelectorAll('[data-view="draw"],#view-draw,.view-draw,.draw-view'));
    return roots.find(visible) || roots[0] || null;
  }
  function mainCanvas(root){
    var canvases=[].slice.call(root.querySelectorAll('canvas'));
    canvases.sort(function(a,b){return (b.clientWidth*b.clientHeight)-(a.clientWidth*a.clientHeight);});
    return canvases[0]||null;
  }
  function syncCanvas(canvas){
    var rect=canvas.getBoundingClientRect();
    var w=Math.max(1,Math.round(rect.width));
    var h=Math.max(1,Math.round(rect.height));
    if(!canvas.width || !canvas.height){canvas.width=w;canvas.height=h;return;}
    if(Math.abs(canvas.width-w)>2 || Math.abs(canvas.height-h)>2){
      var copy=document.createElement('canvas');copy.width=canvas.width;copy.height=canvas.height;
      copy.getContext('2d').drawImage(canvas,0,0);
      canvas.width=w;canvas.height=h;
      canvas.getContext('2d').drawImage(copy,0,0,copy.width,copy.height,0,0,w,h);
    }
  }
  function chosenColor(root,canvas){
    var input=root.querySelector('input[type="color"]');
    if(input && input.value) return input.value;
    var selected=root.querySelector('[data-draw-color].active,[data-color].active,[aria-pressed="true"][data-color]');
    if(selected) return selected.dataset.drawColor||selected.dataset.color||selected.style.backgroundColor||'#111111';
    var bg=window.getComputedStyle(canvas).backgroundColor;
    var values=(bg.match(/\d+/g)||[]).map(Number);
    if(values.length>=3 && (values[0]+values[1]+values[2])<250) return '#ffffff';
    return '#111111';
  }
  function chosenWidth(root){
    var input=root.querySelector('input[type="range"][data-draw-width],input[type="range"][name*="width"],input[type="range"][name*="size"]');
    return Math.max(1,Math.min(32,Number(input&&input.value)||4));
  }
  function canvasPoint(event,canvas){
    var rect=canvas.getBoundingClientRect();
    var x=(event.clientX-rect.left)*(canvas.width/Math.max(1,rect.width));
    var y=(event.clientY-rect.top)*(canvas.height/Math.max(1,rect.height));
    var app=document.querySelector('#app');
    var rotated=app && Number(app.dataset.rotation)===180;
    if(rotated){x=canvas.width-x;y=canvas.height-y;}
    return {x:Math.max(0,Math.min(canvas.width,x)),y:Math.max(0,Math.min(canvas.height,y))};
  }
  function wireDrawing(){
    var root=activeDrawRoot();
    if(!root || drawingRoots.has(root)) return;
    var canvas=mainCanvas(root);
    if(!canvas) return;
    drawingRoots.add(root);
    canvas.style.touchAction='none';
    syncCanvas(canvas);
    drawingState.set(canvas,{drawing:false,pointer:null});

    function handle(event){
      if(event.target!==canvas) return;
      var state=drawingState.get(canvas);
      var point=canvasPoint(event,canvas);
      var ctx=canvas.getContext('2d');
      if(event.type==='pointerdown'){
        event.preventDefault();event.stopImmediatePropagation();
        syncCanvas(canvas);point=canvasPoint(event,canvas);
        state.drawing=true;state.pointer=event.pointerId;
        try{canvas.setPointerCapture(event.pointerId);}catch(_e){}
        ctx.beginPath();ctx.moveTo(point.x,point.y);
        ctx.lineCap='round';ctx.lineJoin='round';
        ctx.strokeStyle=chosenColor(root,canvas);ctx.lineWidth=chosenWidth(root);
        ctx.lineTo(point.x+0.01,point.y+0.01);ctx.stroke();
      }else if(event.type==='pointermove' && state.drawing && state.pointer===event.pointerId){
        event.preventDefault();event.stopImmediatePropagation();
        ctx.lineTo(point.x,point.y);ctx.stroke();
      }else if((event.type==='pointerup'||event.type==='pointercancel'||event.type==='pointerleave') && state.drawing && state.pointer===event.pointerId){
        event.preventDefault();event.stopImmediatePropagation();
        ctx.closePath();state.drawing=false;state.pointer=null;
        try{canvas.releasePointerCapture(event.pointerId);}catch(_e){}
      }
    }
    ['pointerdown','pointermove','pointerup','pointercancel','pointerleave'].forEach(function(type){root.addEventListener(type,handle,true);});
    root.addEventListener('click',function(event){
      var button=event.target.closest('button,[role="button"]');
      if(!button || norm(button.textContent).indexOf('TYHJENNÄ')<0) return;
      event.preventDefault();event.stopImmediatePropagation();
      syncCanvas(canvas);canvas.getContext('2d').clearRect(0,0,canvas.width,canvas.height);
    },true);
  }

  function stabilizeScrolling(){
    [].slice.call(document.querySelectorAll('[data-view="settings"],.settings-view,.settings-content,.settings-panel,.settings-page,[data-settings-panel]')).forEach(function(el){
      el.classList.add('v439-scroll-stable');
    });
  }
  function stopHiddenMedia(){
    [].slice.call(document.querySelectorAll('video')).forEach(function(video){
      if(visible(video)) return;
      try{video.pause();}catch(_e){}
      try{if(video.srcObject && video.srcObject.getTracks) video.srcObject.getTracks().forEach(function(track){track.stop();});}catch(_e){}
      try{video.srcObject=null;}catch(_e){}
    });
  }
  function refresh(){
    wrapSaver();wireUpdateControls();wireDrawing();stabilizeScrolling();stopHiddenMedia();
    if(updateState.busy) saverHide();
  }
  var observer=new MutationObserver(refresh);
  function start(){
    refresh();
    observer.observe(document.documentElement,{subtree:true,childList:true,attributes:true,attributeFilter:['class','hidden','disabled','data-view','data-settings-tab']});
    setInterval(refresh,1500);
  }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',start,{once:true}); else start();
})();
'''

CSS_LAYER = r'''
/* NSPIRE V4.39.0 stability fixes */
.v439-scroll-stable{
  min-height:0!important;
  overflow-y:auto!important;
  overscroll-behavior:contain!important;
  touch-action:pan-y!important;
  -webkit-overflow-scrolling:touch;
}
[data-v439-unified-update="1"]{font-weight:800!important;}
[data-v439-secondary-update="1"]{display:none!important;}
html[data-update-busy="1"] #screensaver,
html[data-update-busy="1"] #screenSaver,
html[data-update-busy="1"] .screensaver,
html[data-update-busy="1"] [data-saver-overlay],
html[data-update-busy="1"] .saver-overlay{
  display:none!important;
  visibility:hidden!important;
  pointer-events:none!important;
  opacity:0!important;
}
[data-view="draw"] canvas,#view-draw canvas,.view-draw canvas,.draw-view canvas{
  touch-action:none!important;
  user-select:none!important;
  -webkit-user-select:none!important;
}
'''


def extract(pattern: str, text: str, label: str) -> str:
    match = re.search(pattern, text, flags=re.MULTILINE)
    if not match:
        raise RuntimeError(f"{label}-versionumeroa ei löytynyt")
    return match.group(1)


def replace_version(index: str, app: str, api: str) -> tuple[str, str, str, str]:
    index_version = extract(r"<title>NSPIRE V([0-9]+\.[0-9]+\.[0-9]+)</title>", index, "index.html")
    app_version = extract(r"(?:var|let|const)\s+APP_VERSION\s*=\s*['\"]([0-9]+\.[0-9]+\.[0-9]+)['\"]", app, "frontend")
    api_version = extract(r"^APP_VERSION\s*=\s*['\"]([0-9]+\.[0-9]+\.[0-9]+)['\"]", api, "backend")
    versions = {index_version, app_version, api_version}
    if len(versions) != 1:
        raise RuntimeError(f"Laitteen versiot eivät täsmää: index={index_version}, frontend={app_version}, backend={api_version}")
    current = versions.pop()
    if current not in ALLOWED_BASES:
        raise RuntimeError(f"V4.39.0 vaatii V4.38.2-pohjan, laitteessa on V{current}")
    if current == TARGET:
        return index, app, api, current

    index, n_index = re.subn(r"<title>NSPIRE V4\.38\.2</title>", f"<title>NSPIRE V{TARGET}</title>", index, count=1)
    app, n_app = re.subn(
        r"((?:var|let|const)\s+APP_VERSION\s*=\s*['\"])4\.38\.2(['\"]\s*;)",
        rf"\g<1>{TARGET}\g<2>", app, count=1, flags=re.MULTILINE,
    )
    api, n_api = re.subn(
        r"(^APP_VERSION\s*=\s*['\"])4\.38\.2(['\"])",
        rf"\g<1>{TARGET}\g<2>", api, count=1, flags=re.MULTILINE,
    )
    if (n_index, n_app, n_api) != (1, 1, 1):
        raise RuntimeError(f"Version vaihto epäonnistui: index={n_index}, frontend={n_app}, backend={n_api}")
    api = re.sub(r"Nspire V4\.38\.2 API listening", f"Nspire V{TARGET} API listening", api, count=1)
    return index, app, api, current


def patch_files(index: str, app: str, css: str, api: str) -> tuple[str, str, str, str]:
    index, app, api, _current = replace_version(index, app, api)

    release_title = "Yhden painalluksen päivitys ja vakauskorjaukset"
    if release_title not in app:
        release = (
            "  {version:'4.39.0',date:'13.07.2026',title:'Yhden painalluksen päivitys ja vakauskorjaukset',"
            "items:['Päivityksen latauspainike on nyt LATAA JA PÄIVITÄ ja asennus jatkuu automaattisesti latauksen jälkeen.',"
            "'Näytönsäästäjä ei voi käynnistyä latauksen, paketin tarkistuksen tai asennuksen aikana.',"
            "'Piirto käyttää korjattuja kosketuskoordinaatteja, pointer capturea ja toimivaa tyhjennystä myös 180 asteen näytöllä.',"
            "'Asetusnäkymien vieritys on vakautettu ja piilossa olevien videonäkymien mediavirrat pysäytetään.',"
            "'Sohva-näytönsäästäjän ulkoasua ei muutettu tässä versiossa.']},\n"
        )
        if "var RELEASES=[\n" in app:
            app = app.replace("var RELEASES=[\n", "var RELEASES=[\n" + release, 1)
        elif "var RELEASES = [\n" in app:
            app = app.replace("var RELEASES = [\n", "var RELEASES = [\n" + release, 1)
        else:
            raise RuntimeError("Muutoslokin RELEASES-listaa ei löytynyt")

    lines = app.splitlines(keepends=True)
    quick_found = False
    for i, line in enumerate(lines):
        if line.lstrip().startswith("function otaQuickActionsHtml()"):
            new_line, count = re.subn(r"<strong>.*?</strong>", "<strong>V4.39.0 · LATAA JA PÄIVITÄ</strong>", line, count=1)
            if count == 1:
                lines[i] = new_line
                quick_found = True
            break
    app = "".join(lines)
    if not quick_found and "V4.39.0 · LATAA JA PÄIVITÄ" not in app:
        raise RuntimeError("Päivitysten kiinteää yläpalkkia ei löytynyt")

    if JS_MARKER not in app:
        app = app.rstrip() + "\n\n" + JS_LAYER.strip() + "\n"
    if CSS_MARKER not in css:
        css = css.rstrip() + "\n\n" + CSS_LAYER.strip() + "\n"

    if f"<title>NSPIRE V{TARGET}</title>" not in index:
        raise RuntimeError("index.html-version lopputarkistus epäonnistui")
    if not re.search(rf"(?:var|let|const)\s+APP_VERSION\s*=\s*['\"]{re.escape(TARGET)}['\"]", app):
        raise RuntimeError("frontend-version lopputarkistus epäonnistui")
    if not re.search(rf"^APP_VERSION\s*=\s*['\"]{re.escape(TARGET)}['\"]", api, flags=re.MULTILINE):
        raise RuntimeError("backend-version lopputarkistus epäonnistui")
    for required in ["LATAA JA PÄIVITÄ", "nspireUpdateBusy", "v439-scroll-stable", "pointerdown", JS_MARKER]:
        if required not in app and required not in css:
            raise RuntimeError(f"Lopputarkistus puuttuu: {required}")
    return index, app, css, api


def main(argv: list[str]) -> int:
    if len(argv) != 6:
        raise SystemExit("usage: install_patch.py index.html app.css app.js nspire_v4_api.py workdir")
    index_path, css_path, app_path, api_path, work_path = map(Path, argv[1:])
    work_path.mkdir(parents=True, exist_ok=True)
    index, app, css, api = patch_files(
        index_path.read_text(encoding="utf-8"),
        app_path.read_text(encoding="utf-8"),
        css_path.read_text(encoding="utf-8"),
        api_path.read_text(encoding="utf-8"),
    )
    (work_path / "index.html").write_text(index, encoding="utf-8")
    (work_path / "app.css").write_text(css, encoding="utf-8")
    (work_path / "app.js").write_text(app, encoding="utf-8")
    (work_path / "nspire_v4_api.py").write_text(api, encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
