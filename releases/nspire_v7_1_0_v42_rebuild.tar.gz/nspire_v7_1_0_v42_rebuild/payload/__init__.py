"""NSPIRE V6 clean runtime."""
__version__ = "7.1.0"
