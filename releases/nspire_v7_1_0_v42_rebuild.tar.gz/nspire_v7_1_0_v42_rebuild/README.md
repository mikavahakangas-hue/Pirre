# NSPIRE V7.1.0

Korjaava ja laajentava päivitys käyttäjän toimittaman V7.0.0-laitedumpin pohjalta.
Päivitys korvaa tarkistetut käyttöliittymä- ja backend-tiedostot, tekee varmuuskopion ja palauttaa kaikki tiedostot automaattisesti, jos asennus- tai health-tarkistus epäonnistuu.

Valvontakamera on päivityksen jälkeen aina pois päältä. Se käynnistetään Kamera → VALVONTA -välilehdeltä, ja käynnistys vaatii onnistuneen kameratestin.
