#!/usr/bin/env bash
set -Eeuo pipefail
umask 022
export PYTHONDONTWRITEBYTECODE=1

PKG_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
VERSION="7.1.0"
LIVE="${NSPIRE_LIVE:-/opt/nspire-v6}"
STATIC="$LIVE/static"
INIT="$LIVE/nspire/__init__.py"
SERVER="$LIVE/server.py"
CSS="$STATIC/app.css"
INDEX="$STATIC/index.html"
APPJS="$STATIC/app.js"
SAVER="$STATIC/screensaver.html"
BACKUP_ROOT="${NSPIRE_BACKUP_ROOT:-/root/nspire-backup}"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="$BACKUP_ROOT/v7_1_0_v42_rebuild_before_${STAMP}"
LOG="${NSPIRE_LOG:-/var/log/nspire-v6-update.log}"
SYSTEMCTL="${SYSTEMCTL:-systemctl}"
CURL="${CURL:-curl}"
SLEEP="${SLEEP:-sleep}"
SUCCESS=0
BACKEND_WAS_ACTIVE=0
KIOSK_WAS_ACTIVE=0
BME_WAS_ACTIVE=0
CURRENT_VERSION="tuntematon"
PHASE="alustus"

say(){ printf '%s [%s] %s\n' "$(date -Is)" "$PHASE" "$*" | tee -a "$LOG"; }
fail(){ say "VIRHE: $*"; return 1; }

[[ ${EUID:-$(id -u)} -eq 0 ]] || { echo "Aja asennin root-oikeuksilla." >&2; exit 1; }
for cmd in python3 sha256sum cp install mkdir rm grep tee "$SYSTEMCTL" "$CURL" "$SLEEP"; do command -v "$cmd" >/dev/null 2>&1 || { echo "Komento puuttuu: $cmd" >&2; exit 1; }; done
for file in "$INIT" "$SERVER" "$CSS" "$INDEX" "$APPJS"; do [[ -f "$file" ]] || { echo "Tiedosto puuttuu: $file" >&2; exit 1; }; done
mkdir -p "$(dirname "$LOG")" "$BACKUP_ROOT"
cd "$PKG_DIR"
PHASE="paketin tarkistus"
sha256sum -c SHA256SUMS
bash -n install.sh selftest.sh
python3 -m py_compile payload/server.py payload/__init__.py
if command -v node >/dev/null 2>&1; then node --check payload/app.js; fi

CURRENT_VERSION="$(python3 - "$INIT" <<'PY'
from pathlib import Path
import re,sys
m=re.search(r'(?m)^\s*__version__\s*=\s*["\']([^"\']+)["\']',Path(sys.argv[1]).read_text(encoding='utf-8'))
print(m.group(1) if m else '')
PY
)"
case "$CURRENT_VERSION" in 6.1.2|6.2.0|7.0.0|7.1.0) ;; *) fail "Päivitys vaatii tuetun V6.1.2–V7.1.0-version. Nykyinen: ${CURRENT_VERSION:-tuntematon}" ;; esac

"$SYSTEMCTL" is-active --quiet nspire-v6.service && BACKEND_WAS_ACTIVE=1 || true
"$SYSTEMCTL" is-active --quiet nspire-kiosk.service && KIOSK_WAS_ACTIVE=1 || true
"$SYSTEMCTL" is-active --quiet nspire-bme680.service && BME_WAS_ACTIVE=1 || true
[[ "$BME_WAS_ACTIVE" -eq 1 ]] || fail "Sisäilmapalvelu ei ole käynnissä"
"$CURL" -fsS --noproxy '*' --connect-timeout 2 --max-time 6 http://127.0.0.1:8766/health >/dev/null || fail "Sisäilmapalvelun health-tarkistus epäonnistui"

mkdir -p "$BACKUP"
for pair in "$INIT:__init__.py" "$SERVER:server.py" "$CSS:app.css" "$INDEX:index.html" "$APPJS:app.js" "$SAVER:screensaver.html"; do
  src="${pair%%:*}"; dst="${pair##*:}"
  if [[ -e "$src" ]]; then cp -a "$src" "$BACKUP/$dst"; else printf 'missing\n' > "$BACKUP/$dst.missing"; fi
done
sha256sum "$INIT" "$SERVER" "$CSS" "$INDEX" "$APPJS" > "$BACKUP/before.sha256"

stop_unit(){
  local unit="$1"
  "$SYSTEMCTL" kill --kill-who=all --signal=SIGTERM "$unit" >/dev/null 2>&1 || true
  for _ in $(seq 1 20); do "$SYSTEMCTL" is-active --quiet "$unit" || return 0; "$SLEEP" 0.25; done
  "$SYSTEMCTL" stop "$unit" >/dev/null 2>&1 || true
  for _ in $(seq 1 20); do "$SYSTEMCTL" is-active --quiet "$unit" || return 0; "$SLEEP" 0.25; done
  "$SYSTEMCTL" kill --kill-who=all --signal=SIGKILL "$unit" >/dev/null 2>&1 || true
  "$SYSTEMCTL" stop "$unit" >/dev/null 2>&1 || true
  "$SYSTEMCTL" is-active --quiet "$unit" && return 1 || return 0
}

restore(){
  local code=$?
  [[ "$SUCCESS" -eq 1 ]] && return 0
  trap - ERR INT TERM EXIT
  PHASE="palautus"; say "Asennus epäonnistui — palautetaan V$CURRENT_VERSION"
  stop_unit nspire-kiosk.service || true
  stop_unit nspire-v6.service || true
  for pair in "$INIT:__init__.py" "$SERVER:server.py" "$CSS:app.css" "$INDEX:index.html" "$APPJS:app.js" "$SAVER:screensaver.html"; do
    dst="${pair%%:*}"; src="${pair##*:}"
    if [[ -f "$BACKUP/$src" ]]; then cp -a "$BACKUP/$src" "$dst"; elif [[ -f "$BACKUP/$src.missing" ]]; then rm -f "$dst"; fi
  done
  rm -rf "$LIVE/nspire/__pycache__" >/dev/null 2>&1 || true
  "$SYSTEMCTL" reset-failed nspire-v6.service nspire-kiosk.service >/dev/null 2>&1 || true
  [[ "$BACKEND_WAS_ACTIVE" -eq 1 ]] && "$SYSTEMCTL" start nspire-v6.service >/dev/null 2>&1 || true
  [[ "$KIOSK_WAS_ACTIVE" -eq 1 ]] && "$SYSTEMCTL" start nspire-kiosk.service >/dev/null 2>&1 || true
  say "Palautus valmis: $BACKUP"; exit "$code"
}
trap restore ERR INT TERM EXIT

PHASE="palvelujen pysäytys"
[[ "$KIOSK_WAS_ACTIVE" -eq 1 ]] && stop_unit nspire-kiosk.service || true
[[ "$BACKEND_WAS_ACTIVE" -eq 1 ]] && stop_unit nspire-v6.service || true

PHASE="tiedostojen asennus"
install -m 0644 payload/__init__.py "$INIT"
install -m 0755 payload/server.py "$SERVER"
install -m 0644 payload/app.css "$CSS"
install -m 0644 payload/index.html "$INDEX"
install -m 0644 payload/app.js "$APPJS"
install -m 0644 payload/screensaver.html "$SAVER"
rm -rf "$LIVE/nspire/__pycache__" >/dev/null 2>&1 || true
python3 -m py_compile "$INIT" "$SERVER"
if command -v node >/dev/null 2>&1; then node --check "$APPJS"; fi

grep -q 'NSPIRE V7.1.0 V4.2 IDEAS REBUILD START' "$APPJS"
grep -q 'window.NSPIRE_RENDERERS' "$APPJS"
grep -q 'data-v710-camera-tab="guard"' "$APPJS"
grep -q '/api/camera/surveillance' "$SERVER"
grep -q 'v710-sleep-fullscreen' "$CSS"
grep -q '/app.js?v=710' "$INDEX"
grep -q 'nspire.v710.saver' "$SAVER"

PHASE="backendin käynnistys"
"$SYSTEMCTL" reset-failed nspire-v6.service nspire-kiosk.service >/dev/null 2>&1 || true
"$SYSTEMCTL" start nspire-v6.service
for _ in $(seq 1 60); do
  if "$SYSTEMCTL" is-active --quiet nspire-v6.service && "$CURL" -fsS --noproxy '*' --connect-timeout 2 --max-time 5 http://127.0.0.1:8765/api/health >/dev/null 2>&1; then break; fi
  "$SLEEP" 1
done
"$SYSTEMCTL" is-active --quiet nspire-v6.service || fail "Backend ei käynnistynyt"
"$CURL" -fsS --noproxy '*' --connect-timeout 2 --max-time 6 http://127.0.0.1:8765/api/health | python3 -c 'import json,sys;d=json.load(sys.stdin);sys.exit(0 if d.get("ok") is True and str(d.get("version"))=="7.1.0" else 1)' || fail "Backend ei ilmoita versiota V7.1.0"
"$CURL" -fsS --noproxy '*' --connect-timeout 2 --max-time 8 http://127.0.0.1:8765/api/camera/surveillance | python3 -c 'import json,sys;d=json.load(sys.stdin);sys.exit(0 if d.get("ok") is True and d.get("armed") is False else 1)' || fail "Valvontakameran turvallinen alkutila epäonnistui"

PHASE="frontendin tarkistus"
TMP_ROOT="$(mktemp)"; TMP_JS="$(mktemp)"; TMP_CSS="$(mktemp)"; TMP_SAVER="$(mktemp)"
trap 'rm -f "$TMP_ROOT" "$TMP_JS" "$TMP_CSS" "$TMP_SAVER"; restore' ERR INT TERM EXIT
"$CURL" -fsS --noproxy '*' --connect-timeout 2 --max-time 8 http://127.0.0.1:8765/ > "$TMP_ROOT"
"$CURL" -fsS --noproxy '*' --connect-timeout 2 --max-time 8 'http://127.0.0.1:8765/app.js?v=710' > "$TMP_JS"
"$CURL" -fsS --noproxy '*' --connect-timeout 2 --max-time 8 'http://127.0.0.1:8765/app.css?v=710' > "$TMP_CSS"
"$CURL" -fsS --noproxy '*' --connect-timeout 2 --max-time 8 'http://127.0.0.1:8765/screensaver.html' > "$TMP_SAVER"
grep -q '/app.js?v=710' "$TMP_ROOT"
grep -q 'window.NSPIRE_RENDERERS' "$TMP_JS"
grep -q 'R.camera=' "$TMP_JS"
grep -q 'R.weather=' "$TMP_JS"
grep -q 'R.sleepclock=' "$TMP_JS"
grep -q 'v710-camera-stage' "$TMP_CSS"
grep -q 'nspire.v710.saver' "$TMP_SAVER"
rm -f "$TMP_ROOT" "$TMP_JS" "$TMP_CSS" "$TMP_SAVER"
trap restore ERR INT TERM EXIT

PHASE="kioskin käynnistys"
if [[ "$KIOSK_WAS_ACTIVE" -eq 1 ]]; then
  "$SYSTEMCTL" start nspire-kiosk.service
  for _ in $(seq 1 40); do "$SYSTEMCTL" is-active --quiet nspire-kiosk.service && break; "$SLEEP" 1; done
  "$SYSTEMCTL" is-active --quiet nspire-kiosk.service || fail "Cog-kioski ei käynnistynyt"
fi

PHASE="vakaustarkistus"
for _ in 1 2 3; do
  "$SYSTEMCTL" is-active --quiet nspire-v6.service || fail "Backend pysähtyi vakaustarkistuksessa"
  "$SYSTEMCTL" is-active --quiet nspire-bme680.service || fail "Sisäilmapalvelu pysähtyi vakaustarkistuksessa"
  "$CURL" -fsS --noproxy '*' --connect-timeout 2 --max-time 5 http://127.0.0.1:8765/api/status >/dev/null || fail "Status-rajapinta ei vastaa"
  "$CURL" -fsS --noproxy '*' --connect-timeout 2 --max-time 5 http://127.0.0.1:8765/api/camera/status >/dev/null || fail "Kameran status ei vastaa"
  [[ "$KIOSK_WAS_ACTIVE" -eq 0 ]] || "$SYSTEMCTL" is-active --quiet nspire-kiosk.service || fail "Kioski pysähtyi"
  "$SLEEP" 4
done

sha256sum "$INIT" "$SERVER" "$CSS" "$INDEX" "$APPJS" "$SAVER" > "$BACKUP/after.sha256"
SUCCESS=1; trap - ERR INT TERM EXIT
PHASE="valmis"
say "V7.1.0 asennus OK · sovellusreititys, Kamera/Valvonta, Sää, Unikello ja näytönsäästäjä · lähtöversio V$CURRENT_VERSION · varmuuskopio=$BACKUP"
