#!/usr/bin/env python3
from pathlib import Path
import sys

if len(sys.argv) != 6:
    raise SystemExit('usage: patch.py index app.js app.css api.py target_version')
index_p, js_p, css_p, api_p, target = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3]), Path(sys.argv[4]), sys.argv[5]
source = '4.42.5'

css = css_p.read_text(encoding='utf-8')
js = js_p.read_text(encoding='utf-8')
api = api_p.read_text(encoding='utf-8')

if f"APP_VERSION='{source}'" not in js:
    raise SystemExit('source JS version mismatch')
if f'APP_VERSION = "{source}"' not in api:
    raise SystemExit('source API version mismatch')
marker = '/* NSPIRE UI V4.42.5 — direct component rules */'
if marker not in css:
    raise SystemExit('V4.42.5 CSS marker missing')

old_tile = '''.app-tile::before{left:18px!important;right:18px!important;height:3px!important;background:var(--tile-accent,var(--accent))!important;border:0!important;opacity:.88!important;box-shadow:none!important}
.app-tile:active{background:color-mix(in srgb,var(--tile-accent,var(--accent)) 10%,var(--surface))!important;border-color:color-mix(in srgb,var(--tile-accent,var(--accent)) 68%,var(--line))!important;transform:translateY(1px)!important}
'''
new_tile = '''.app-tile::before{left:18px!important;right:18px!important;height:3px!important;background:var(--tile-accent,var(--accent))!important;border:0!important;opacity:0!important;box-shadow:none!important;transition:opacity .12s ease!important}
.app-tile:active::before,.app-tile:focus-visible::before{opacity:.92!important}
.app-tile:focus-visible{outline:2px solid var(--tile-accent,var(--accent))!important;outline-offset:2px!important}
.app-tile:active{background:color-mix(in srgb,var(--tile-accent,var(--accent)) 10%,var(--surface))!important;border-color:color-mix(in srgb,var(--tile-accent,var(--accent)) 68%,var(--line))!important;transform:translateY(1px)!important}
'''
if old_tile not in css:
    raise SystemExit('V4.42.5 app-tile block missing')
css = css.replace(old_tile, new_tile, 1)

old_swatch = '''.theme-swatch.active{border-color:var(--accent)!important;box-shadow:inset 0 0 0 2px var(--surface),0 0 0 2px var(--accent),0 3px 8px color-mix(in srgb,var(--accent) 30%,transparent)!important}
.theme-swatch.active::after{content:"✓";position:absolute;right:6px;top:5px;width:18px;height:18px;border-radius:50%;display:grid;place-items:center;background:var(--accent);color:#fff;font-size:12px;font-weight:900;text-shadow:none}
'''
new_swatch = '''.theme-swatch.active{border-color:var(--accent)!important;box-shadow:inset 0 0 0 3px var(--surface),0 0 0 3px var(--accent),0 4px 10px color-mix(in srgb,var(--accent) 38%,transparent)!important;transform:translateY(-1px)!important}
.theme-swatch.active::after{content:"✓";position:absolute;right:6px;top:5px;width:20px;height:20px;border-radius:50%;display:grid;place-items:center;background:var(--accent);color:#fff;font-size:13px;font-weight:950;text-shadow:none;border:2px solid var(--surface);box-shadow:0 2px 5px rgba(0,0,0,.28)}
'''
if old_swatch not in css:
    raise SystemExit('V4.42.5 theme-swatch block missing')
css = css.replace(old_swatch, new_swatch, 1)

anchor = '''#app[data-theme^="light-"] .app-tile,#app[data-theme^="light-"] .home-live,#app[data-theme^="light-"] .setting-row,#app[data-theme^="light-"] .ota-hero,#app[data-theme^="light-"] .ota-card>div,#app[data-theme^="light-"] .ota-quick,#app[data-theme^="light-"] .update-manifest-card{box-shadow:0 2px 7px rgba(0,0,0,.10)!important;border-color:color-mix(in srgb,var(--line) 68%,var(--text) 32%)!important}
'''
addition = '''#app[data-theme^="light-"] .app-tile strong,#app[data-theme^="light-"] .home-live strong,#app[data-theme^="light-"] .setting-row strong,#app[data-theme^="light-"] .ota-hero strong,#app[data-theme^="light-"] .ota-card b,#app[data-theme^="light-"] .update-manifest-card strong{color:color-mix(in srgb,var(--text) 94%,#000)!important}
#app[data-theme^="light-"] .app-tile small,#app[data-theme^="light-"] .home-live small,#app[data-theme^="light-"] .setting-row small,#app[data-theme^="light-"] .ota-hero span,#app[data-theme^="light-"] .ota-hero small,#app[data-theme^="light-"] .ota-card span,#app[data-theme^="light-"] .update-manifest-card small{color:color-mix(in srgb,var(--muted) 78%,var(--text) 22%)!important;font-weight:650!important}
/* NSPIRE UI V4.42.6 — final visual polish */
'''
if anchor not in css:
    raise SystemExit('V4.42.5 light-theme anchor missing')
css = css.replace(anchor, anchor + addition, 1)

js = js.replace(f"var APP_VERSION='{source}';", f"var APP_VERSION='{target}';", 1)
release = "  {version:'4.42.6',date:'14.07.2026',title:'Visuaalinen viimeistely',items:['Passiivisten etusivukorttien korostusviivat poistettiin.','Kortin korostus näkyy vain painettaessa tai kohdistettaessa.','Vaaleiden teemojen tekstikontrastia vahvistettiin.','Teemasivun aktiivinen valinta erottuu aiempaa selvemmin.']},\n"
needle = "  {version:'4.42.5',"
pos = js.find(needle)
if pos < 0:
    raise SystemExit('release insertion point missing')
js = js[:pos] + release + js[pos:]
api = api.replace(f'APP_VERSION = "{source}"', f'APP_VERSION = "{target}"', 1)
api = api.replace(f'Nspire V{source} API listening', f'Nspire V{target} API listening', 1)

css_p.write_text(css, encoding='utf-8')
js_p.write_text(js, encoding='utf-8')
api_p.write_text(api, encoding='utf-8')
