#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"
sha256sum -c SHA256SUMS
bash -n install.sh selftest.sh
NSPIRE_V610_PARTS_DIR="${NSPIRE_V610_PARTS_DIR:-/mnt/data/v610parts}" \
NSPIRE_BOOTSTRAP_VERIFY_ONLY=1 ./install.sh
echo "V6.1.0 BOOTSTRAP SELFTEST OK"
