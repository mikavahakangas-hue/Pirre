# NSPIRE V6.1.0 Sisäilma – varmennettu latauspaketti

Tämä pieni OTA-paketti hakee V6.1.0 Sisäilma -julkaisun kahdeksana
GitHubiin lukittuna tekstiosana. Osat yhdistetään laitteella, minkä jälkeen
koko sisäpaketin koko, SHA-256-tarkistussumma ja tar-rakenne tarkistetaan
ennen varsinaisen asennusohjelman käynnistämistä.

Sisäpaketti lisää BME680-palvelun, Sisäilma-sovelluksen, reaaliaikaisen
värillisen ilmanlaatumittarin, historian ja anturin asetukset. NSPIRE:n
0–100 ilmanlaatuarvio ei ole Bosch BSEC -arvo eikä terveysmittaus.
