#!/usr/bin/env bash
set -Eeuo pipefail
umask 077

VERSION="6.1.0"
SOURCE_COMMIT="570ab45127042b17d77a7e14f5c15e2b0ee2f9f2"
BASE_URL_DEFAULT="https://raw.githubusercontent.com/mikavahakangas-hue/Pirre/${SOURCE_COMMIT}/releases/v6.1.0"
BASE_URL="${NSPIRE_V610_BASE_URL:-$BASE_URL_DEFAULT}"
PARTS_DIR="${NSPIRE_V610_PARTS_DIR:-}"
FULL_SHA="09cd618d4995181c1b1ded2b2d9f8f0d76fb447c77c2cb7f95385832a703b667"
FULL_SIZE="29495"
ARCHIVE_NAME="nspire_v6_1_0_bme680_indoor_air.tar.gz"
INNER_DIR="nspire_v6_1_0_bme680_indoor_air"
VERIFY_ONLY="${NSPIRE_BOOTSTRAP_VERIFY_ONLY:-0}"
TMP=""

log() { printf '[V6.1.0 lataus] %s\n' "$*"; }
die() { printf '[V6.1.0 lataus] VIRHE: %s\n' "$*" >&2; exit 1; }
cleanup() { [[ -z "$TMP" ]] || rm -rf -- "$TMP"; }
trap cleanup EXIT INT TERM

for cmd in base64 cat chmod cmp curl mkdir mktemp sha256sum stat tar tr; do
  command -v "$cmd" >/dev/null 2>&1 || die "Komento puuttuu: $cmd"
done

TMP="$(mktemp -d /tmp/nspire-v610-bootstrap.XXXXXX)"
mkdir -p "$TMP/parts" "$TMP/unpack"

copy_or_download_part() {
  local num="$1"
  local long_name="${ARCHIVE_NAME}.b64.part${num}"
  local target="$TMP/parts/part${num}"
  local source=""

  if [[ -n "$PARTS_DIR" ]]; then
    if [[ -f "$PARTS_DIR/part${num}" ]]; then
      source="$PARTS_DIR/part${num}"
    elif [[ -f "$PARTS_DIR/$long_name" ]]; then
      source="$PARTS_DIR/$long_name"
    else
      die "Paikallinen osa puuttuu: $num"
    fi
    cat -- "$source" > "$target"
  else
    curl -fL --retry 3 --retry-delay 1 --connect-timeout 10 --max-time 60 \
      "$BASE_URL/$long_name" -o "$target"
  fi

  [[ -s "$target" ]] || die "Tyhjä latausosa: $num"
  case "$(stat -c %s "$target")" in
    5000) [[ "$num" != "08" ]] || die "Osa 08 on väärän kokoinen" ;;
    4328) [[ "$num" == "08" ]] || die "Osa $num on väärän kokoinen" ;;
    *) die "Osa $num on väärän kokoinen: $(stat -c %s "$target") tavua" ;;
  esac
}

log "Haetaan varmennetut julkaisuosat"
for num in 01 02 03 04 05 06 07 08; do
  copy_or_download_part "$num"
done

cat "$TMP"/parts/part{01,02,03,04,05,06,07,08} | tr -d '\r\n' > "$TMP/package.b64"
base64 --decode "$TMP/package.b64" > "$TMP/$ARCHIVE_NAME" || die "Base64-purku epäonnistui"

actual_size="$(stat -c %s "$TMP/$ARCHIVE_NAME")"
[[ "$actual_size" == "$FULL_SIZE" ]] || die "Sisäpaketin koko on $actual_size, odotettiin $FULL_SIZE"
printf '%s  %s\n' "$FULL_SHA" "$TMP/$ARCHIVE_NAME" | sha256sum -c - >/dev/null \
  || die "Sisäpaketin SHA-256 ei täsmää"
tar -tzf "$TMP/$ARCHIVE_NAME" >/dev/null || die "Sisäpaketin tar-rakenne on vioittunut"
tar -xzf "$TMP/$ARCHIVE_NAME" -C "$TMP/unpack"

INNER="$TMP/unpack/$INNER_DIR"
[[ -x "$INNER/install.sh" ]] || die "Sisäpaketin install.sh puuttuu"
[[ -x "$INNER/selftest.sh" ]] || die "Sisäpaketin selftest.sh puuttuu"
[[ "$(cat "$INNER/VERSION")" == "$VERSION" ]] || die "Sisäpaketin versionumero ei täsmää"

log "Lataus, koko, SHA-256 ja rakenne kunnossa"
if [[ "$VERIFY_ONLY" == "1" ]]; then
  log "Varmennustila valmis – järjestelmään ei tehty muutoksia"
  exit 0
fi

log "Käynnistetään V6.1.0 Sisäilma -asennus"
cd "$INNER"
exec ./install.sh
