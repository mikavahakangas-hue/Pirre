#!/usr/bin/env python3
from pathlib import Path
import re
import sys

if len(sys.argv) != 8:
    raise SystemExit("Käyttö: patch.py index js css api theme source_version target_version")

index_p, js_p, css_p, api_p, theme_p = map(Path, sys.argv[1:6])
source_version, target_version = sys.argv[6:8]
index = index_p.read_text(encoding="utf-8")
js = js_p.read_text(encoding="utf-8")
css = css_p.read_text(encoding="utf-8")
api = api_p.read_text(encoding="utf-8")
theme = theme_p.read_text(encoding="utf-8")

source_js = f"APP_VERSION='{source_version}'"
target_js = f"APP_VERSION='{target_version}'"
source_api = f'APP_VERSION = "{source_version}"'
target_api = f'APP_VERSION = "{target_version}"'

if target_js in js and target_api in api and f"NSPIRE UI V{target_version}" in css:
    print(f"V{target_version} on jo asennettu")
    raise SystemExit(0)
if source_js not in js or source_api not in api:
    raise SystemExit(f"VIRHE: päivitys vaatii toimivan V{source_version}-pohjan")

index = index.replace(f"V{source_version}", f"V{target_version}")
index = index.replace(f"v={source_version}", f"v={target_version}")
js = js.replace(source_js, target_js, 1)
api = api.replace(source_api, target_api, 1)
api = api.replace(f"Nspire V{source_version} API", f"Nspire V{target_version} API")

entry = (
    f"  {{version:'{target_version}',date:'14.07.2026',title:'18 viimeisteltyä teemaa ja SOHVA 2.2',"
    "items:['Jokaisella teemalla on nyt oma täydellinen väri- ja materiaalikartta.',"
    "'Tummat ja vaaleat teemat erottuvat toisistaan myös taustoilla ja pinnoilla.',"
    "'SOHVA-näkymän päivämäärä, lämpötilat ja alarivi on tasapainotettu.',"
    "'Etusivun rakenne ja toimiva OTA-ketju säilyvät ennallaan.']},\n"
)
needle = "var RELEASES=[\n"
if entry not in js:
    if needle not in js:
        raise SystemExit("VIRHE: RELEASES-rakenne puuttuu")
    js = js.replace(needle, needle + entry, 1)

colors = {
    "dark-ocean": ["#070d14", "#101d2a", "#42a5ff"],
    "dark-graphite": ["#0d0f11", "#1d2125", "#c2c8cf"],
    "dark-forest": ["#07100b", "#122319", "#4ec97f"],
    "dark-amber": ["#140c05", "#281a0d", "#f0a13d"],
    "dark-violet": ["#0d0715", "#21162e", "#ad7cff"],
    "dark-crimson": ["#13070a", "#29131a", "#ef5d78"],
    "dark-teal": ["#041011", "#0d2425", "#36c2bd"],
    "dark-navy": ["#05091a", "#101a39", "#7198ff"],
    "dark-mono": ["#030303", "#121212", "#ffffff"],
    "light-windows": ["#f2f2f2", "#ffffff", "#0067c0"],
    "light-paper": ["#f5f1e8", "#fffdf8", "#506b7e"],
    "light-warm": ["#fbf0e2", "#fffaf3", "#b85100"],
    "light-cool": ["#eaf3f8", "#ffffff", "#0078d4"],
    "light-mint": ["#eaf6ef", "#ffffff", "#087c55"],
    "light-lilac": ["#f3edfa", "#ffffff", "#7042b3"],
    "light-rose": ["#faedf1", "#ffffff", "#aa3f5d"],
    "light-sand": ["#f2ebdc", "#fffdf7", "#7d5e17"],
    "light-contrast": ["#ffffff", "#f5f5f5", "#003fbd"],
}
mi = js.find("var THEME_SWATCHES=")
me = js.find(";\nfunction renderThemeSwatches", mi)
if mi < 0 or me < 0:
    raise SystemExit("VIRHE: teemakarttaa ei löytynyt")
js = js[:mi] + "var THEME_SWATCHES=" + repr(colors) + js[me:]

for marker in ["/* NSPIRE UI V4.42.1", "/* NSPIRE UI V4.42.2", "/* NSPIRE UI V4.42.3"]:
    if marker in css:
        css = css.split(marker, 1)[0].rstrip() + "\n\n"
css += theme.rstrip() + "\n"

index_p.write_text(index, encoding="utf-8")
js_p.write_text(js, encoding="utf-8")
css_p.write_text(css, encoding="utf-8")
api_p.write_text(api, encoding="utf-8")
print(f"V{target_version} tiedostot päivitetty")
