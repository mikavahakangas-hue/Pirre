#!/usr/bin/env bash
set -Eeuo pipefail

BASE=/opt/nspire-ui/static
API=/opt/nspire-v4/nspire_v4_api.py
SELF="$(cd "$(dirname "$0")" && pwd)"
SOURCE_VERSION=4.42.2
TARGET_VERSION="$(tr -d '[:space:]' < "$SELF/VERSION")"
STATE_DIR=/home/mavks/.local/share/nspire-v4

for f in "$BASE/index.html" "$BASE/v4/app.js" "$BASE/v4/app.css" "$API" "$SELF/patch.py" "$SELF/theme-v4423.css"; do
  test -f "$f" || { echo "VIRHE: puuttuu $f"; exit 1; }
done
[[ "$TARGET_VERSION" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]] || { echo "VIRHE: virheellinen VERSION"; exit 1; }

reset_update_state() {
  local final_state="${1:-idle}"
  python3 - "$STATE_DIR" "$final_state" <<'PY'
import json, sys, time
from pathlib import Path
root = Path(sys.argv[1])
final_state = sys.argv[2]
root.mkdir(parents=True, exist_ok=True)
for name in ("update-state.json", "update-install-status.json"):
    path = root / name
    try:
        data = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}
    except Exception:
        data = {}
    if not isinstance(data, dict):
        data = {}
    if name == "update-state.json":
        data["operation"] = "idle"
        data["operation_message"] = ""
        data["error"] = ""
        data["install_scheduled_ts"] = 0
        data["install_path"] = ""
    else:
        data.update({
            "state": final_state,
            "title": "",
            "message": "",
            "progress": 0,
            "error": "",
            "acknowledged": True,
            "acknowledged_ts": int(time.time()),
        })
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    tmp.replace(path)
PY
}

if [[ "${NSPIRE_PREFLIGHT_ONLY:-0}" == 1 ]]; then
  TMP=$(mktemp -d -t nspire-v4423-preflight-XXXXXX)
  trap 'rm -rf "$TMP"' EXIT
  cp "$BASE/index.html" "$TMP/index.html"
  cp "$BASE/v4/app.js" "$TMP/app.js"
  cp "$BASE/v4/app.css" "$TMP/app.css"
  cp "$API" "$TMP/api.py"
  python3 "$SELF/patch.py" "$TMP/index.html" "$TMP/app.js" "$TMP/app.css" "$TMP/api.py" "$SELF/theme-v4423.css" "$SOURCE_VERSION" "$TARGET_VERSION"
  node --check "$TMP/app.js" >/dev/null
  python3 -m py_compile "$TMP/api.py"
  grep -Fq "APP_VERSION='$TARGET_VERSION'" "$TMP/app.js"
  grep -Fq "APP_VERSION = \"$TARGET_VERSION\"" "$TMP/api.py"
  grep -Fq "NSPIRE UI V$TARGET_VERSION" "$TMP/app.css"
  echo "V$TARGET_VERSION OTA-esitarkistus OK"
  exit 0
fi

STAMP=$(date +%Y%m%d-%H%M%S)
BACK="/root/nspire-backup/ota_before_${TARGET_VERSION//./_}_$STAMP"
mkdir -p "$BACK/static/v4" "$BACK/api"
cp -a "$BASE/index.html" "$BACK/static/index.html"
cp -a "$BASE/v4/app.js" "$BACK/static/v4/app.js"
cp -a "$BASE/v4/app.css" "$BACK/static/v4/app.css"
cp -a "$API" "$BACK/api/nspire_v4_api.py"

rollback() {
  local rc=$?
  trap - ERR
  set +e
  echo "VIRHE: V$TARGET_VERSION epäonnistui, palautetaan V$SOURCE_VERSION"
  cp -a "$BACK/static/index.html" "$BASE/index.html"
  cp -a "$BACK/static/v4/app.js" "$BASE/v4/app.js"
  cp -a "$BACK/static/v4/app.css" "$BASE/v4/app.css"
  cp -a "$BACK/api/nspire_v4_api.py" "$API"
  systemctl restart nspire-v4.service
  systemctl restart kiosk-cog.service
  reset_update_state idle
  exit "$rc"
}
trap rollback ERR

python3 "$SELF/patch.py" "$BASE/index.html" "$BASE/v4/app.js" "$BASE/v4/app.css" "$API" "$SELF/theme-v4423.css" "$SOURCE_VERSION" "$TARGET_VERSION"
node --check "$BASE/v4/app.js" >/dev/null
python3 -m py_compile "$API"
systemctl restart nspire-v4.service
sleep 8
curl -fsS --max-time 20 http://127.0.0.1:8093/health | python3 -c 'import json,sys; d=json.load(sys.stdin); expected=sys.argv[1]; actual=str(d.get("version", "")); assert actual == expected, f"health version {actual} != {expected}"' "$TARGET_VERSION"
systemctl restart kiosk-cog.service
sleep 5
systemctl is-active --quiet nspire-v4.service
systemctl is-active --quiet kiosk-cog.service
reset_update_state idle
trap - ERR
echo "V$TARGET_VERSION OTA-asennus OK"
