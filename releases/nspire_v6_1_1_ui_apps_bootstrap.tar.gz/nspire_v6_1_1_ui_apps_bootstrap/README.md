# NSPIRE V6.1.1 – käyttöliittymä- ja sovelluskorjaukset

Tämä pieni varmennettu käynnistyspaketti lataa V6.1.1:n julkaisuosat lukitusta GitHub-commitista, yhdistää ne, tarkistaa koon ja SHA-256-tarkistussumman ja käynnistää varsinaisen asennuksen.

V6.1.1 korjaa Sisäilma-kalibroinnin, kalenterin, sääsivun, ilmanlaatumittarin suunnan ja historiakäyrän sekä palauttaa Pörssisähkö-sovelluksen. V6.1.0 säilyy palautuspisteenä.
