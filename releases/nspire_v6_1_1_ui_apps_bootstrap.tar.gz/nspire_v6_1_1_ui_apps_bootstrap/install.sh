#!/usr/bin/env bash
set -Eeuo pipefail
umask 077

VERSION="6.1.1"
SOURCE_COMMIT="14af8211c4bd3ac971d534c6479874d9d32ae9ed"
BASE_URL_DEFAULT="https://raw.githubusercontent.com/mikavahakangas-hue/Pirre/${SOURCE_COMMIT}/releases/v6.1.1"
BASE_URL="${NSPIRE_V611_BASE_URL:-$BASE_URL_DEFAULT}"
PARTS_DIR="${NSPIRE_V611_PARTS_DIR:-}"
FULL_SHA="a5b32243fd65454204c6f7b4016f6be6afdc5c542dd0413d7c327eeee789144d"
FULL_SIZE="42419"
ARCHIVE_NAME="nspire_v6_1_1_ui_apps_fix.tar.gz"
INNER_DIR="nspire_v6_1_1_ui_apps_fix"
VERIFY_ONLY="${NSPIRE_BOOTSTRAP_VERIFY_ONLY:-0}"
TMP=""

log() { printf '[V6.1.1 lataus] %s\n' "$*"; }
die() { printf '[V6.1.1 lataus] VIRHE: %s\n' "$*" >&2; exit 1; }
cleanup() { [[ -z "$TMP" ]] || rm -rf -- "$TMP"; }
trap cleanup EXIT INT TERM

for cmd in base64 cat chmod curl mkdir mktemp sha256sum stat tar tr; do
  command -v "$cmd" >/dev/null 2>&1 || die "Komento puuttuu: $cmd"
done

TMP="$(mktemp -d /tmp/nspire-v611-bootstrap.XXXXXX)"
mkdir -p "$TMP/parts" "$TMP/unpack"

expected_part_size() {
  case "$1" in
    01|02) printf '10000' ;;
    03) printf '20000' ;;
    04|05|06|07|08|09) printf '2760' ;;
    *) die "Tuntematon julkaisuosa: $1" ;;
  esac
}

copy_or_download_part() {
  local num="$1"
  local long_name="${ARCHIVE_NAME}.b64.part${num}"
  local target="$TMP/parts/part${num}"
  local source=""
  local expected actual

  if [[ -n "$PARTS_DIR" ]]; then
    if [[ -f "$PARTS_DIR/part${num}" ]]; then
      source="$PARTS_DIR/part${num}"
    elif [[ -f "$PARTS_DIR/$long_name" ]]; then
      source="$PARTS_DIR/$long_name"
    else
      die "Paikallinen osa puuttuu: $num"
    fi
    cat -- "$source" > "$target"
  else
    curl -fL --retry 3 --retry-delay 1 --connect-timeout 10 --max-time 90 \
      "$BASE_URL/$long_name" -o "$target"
  fi

  [[ -s "$target" ]] || die "Tyhjä latausosa: $num"
  expected="$(expected_part_size "$num")"
  actual="$(stat -c %s "$target")"
  [[ "$actual" == "$expected" ]] || die "Osa $num on $actual tavua, odotettiin $expected"
}

log "Haetaan varmennetut julkaisuosat"
for num in 01 02 03 04 05 06 07 08 09; do
  copy_or_download_part "$num"
done

cat "$TMP"/parts/part{01,02,03,04,05,06,07,08,09} | tr -d '\r\n' > "$TMP/package.b64"
base64 --decode "$TMP/package.b64" > "$TMP/$ARCHIVE_NAME" || die "Base64-purku epäonnistui"

actual_size="$(stat -c %s "$TMP/$ARCHIVE_NAME")"
[[ "$actual_size" == "$FULL_SIZE" ]] || die "Sisäpaketin koko on $actual_size, odotettiin $FULL_SIZE"
printf '%s  %s\n' "$FULL_SHA" "$TMP/$ARCHIVE_NAME" | sha256sum -c - >/dev/null \
  || die "Sisäpaketin SHA-256 ei täsmää"
tar -tzf "$TMP/$ARCHIVE_NAME" >/dev/null || die "Sisäpaketin tar-rakenne on vioittunut"
tar -xzf "$TMP/$ARCHIVE_NAME" -C "$TMP/unpack"

INNER="$TMP/unpack/$INNER_DIR"
[[ -x "$INNER/install.sh" ]] || die "Sisäpaketin install.sh puuttuu"
[[ -x "$INNER/selftest.sh" ]] || die "Sisäpaketin selftest.sh puuttuu"
[[ "$(cat "$INNER/VERSION")" == "$VERSION" ]] || die "Sisäpaketin versionumero ei täsmää"

log "Lataus, koko, SHA-256 ja rakenne kunnossa"
if [[ "$VERIFY_ONLY" == "1" ]]; then
  log "Varmennustila valmis – järjestelmään ei tehty muutoksia"
  exit 0
fi

log "Käynnistetään V6.1.1-asennus"
cd "$INNER"
exec ./install.sh
