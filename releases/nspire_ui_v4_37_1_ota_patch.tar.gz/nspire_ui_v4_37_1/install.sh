#!/usr/bin/env bash
set -euo pipefail

PKG="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VERSION="$(tr -d '[:space:]' < "$PKG/VERSION")"
[[ "$VERSION" == "4.37.1" ]] || { echo "VIRHE: väärä OTA-versio: $VERSION" >&2; exit 1; }

cd "$PKG"
sha256sum -c --quiet SHA256SUMS

echo "V4.37.1 OTA-paketin tarkistussumma OK"
if [[ "${NSPIRE_PREFLIGHT_ONLY:-0}" == "1" ]]; then
  python3 -m py_compile "$PKG/install_patch.py"
  echo "V4.37.1 OTA-esitarkistus OK"
  exit 0
fi

ROOT="${NSPIRE_OTA_TEST_ROOT:-}"
STATIC="$ROOT/opt/nspire-ui/static"
V4STATIC="$STATIC/v4"
APPDIR="$ROOT/opt/nspire-v4"
BACKUP_ROOT="$ROOT/root/nspire-backup"
BACKUP="$BACKUP_ROOT/ota_before_4_37_1_$(date +%F-%H%M%S)"

if [[ -z "$ROOT" && "${EUID:-$(id -u)}" -ne 0 ]]; then
  exec sudo -E bash "$0"
fi

[[ -f "$STATIC/index.html" ]] || { echo "VIRHE: index.html puuttuu" >&2; exit 1; }
[[ -f "$V4STATIC/app.js" ]] || { echo "VIRHE: app.js puuttuu" >&2; exit 1; }
[[ -f "$APPDIR/nspire_v4_api.py" ]] || { echo "VIRHE: backend puuttuu" >&2; exit 1; }

mkdir -p "$BACKUP"
cp -a "$STATIC/index.html" "$BACKUP/index.html"
cp -a "$V4STATIC/app.js" "$BACKUP/app.js"
cp -a "$APPDIR/nspire_v4_api.py" "$BACKUP/nspire_v4_api.py"

rollback(){
  local rc=$?
  if [[ $rc -ne 0 ]]; then
    echo "VIRHE: V4.37.1 OTA epäonnistui, palautetaan V4.37.0" >&2
    cp -a "$BACKUP/index.html" "$STATIC/index.html" 2>/dev/null || true
    cp -a "$BACKUP/app.js" "$V4STATIC/app.js" 2>/dev/null || true
    cp -a "$BACKUP/nspire_v4_api.py" "$APPDIR/nspire_v4_api.py" 2>/dev/null || true
    if [[ -z "$ROOT" ]]; then
      systemctl restart nspire-v4.service 2>/dev/null || true
      systemctl restart kiosk-cog.service 2>/dev/null || true
    fi
  fi
  exit $rc
}
trap rollback ERR

WORK="$(mktemp -d -t nspire-ota371-files-XXXXXX)"
trap 'rm -rf "$WORK"' EXIT
python3 "$PKG/install_patch.py" \
  "$STATIC/index.html" "$V4STATIC/app.js" "$APPDIR/nspire_v4_api.py" "$WORK"

python3 -m py_compile "$WORK/nspire_v4_api.py"
if command -v node >/dev/null 2>&1; then node --check "$WORK/app.js"; fi
grep -q '<title>NSPIRE V4.37.1</title>' "$WORK/index.html"
grep -q "APP_VERSION='4.37.1'" "$WORK/app.js"
grep -q 'PILVIPÄIVITYS TOIMII' "$WORK/app.js"
grep -q 'APP_VERSION = "4.37.1"' "$WORK/nspire_v4_api.py"

install -m 0644 "$WORK/index.html" "$STATIC/index.html"
install -m 0644 "$WORK/app.js" "$V4STATIC/app.js"
install -m 0644 "$WORK/nspire_v4_api.py" "$APPDIR/nspire_v4_api.py"

if [[ -z "$ROOT" ]]; then
  systemctl restart nspire-v4.service
  ok=0
  for _ in $(seq 1 30); do
    if python3 - <<'PY' >/dev/null 2>&1
import json, urllib.request
with urllib.request.urlopen('http://127.0.0.1:8093/health', timeout=2) as r:
    data=json.load(r)
assert data.get('ok') and data.get('version') == '4.37.1'
PY
    then ok=1; break; fi
    sleep 0.5
  done
  [[ "$ok" == "1" ]] || { echo "VIRHE: V4.37.1 backend ei käynnistynyt" >&2; exit 1; }
  systemctl restart kiosk-cog.service
fi

trap - ERR
echo "V4.37.1 OTA-asennus OK"
