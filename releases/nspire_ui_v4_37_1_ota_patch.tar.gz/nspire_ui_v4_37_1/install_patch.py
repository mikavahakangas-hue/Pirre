#!/usr/bin/env python3
from __future__ import annotations

import re
import sys
from pathlib import Path

if len(sys.argv) != 5:
    raise SystemExit("usage: install_patch.py index.html app.js nspire_v4_api.py workdir")
index_path, app_path, api_path, work_path = map(Path, sys.argv[1:])
work_path.mkdir(parents=True, exist_ok=True)

index = index_path.read_text(encoding="utf-8")
app = app_path.read_text(encoding="utf-8")
api = api_path.read_text(encoding="utf-8")

if "4.37.1" in index and "APP_VERSION='4.37.1'" in app and 'APP_VERSION = "4.37.1"' in api:
    # Idempotent reinstall: keep current V4.37.1 files.
    pass
else:
    if '<title>NSPIRE V4.37.0</title>' not in index:
        raise RuntimeError("V4.37.0 index-versiota ei löytynyt")
    if "var APP_VERSION='4.37.0';" not in app:
        raise RuntimeError("V4.37.0 frontend-versiota ei löytynyt")
    if 'APP_VERSION = "4.37.0"' not in api:
        raise RuntimeError("V4.37.0 backend-versiota ei löytynyt")

    index = index.replace("4.37.0", "4.37.1")
    app = app.replace("var APP_VERSION='4.37.0';", "var APP_VERSION='4.37.1';", 1)
    release = "  {version:'4.37.1',date:'13.07.2026',title:'Ensimmäinen toimiva Pirre-pilvipäivitystesti',items:['V4.37.1 julkaistiin suoraan Pirre-päivityskanavaan V4.37.0:n OTA-asennuksen käytännön testaamiseksi.','Päivitykset-sivun kiinteässä yläpalkissa näkyy versionumero ja teksti PILVIPÄIVITYS TOIMII, joten onnistunut päivitys on helppo tunnistaa.','PÄIVITYS ASENNETTU -ikkuna jää edelleen näkyviin, kunnes se kuitataan OK-painikkeella.','Pyörivä maapallo, vaihetekstit ja etenemispalkki säilyvät tarkistuksessa, latauksessa ja asennuksessa.']},\n"
    if "title:'Ensimmäinen toimiva Pirre-pilvipäivitystesti'" not in app:
        app = app.replace("var RELEASES=[\n", "var RELEASES=[\n" + release, 1)

    new_quick = "function otaQuickActionsHtml(){var ota=(maintenanceData||{}).ota||{},install=ota.install||{},busy=updateInstallActive(install)||String(ota.operation||'')==='downloading';return '<section class=\"ota-quick\"><div><strong>PILVIPÄIVITYS TOIMII</strong><small>V'+esc(APP_VERSION)+' · tarkista, lataa ja asenna</small></div><div class=\"ota-quick-buttons\"><button id=\"otaCheck\" '+(busy?'disabled':'')+'>TARKISTA</button><button id=\"otaDownload\" '+(ota.newer&&!busy?'':'disabled')+'>LATAA</button><button id=\"otaInstall\" '+(ota.downloaded_path&&!busy?'':'disabled')+'>ASENNA</button></div></section>'}"
    app, count = re.subn(r"^function otaQuickActionsHtml\(\)\{.*\}$", new_quick, app, count=1, flags=re.MULTILINE)
    if count != 1:
        raise RuntimeError("Päivitysten yläpalkin funktiota ei löytynyt")

    api = api.replace('APP_VERSION = "4.37.0"', 'APP_VERSION = "4.37.1"', 1)
    api = api.replace('Nspire V4.37.0 API listening', 'Nspire V4.37.1 API listening', 1)

if '<title>NSPIRE V4.37.1</title>' not in index:
    raise RuntimeError("index.html-version päivittynyt väärin")
if "APP_VERSION='4.37.1'" not in app or "PILVIPÄIVITYS TOIMII" not in app:
    raise RuntimeError("app.js-version tai näkyvä OTA-tunniste puuttuu")
if 'APP_VERSION = "4.37.1"' not in api:
    raise RuntimeError("backend-version päivittynyt väärin")

(work_path / "index.html").write_text(index, encoding="utf-8")
(work_path / "app.js").write_text(app, encoding="utf-8")
(work_path / "nspire_v4_api.py").write_text(api, encoding="utf-8")
