#!/usr/bin/env python3
from __future__ import annotations

import re
import sys
from pathlib import Path

TARGET = "4.38.2"
ALLOWED_BASES = {"4.38.0", "4.38.1", TARGET}

if len(sys.argv) != 5:
    raise SystemExit("usage: install_patch.py index.html app.js nspire_v4_api.py workdir")

index_path, app_path, api_path, work_path = map(Path, sys.argv[1:])
work_path.mkdir(parents=True, exist_ok=True)

index = index_path.read_text(encoding="utf-8")
app = app_path.read_text(encoding="utf-8")
api = api_path.read_text(encoding="utf-8")


def extract(pattern: str, text: str, label: str) -> str:
    match = re.search(pattern, text, flags=re.MULTILINE)
    if not match:
        raise RuntimeError(f"{label}-versionumeroa ei löytynyt")
    return match.group(1)

index_version = extract(r"<title>NSPIRE V([0-9]+\.[0-9]+\.[0-9]+)</title>", index, "index.html")
app_version = extract(r"(?:var|let|const)\s+APP_VERSION\s*=\s*['\"]([0-9]+\.[0-9]+\.[0-9]+)['\"]", app, "frontend")
api_version = extract(r"^APP_VERSION\s*=\s*['\"]([0-9]+\.[0-9]+\.[0-9]+)['\"]", api, "backend")

versions = {index_version, app_version, api_version}
if len(versions) != 1:
    raise RuntimeError(f"Laitteen versiot eivät täsmää: index={index_version}, frontend={app_version}, backend={api_version}")
current = versions.pop()
if current not in ALLOWED_BASES:
    raise RuntimeError(f"V4.38.2-versiokorjaus vaatii V4.38.0- tai V4.38.1-pohjan, laitteessa on V{current}")

if current != TARGET:
    index, n_index = re.subn(
        r"<title>NSPIRE V(?:4\.38\.[01])</title>",
        f"<title>NSPIRE V{TARGET}</title>",
        index,
        count=1,
    )
    app, n_app = re.subn(
        r"((?:var|let|const)\s+APP_VERSION\s*=\s*['\"])(?:4\.38\.[01])(['\"]\s*;)",
        rf"\g<1>{TARGET}\g<2>",
        app,
        count=1,
        flags=re.MULTILINE,
    )
    api, n_api = re.subn(
        r"(^APP_VERSION\s*=\s*['\"])(?:4\.38\.[01])(['\"])",
        rf"\g<1>{TARGET}\g<2>",
        api,
        count=1,
        flags=re.MULTILINE,
    )
    if (n_index, n_app, n_api) != (1, 1, 1):
        raise RuntimeError(f"Version vaihto epäonnistui: index={n_index}, frontend={n_app}, backend={n_api}")

    api = re.sub(
        r"Nspire V4\.38\.[01] API listening",
        f"Nspire V{TARGET} API listening",
        api,
        count=1,
    )

release_title = "Päivityskanavan versionumero korjattu"
if release_title not in app:
    release = (
        "  {version:'4.38.2',date:'13.07.2026',title:'Päivityskanavan versionumero korjattu',"
        "items:['Pilvessä ollut V4.38.0 oli vanhempi kuin laitteessa jo ollut V4.38.1, joten päivitysohjelma esti aivan oikein alaspäin päivityksen.',"
        "'Manifesti ja OTA-paketti ovat nyt V4.38.2, joten päivitys näkyy V4.38.1-laitteessa uutena versiona.',"
        "'Päivitysnäkymän yläpalkissa näkyy V4.38.2 · PÄIVITYSKANAVA OK, jotta korjauksen huomaa heti.',"
        "'V4.38.1:n AI-, järjestelmä-, varmuuskopio- ja tapahtumailmaisintoiminnot säilyvät muuttumattomina.']},\n"
    )
    if "var RELEASES=[\n" in app:
        app = app.replace("var RELEASES=[\n", "var RELEASES=[\n" + release, 1)
    elif "var RELEASES = [\n" in app:
        app = app.replace("var RELEASES = [\n", "var RELEASES = [\n" + release, 1)
    else:
        raise RuntimeError("Muutoslokin RELEASES-listaa ei löytynyt")

# Tee korjaus näkyväksi Päivitykset-sivun kiinteässä yläpalkissa.
lines = app.splitlines(keepends=True)
updated_quick = False
for i, line in enumerate(lines):
    if line.lstrip().startswith("function otaQuickActionsHtml()"):
        new_line, count = re.subn(
            r"<strong>.*?</strong>",
            "<strong>V4.38.2 · PÄIVITYSKANAVA OK</strong>",
            line,
            count=1,
        )
        if count == 1:
            lines[i] = new_line
            updated_quick = True
        break
app = "".join(lines)
if not updated_quick and "V4.38.2 · PÄIVITYSKANAVA OK" not in app:
    raise RuntimeError("Päivitysten kiinteää yläpalkkia ei löytynyt")

# Lopputarkistukset ennen tiedostojen kirjoittamista.
if f"<title>NSPIRE V{TARGET}</title>" not in index:
    raise RuntimeError("index.html-version lopputarkistus epäonnistui")
if not re.search(rf"(?:var|let|const)\s+APP_VERSION\s*=\s*['\"]{re.escape(TARGET)}['\"]", app):
    raise RuntimeError("frontend-version lopputarkistus epäonnistui")
if not re.search(rf"^APP_VERSION\s*=\s*['\"]{re.escape(TARGET)}['\"]", api, flags=re.MULTILINE):
    raise RuntimeError("backend-version lopputarkistus epäonnistui")
if "V4.38.2 · PÄIVITYSKANAVA OK" not in app:
    raise RuntimeError("Näkyvä V4.38.2-tunniste puuttuu")

(work_path / "index.html").write_text(index, encoding="utf-8")
(work_path / "app.js").write_text(app, encoding="utf-8")
(work_path / "nspire_v4_api.py").write_text(api, encoding="utf-8")
