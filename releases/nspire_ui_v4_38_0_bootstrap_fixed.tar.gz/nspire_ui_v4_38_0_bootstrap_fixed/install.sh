#!/usr/bin/env bash
set -Eeuo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
(cd "$HERE" && sha256sum -c --quiet SHA256SUMS)

COMMIT="354c1f70c8a6d76af6da5560ac4e99c4671004e4"
BASE="${NSPIRE_UPDATE_BASE_URL:-https://raw.githubusercontent.com/mikavahakangas-hue/Pirre/${COMMIT}}"
INNER_SHA256="7c0c33b5c224db0e7c862ffc87443f43ce350d4d73c8c0d82b69c0c5798230c2"

FILES=(
  tmp-v438-part00-fixed.txt
  tmp-v438-part01.txt
  tmp-v438-part02a.txt
  tmp-v438-part03.txt
  tmp-v438-part04.txt
  tmp-v438-part05.txt
  tmp-v438-part06.txt
)

WORK="$(mktemp -d -t pirre-v438-bootstrap-XXXXXX)"
cleanup() { rm -rf "$WORK"; }
trap cleanup EXIT

fetch_file() {
  local name="$1"
  local target="$WORK/$name"
  if [[ "$BASE" == file://* ]]; then
    cp -- "${BASE#file://}/$name" "$target"
  elif command -v curl >/dev/null 2>&1; then
    curl -fL --retry 3 --connect-timeout 15 --max-time 120 \
      "$BASE/$name" -o "$target"
  elif command -v wget >/dev/null 2>&1; then
    wget -q --timeout=120 --tries=3 -O "$target" "$BASE/$name"
  else
    echo "Päivityksen lataukseen tarvitaan curl tai wget." >&2
    return 1
  fi
  [[ -s "$target" ]] || { echo "Tyhjä päivitysosa: $name" >&2; return 1; }
}

for file in "${FILES[@]}"; do
  fetch_file "$file"
done

cat "${FILES[@]/#/$WORK/}" | tr -d '\r\n' | base64 -d > "$WORK/payload.tar.gz"
echo "$INNER_SHA256  $WORK/payload.tar.gz" | sha256sum -c --quiet

tar -tzf "$WORK/payload.tar.gz" >/dev/null
mkdir -p "$WORK/unpacked"
tar -xzf "$WORK/payload.tar.gz" -C "$WORK/unpacked"
mapfile -t roots < <(find "$WORK/unpacked" -mindepth 1 -maxdepth 1 -type d -print)
[[ "${#roots[@]}" -eq 1 ]] || { echo "Päivityspaketin rakenne on virheellinen." >&2; exit 1; }
PKG="${roots[0]}"
[[ -f "$PKG/VERSION" && -f "$PKG/install.sh" && -f "$PKG/SHA256SUMS" ]]
[[ "$(tr -d '[:space:]' < "$PKG/VERSION")" == "4.38.0" ]]

exec bash "$PKG/install.sh"
