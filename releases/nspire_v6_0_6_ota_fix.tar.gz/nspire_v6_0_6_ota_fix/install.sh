#!/usr/bin/env bash
set -Eeuo pipefail
umask 022
export PYTHONDONTWRITEBYTECODE=1

PKG_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
LIVE=/opt/nspire-v6
TARGET="$LIVE/nspire/__init__.py"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="/root/nspire-backup/v6_0_6_before_${STAMP}"
LOG=/var/log/nspire-v6-update.log
SUCCESS=0
BACKEND_WAS_ACTIVE=0
KIOSK_WAS_ACTIVE=0
CURRENT_VERSION="tuntematon"
PHASE="alustus"

say(){ printf '%s [%s] %s\n' "$(date -Is)" "$PHASE" "$*" | tee -a "$LOG"; }
fail(){ say "VIRHE: $*"; return 1; }

[[ ${EUID:-$(id -u)} -eq 0 ]] || { echo "Aja asennin sudolla." >&2; exit 1; }
for cmd in python3 systemctl curl sha256sum install grep sed; do
  command -v "$cmd" >/dev/null 2>&1 || { echo "Komento puuttuu: $cmd" >&2; exit 1; }
done
[[ -f "$TARGET" ]] || { echo "V6-runtimea ei löytynyt: $TARGET" >&2; exit 1; }

cd "$PKG_DIR"
PHASE="paketin tarkistus"
sha256sum -c SHA256SUMS
bash -n install.sh

CURRENT_VERSION="$(python3 - "$TARGET" <<'PY'
from pathlib import Path
import re, sys
text = Path(sys.argv[1]).read_text(encoding='utf-8')
m = re.search(r'(?m)^\s*__version__\s*=\s*["\']([^"\']+)["\']', text)
print(m.group(1) if m else '')
PY
)"
case "$CURRENT_VERSION" in
  6.0.4|6.0.5) ;;
  6.0.6) say "V6.0.6 on jo asennettu"; exit 0 ;;
  *) fail "Päivitys vaatii V6.0.4:n tai V6.0.5:n. Nykyinen: ${CURRENT_VERSION:-tuntematon}" ;;
esac

systemctl is-active --quiet nspire-v6.service && BACKEND_WAS_ACTIVE=1 || true
systemctl is-active --quiet nspire-kiosk.service && KIOSK_WAS_ACTIVE=1 || true
mkdir -p "$BACKUP"
cp -a "$TARGET" "$BACKUP/__init__.py"

stop_unit(){
  local unit="$1"
  systemctl stop "$unit" >/dev/null 2>&1 || true
  for _ in $(seq 1 20); do
    systemctl is-active --quiet "$unit" || return 0
    sleep 0.5
  done
  systemctl kill --kill-who=all --signal=SIGKILL "$unit" >/dev/null 2>&1 || true
  systemctl stop "$unit" >/dev/null 2>&1 || true
  systemctl is-active --quiet "$unit" && return 1 || return 0
}

restore(){
  local code=$?
  [[ "$SUCCESS" -eq 1 ]] && return 0
  trap - ERR INT TERM EXIT
  PHASE="palautus"
  say "Asennus epäonnistui — palautetaan V$CURRENT_VERSION"
  stop_unit nspire-kiosk.service || true
  stop_unit nspire-v6.service || true
  cp -a "$BACKUP/__init__.py" "$TARGET"
  rm -rf "$LIVE/nspire/__pycache__" >/dev/null 2>&1 || true
  systemctl daemon-reload || true
  systemctl reset-failed nspire-v6.service nspire-kiosk.service >/dev/null 2>&1 || true
  [[ "$BACKEND_WAS_ACTIVE" -eq 1 ]] && systemctl start nspire-v6.service >/dev/null 2>&1 || true
  [[ "$KIOSK_WAS_ACTIVE" -eq 1 ]] && systemctl start nspire-kiosk.service >/dev/null 2>&1 || true
  say "Palautus valmis: $BACKUP"
  exit "$code"
}
trap restore ERR INT TERM EXIT

PHASE="palvelujen pysäytys"
say "Pysäytetään käytössä olevat V6-palvelut"
[[ "$KIOSK_WAS_ACTIVE" -eq 1 ]] && stop_unit nspire-kiosk.service || true
[[ "$BACKEND_WAS_ACTIVE" -eq 1 ]] && stop_unit nspire-v6.service || true

PHASE="version päivitys"
say "Muutetaan vain runtime-versionumero V6.0.6:een"
python3 - "$TARGET" <<'PY'
from pathlib import Path
import os, re, sys, tempfile
path = Path(sys.argv[1])
text = path.read_text(encoding='utf-8')
pattern = re.compile(r'(?m)^(\s*__version__\s*=\s*)["\'][^"\']+["\'](\s*)$')
new_text, count = pattern.subn(r'\1"6.0.6"\2', text, count=1)
if count != 1:
    raise SystemExit("__version__-riviä ei löytynyt yksikäsitteisesti")
fd, tmp = tempfile.mkstemp(prefix=path.name + '.', dir=str(path.parent))
try:
    with os.fdopen(fd, 'w', encoding='utf-8', newline='') as f:
        f.write(new_text)
        f.flush()
        os.fsync(f.fileno())
    os.chmod(tmp, 0o644)
    os.chown(tmp, 0, 0)
    os.replace(tmp, path)
finally:
    if os.path.exists(tmp):
        os.unlink(tmp)
PY
rm -rf "$LIVE/nspire/__pycache__" >/dev/null 2>&1 || true
python3 -m py_compile "$TARGET"
python3 - "$TARGET" <<'PY'
from pathlib import Path
import re, sys
text = Path(sys.argv[1]).read_text(encoding='utf-8')
m = re.search(r'(?m)^\s*__version__\s*=\s*["\']([^"\']+)["\']', text)
assert m and m.group(1) == '6.0.6', m.group(1) if m else 'puuttuu'
PY

PHASE="backendin käynnistys"
systemctl daemon-reload
systemctl reset-failed nspire-v6.service nspire-kiosk.service >/dev/null 2>&1 || true
systemctl start nspire-v6.service
for _ in $(seq 1 60); do
  systemctl is-active --quiet nspire-v6.service && \
    curl -fsS --noproxy '*' --connect-timeout 2 --max-time 5 http://127.0.0.1:8765/api/health >/dev/null 2>&1 && break
  sleep 1
done
systemctl is-active --quiet nspire-v6.service || fail "Backend ei käynnistynyt"
curl -fsS --noproxy '*' --connect-timeout 2 --max-time 5 http://127.0.0.1:8765/api/health >/dev/null || fail "Health-tarkistus epäonnistui"

PHASE="OTA-version tarkistus"
update_json="$(curl -fsS --noproxy '*' --connect-timeout 2 --max-time 8 http://127.0.0.1:8765/api/update)" || fail "OTA-tilaa ei saatu"
printf '%s' "$update_json" | python3 -c 'import json,sys; d=json.load(sys.stdin); v=str(d.get("current_version", "")); sys.exit(0 if v == "6.0.6" else 1)' \
  || fail "OTA-palvelu ei ilmoita nykyversioksi V6.0.6"

PHASE="kioskin käynnistys"
if [[ "$KIOSK_WAS_ACTIVE" -eq 1 ]]; then
  systemctl start nspire-kiosk.service
  for _ in $(seq 1 30); do
    systemctl is-active --quiet nspire-kiosk.service && break
    sleep 1
  done
  systemctl is-active --quiet nspire-kiosk.service || fail "Cog-kioski ei käynnistynyt"
fi

PHASE="vakaustarkistus"
for _ in 1 2 3; do
  systemctl is-active --quiet nspire-v6.service || fail "Backend pysähtyi vakaustarkistuksessa"
  curl -fsS --noproxy '*' --connect-timeout 2 --max-time 5 http://127.0.0.1:8765/api/health >/dev/null || fail "Health epäonnistui vakaustarkistuksessa"
  [[ "$KIOSK_WAS_ACTIVE" -eq 0 ]] || systemctl is-active --quiet nspire-kiosk.service || fail "Kioski pysähtyi vakaustarkistuksessa"
  sleep 3
done

SUCCESS=1
trap - ERR INT TERM EXIT
PHASE="valmis"
say "V6.0.6 asennus OK · lähtöversio V$CURRENT_VERSION · varmuuskopio=$BACKUP"
