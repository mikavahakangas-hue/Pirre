# NSPIRE V6.0.6 OTA-korjaus

Korjauspäivitys V6.0.5:n epäonnistuneeseen asennukseen. Asennin ei enää vaadi paikallisen runtime-tiedoston täsmällistä SHA-256-arvoa eikä korvaa koko tiedostoa. Se muuttaa vain `__version__`-arvon, tarkistaa Python-syntaksin, käynnistää aiemmin käytössä olleet palvelut ja varmistaa OTA-palvelun ilmoittaman version.
