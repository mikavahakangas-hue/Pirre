#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"
sha256sum -c SHA256SUMS
bash -n "$ROOT/install.sh"
python3 - "$ROOT/install.sh" <<'PY'
from pathlib import Path
import sys
text=Path(sys.argv[1]).read_text(encoding='utf-8')
required=(
    '6.0.4|6.0.5',
    'Muutetaan vain runtime-versionumero V6.0.6:een',
    'json.load(sys.stdin)',
    'OTA-palvelu ei ilmoita nykyversioksi V6.0.6',
    'restore(){',
)
for marker in required:
    assert marker in text, marker
print('V6.0.6 OTA SELFTEST OK')
PY
