# NSPIRE V6.1.2 – Unikello ja sisäilmatiedot

Pieni OTA-bootstrap lataa tarkistussummalla lukitun V6.1.2-asennuspaketin osat GitHubista, kokoaa varsinaisen paketin ja käynnistää sen turvallisen asentimen.

Muutokset:
- Unikello-sovellus, jonka yö-, herätys-, keltainen vaihe- ja päiväuniajan asetukset tallentuvat.
- Olemassa olevaan näytönsäästäjään sisälämpötila ja kosteus BME680-palvelusta.
- Anturitiedot piilotetaan, jos BME680-palvelu ei vastaa tai lukema on vanhentunut.
- V6.1.1 säilyy palautuspisteenä; BME680-palvelua ei asenneta uudelleen.
