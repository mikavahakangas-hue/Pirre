#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"
sha256sum -c SHA256SUMS
bash -n install.sh
for marker in \
  'aea8763195b9b2d1fb27699591f2c63412462b64' \
  '21920108bba4cf370db80a40cade2c435ac368f1dfc3d36e0c06a75d085c585b' \
  'NSPIRE_BOOTSTRAP_VERIFY_ONLY' \
  'part${n}.txt'; do
  grep -Fq "$marker" install.sh
 done
echo 'V6.1.2 BOOTSTRAP SELFTEST OK'
