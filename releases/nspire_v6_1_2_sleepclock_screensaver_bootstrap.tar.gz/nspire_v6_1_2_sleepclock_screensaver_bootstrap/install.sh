#!/usr/bin/env bash
set -Eeuo pipefail
umask 022

PARTS_COMMIT="aea8763195b9b2d1fb27699591f2c63412462b64"
BASE_URL="https://raw.githubusercontent.com/mikavahakangas-hue/Pirre/${PARTS_COMMIT}/releases/v6.1.2-lite-exact"
INNER_SHA256="21920108bba4cf370db80a40cade2c435ac368f1dfc3d36e0c06a75d085c585b"
TMP_ROOT="$(mktemp -d /tmp/nspire-v612-bootstrap.XXXXXX)"
B64_FILE="$TMP_ROOT/package.tar.gz.b64"
ARCHIVE="$TMP_ROOT/nspire_v6_1_2_sleepclock_screensaver_lite.tar.gz"
EXTRACT="$TMP_ROOT/extract"
CURL_BIN="${CURL:-curl}"

cleanup(){ rm -rf "$TMP_ROOT"; }
trap cleanup EXIT INT TERM

[[ ${EUID:-$(id -u)} -eq 0 ]] || { echo "Aja asennin root-oikeuksilla." >&2; exit 1; }
for cmd in "$CURL_BIN" base64 sha256sum tar bash mkdir mktemp rm cat; do
  command -v "$cmd" >/dev/null 2>&1 || { echo "Komento puuttuu: $cmd" >&2; exit 1; }
done

: > "$B64_FILE"
for n in 00 01 02 03 04 05 06 07 08; do
  echo "V6.1.2: ladataan paketin osa $n/08"
  "$CURL_BIN" -fsSL --retry 3 --retry-delay 1 --connect-timeout 10 --max-time 60 \
    "$BASE_URL/part${n}.txt" >> "$B64_FILE"
done

base64 --decode "$B64_FILE" > "$ARCHIVE"
printf '%s  %s\n' "$INNER_SHA256" "$ARCHIVE" | sha256sum -c -
mkdir -p "$EXTRACT"
tar -xzf "$ARCHIVE" -C "$EXTRACT" --no-same-owner
INNER_DIR="$EXTRACT/nspire_v6_1_2_sleepclock_screensaver_lite"
[[ -x "$INNER_DIR/install.sh" ]] || { echo "Varsinainen V6.1.2-asennin puuttuu." >&2; exit 1; }
(
  cd "$INNER_DIR"
  sha256sum -c SHA256SUMS
)

if [[ "${NSPIRE_BOOTSTRAP_VERIFY_ONLY:-0}" == "1" ]]; then
  echo "V6.1.2 bootstrap verification OK"
  exit 0
fi

exec bash "$INNER_DIR/install.sh"
