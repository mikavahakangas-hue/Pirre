#!/usr/bin/env bash
set -Eeuo pipefail
umask 022
export PYTHONDONTWRITEBYTECODE=1

PKG_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
LIVE=/opt/nspire-v6
TARGET="$LIVE/nspire/__init__.py"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="/root/nspire-backup/v6_0_5_verify_before_${STAMP}"
LOG=/var/log/nspire-v6-update.log
SUCCESS=0
BACKEND_WAS_ACTIVE=0
KIOSK_WAS_ACTIVE=0

say(){ printf '%s %s\n' "$(date -Is)" "$*" | tee -a "$LOG"; }
fail(){ say "VIRHE: $*"; return 1; }
[[ ${EUID:-$(id -u)} -eq 0 ]] || { echo "Aja asennin sudolla." >&2; exit 1; }
for cmd in python3 systemctl curl sha256sum install; do command -v "$cmd" >/dev/null 2>&1 || { echo "Komento puuttuu: $cmd" >&2; exit 1; }; done
[[ -f "$TARGET" ]] || { echo "V6-runtimea ei löytynyt." >&2; exit 1; }

cd "$PKG_DIR"
sha256sum -c SHA256SUMS
python3 -m py_compile "$PKG_DIR/payload/nspire/__init__.py"

current_version="$(python3 - <<PY
import re
from pathlib import Path
s=Path('$TARGET').read_text(encoding='utf-8')
m=re.search(r'__version__\s*=\s*["\x27]([^"\x27]+)',s)
print(m.group(1) if m else '')
PY
)"
case "$current_version" in 6.0.4) ;; *) fail "Päivitys vaatii V6.0.4:n. Nykyinen: ${current_version:-tuntematon}" ;; esac
current_hash="$(sha256sum "$TARGET" | awk '{print $1}')"
case "$current_version:$current_hash" in
  6.0.4:5bbd371f54b3c7d8f9e0c749d8909d489cbb28d9c6050607c4d1d9940a3c49e2) ;;
  *) fail "Runtime-version lähdetiedosto ei vastaa tunnettua V$current_version-versiota" ;;
esac

systemctl is-active --quiet nspire-v6.service && BACKEND_WAS_ACTIVE=1 || true
systemctl is-active --quiet nspire-kiosk.service && KIOSK_WAS_ACTIVE=1 || true
mkdir -p "$BACKUP"
cp -a "$TARGET" "$BACKUP/__init__.py"

stop_unit(){
  local unit="$1"
  systemctl stop --no-block "$unit" >/dev/null 2>&1 || true
  for _ in $(seq 1 24); do systemctl is-active --quiet "$unit" || return 0; sleep 0.5; done
  systemctl kill --kill-who=all --signal=SIGKILL "$unit" >/dev/null 2>&1 || true
  systemctl stop "$unit" >/dev/null 2>&1 || true
  for _ in $(seq 1 10); do systemctl is-active --quiet "$unit" || return 0; sleep 0.5; done
  return 1
}

restore(){
  local code=$?
  [[ "$SUCCESS" -eq 1 ]] && return 0
  trap - ERR INT TERM EXIT
  say "Asennus epäonnistui — palautetaan V$current_version"
  stop_unit nspire-kiosk.service || true
  stop_unit nspire-v6.service || true
  cp -a "$BACKUP/__init__.py" "$TARGET"
  systemctl daemon-reload || true
  systemctl reset-failed nspire-v6.service nspire-kiosk.service >/dev/null 2>&1 || true
  [[ "$BACKEND_WAS_ACTIVE" -eq 1 ]] && systemctl start nspire-v6.service >/dev/null 2>&1 || true
  [[ "$KIOSK_WAS_ACTIVE" -eq 1 ]] && systemctl start nspire-kiosk.service >/dev/null 2>&1 || true
  say "Palautus valmis: $BACKUP"
  exit "$code"
}
trap restore ERR INT TERM EXIT

say "Pysäytetään V6-runtime hallitusti"
stop_unit nspire-kiosk.service
stop_unit nspire-v6.service

say "Päivitetään runtime-versio atomisesti V6.0.5:een"
install -m 0644 -o root -g root "$PKG_DIR/payload/nspire/__init__.py" "$TARGET.v605.tmp"
mv -f "$TARGET.v605.tmp" "$TARGET"
python3 -m py_compile "$TARGET"

systemctl daemon-reload
systemctl reset-failed nspire-v6.service nspire-kiosk.service >/dev/null 2>&1 || true
systemctl start nspire-v6.service
for _ in $(seq 1 90); do
  curl -fsS --noproxy '*' --connect-timeout 2 --max-time 5 http://127.0.0.1:8765/api/health 2>/dev/null | grep -q '"version":"6.0.5"' && break
  sleep 1
done
curl -fsS --noproxy '*' --connect-timeout 2 --max-time 5 http://127.0.0.1:8765/api/health | grep -q '"version":"6.0.5"' || fail "V6.0.5 API ei käynnistynyt"
curl -fsS --noproxy '*' --connect-timeout 2 --max-time 8 http://127.0.0.1:8765/api/update | grep -q '"current_version":"6.0.5"' || fail "OTA-palvelu ei tunnista V6.0.5:tä"
curl -fsS --noproxy '*' --connect-timeout 2 --max-time 8 http://127.0.0.1:8765/ | grep -q 'NSPIRE 6' || fail "Etusivu ei vastaa"

systemctl start nspire-kiosk.service
for _ in $(seq 1 45); do systemctl is-active --quiet nspire-kiosk.service && break; sleep 1; done
systemctl is-active --quiet nspire-kiosk.service || fail "Cog-kioski ei käynnistynyt"

say "Ajetaan 45 sekunnin OTA-vakaustesti"
for _ in $(seq 1 9); do
  systemctl is-active --quiet nspire-v6.service || fail "Backend pysähtyi vakaustestissä"
  systemctl is-active --quiet nspire-kiosk.service || fail "Kioski pysähtyi vakaustestissä"
  curl -fsS --noproxy '*' --connect-timeout 2 --max-time 6 http://127.0.0.1:8765/api/health >/dev/null || fail "Health epäonnistui vakaustestissä"
  sleep 5
done
backend_restarts="$(systemctl show nspire-v6.service -p NRestarts --value)"
kiosk_restarts="$(systemctl show nspire-kiosk.service -p NRestarts --value)"
[[ "$backend_restarts" == 0 ]] || fail "Backend käynnistyi uudelleen: $backend_restarts"
[[ "$kiosk_restarts" == 0 ]] || fail "Kioski käynnistyi uudelleen: $kiosk_restarts"

SUCCESS=1
trap - ERR INT TERM EXIT
say "V6.0.5 asennus OK · suora OTA-ketju varmennettu · NRestarts=0 · varmuuskopio=$BACKUP"
