#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
sha256sum -c "$ROOT/SHA256SUMS"
bash -n "$ROOT/install.sh"
python3 - "$ROOT" <<'PY'
from pathlib import Path
import re,sys
root=Path(sys.argv[1])
text=(root/'payload/nspire/__init__.py').read_text(encoding='utf-8')
compile(text,str(root/'payload/nspire/__init__.py'),'exec')
assert re.search(r'__version__\s*=\s*"6\.0\.5"',text)
installer=(root/'install.sh').read_text(encoding='utf-8')
for marker in ('case "$current_version" in 6.0.4)','"version":"6.0.5"','"current_version":"6.0.5"','NRestarts','restore'):
    assert marker in installer, marker
print('V6.0.5 OTA SELFTEST OK')
PY
