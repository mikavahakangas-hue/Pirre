# NSPIRE V6.0.5 OTA-varmistus

Minimaalinen korjauspäivitys V6.0.4:n päälle. Paketin versionumero on tarkoituksella 6.0.5, jotta laitteen OTA-vertailu tunnistaa sen uudeksi päivitykseksi. Se päivittää vain runtime-version ja testaa suoran OTA-ketjun muuttamatta käyttöliittymää, näytönsäästäjää, VNC:tä, näyttöä, kosketusta, verkkoa tai palvelurakennetta.
