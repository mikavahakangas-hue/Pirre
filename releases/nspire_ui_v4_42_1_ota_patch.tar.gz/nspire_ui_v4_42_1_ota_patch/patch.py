#!/usr/bin/env python3
from pathlib import Path
import re,sys
index_p,js_p,css_p,api_p,theme_p=map(Path,sys.argv[1:])
index=index_p.read_text(encoding='utf-8'); js=js_p.read_text(encoding='utf-8'); css=css_p.read_text(encoding='utf-8'); api=api_p.read_text(encoding='utf-8'); theme=theme_p.read_text(encoding='utf-8')
if "APP_VERSION='4.42.1'" in js and 'NSPIRE UI V4.42.1' in css:
 print('V4.42.1 on jo asennettu'); raise SystemExit(0)
if "APP_VERSION='4.41.1'" not in js or 'APP_VERSION = "4.41.1"' not in api:
 raise SystemExit('VIRHE: päivitys vaatii toimivan V4.41.1-pohjan')
index=index.replace('V4.41.1','V4.42.1').replace('v=4.41.1','v=4.42.1').replace('data-theme="win-dark"','data-theme="dark-ocean"')
js=js.replace("APP_VERSION='4.41.1'","APP_VERSION='4.42.1'",1)
entry="  {version:'4.42.1',date:'14.07.2026',title:'18 itsenäistä teemaa ja kokonaan uusi etusivu',items:['Yhdeksän tummaa ja yhdeksän vaaleaa värikarttaa.','Jokaisella teemalla on omat tausta-, pinta-, teksti-, reuna- ja korostusvärit.','Etusivu on rakennettu uusiksi Windows-henkisillä kuvakekorteilla.','Statusvärit ja sovelluskuvakkeiden tunnistevärit ovat erillään teemaväristä.']},\n"
needle='var RELEASES=[\n'
if entry not in js: js=js.replace(needle,needle+entry,1)
start=js.find('theme:[{',js.find('var SETTINGS_CHOICES=')); end=js.find('],gemini_model:',start)
if start<0 or end<0: raise SystemExit('VIRHE: teemaluetteloa ei löytynyt')
themes=[('Ocean Dark','dark-ocean'),('Graphite Dark','dark-graphite'),('Forest Dark','dark-forest'),('Amber Dark','dark-amber'),('Violet Dark','dark-violet'),('Crimson Dark','dark-crimson'),('Teal Dark','dark-teal'),('Navy Dark','dark-navy'),('Mono Dark','dark-mono'),('Windows Light','light-windows'),('Paper Light','light-paper'),('Warm Light','light-warm'),('Cool Light','light-cool'),('Mint Light','light-mint'),('Lilac Light','light-lilac'),('Rose Light','light-rose'),('Sand Light','light-sand'),('Contrast Light','light-contrast')]
choices='theme:['+','.join("{label:%r,value:%r}"%(a,b) for a,b in themes)+']'
js=js[:start]+choices+js[end+1:]
mi=js.find('var THEME_SWATCHES='); me=js.find(';\nfunction renderThemeSwatches',mi)
if mi<0 or me<0: raise SystemExit('VIRHE: teemakarttaa ei löytynyt')
colors={'dark-ocean':['#0b0f14','#1c2632','#4aa3ff'],'dark-graphite':['#101112','#26292c','#b4bac3'],'dark-forest':['#09110d','#1c2d22','#4ac17b'],'dark-amber':['#15100a','#312619','#e99a42'],'dark-violet':['#100c17','#2c233a','#a57af3'],'dark-crimson':['#150b0e','#321d23','#e45b70'],'dark-teal':['#071212','#172e2e','#35b9b4'],'dark-navy':['#080d19','#182641','#638df2'],'dark-mono':['#050505','#1e1e1e','#ffffff'],'light-windows':['#f3f3f3','#ffffff','#0067c0'],'light-paper':['#f7f5f0','#fffefa','#4e6a80'],'light-warm':['#faf4ea','#fffaf3','#b85c00'],'light-cool':['#edf4f8','#ffffff','#0078d4'],'light-mint':['#eef7f2','#ffffff','#16855b'],'light-lilac':['#f5f1fa','#ffffff','#7651b5'],'light-rose':['#fbf1f3','#ffffff','#b64f68'],'light-sand':['#f4f0e6','#fffdf8','#8a681e'],'light-contrast':['#ffffff','#f2f2f2','#0046cc']}
newmap='var THEME_SWATCHES='+repr(colors).replace("'",'\'')
# repr is already valid JS object syntax with quoted keys
js=js[:mi]+newmap+js[me:]
js=js.replace("config.theme||'win-dark'","config.theme||'dark-ocean'").replace("config.theme||'redline'","config.theme||'dark-ocean'")
oldinfo='Jokainen teema käyttää omaa Windows-tyylistä värikarttaa: neutraalit taustat ja tekstit sekä erilliset korostus-, info-, onnistumis-, varoitus- ja virhevärit. Vaaleat teemat vaihtavat pinnat ja tekstikontrastin oikeasti vaaleiksi.'
newinfo='18 itsenäistä värikarttaa: yhdeksän tummaa ja yhdeksän vaaleaa. Esikatselu näyttää kunkin teeman taustan, pinnan ja pääkorostuksen.'
js=js.replace(oldinfo,newinfo)
api=api.replace('APP_VERSION = "4.41.1"','APP_VERSION = "4.42.1"',1).replace('Nspire V4.41.1 API','Nspire V4.42.1 API')
# replace theme default and validator regardless of current exact set
api=api.replace('"theme": "win-dark"','"theme": "dark-ocean"')
vals=', '.join('"%s"'%v for _,v in themes)
api=re.sub(r'config\["theme"\] = choice\(config\.get\("theme"\), \{[^\n]+?\}, "[^"]+"\)',f'config["theme"] = choice(config.get("theme"), {{{vals}}}, "dark-ocean")',api,count=1)
# Remove all earlier theme overhaul appendices and replace with one coherent system
for marker in ['/* NSPIRE UI V4.41.0','/* NSPIRE UI V4.41.1','/* NSPIRE UI V4.42.1']:
 if marker in css: css=css.split(marker,1)[0].rstrip()+'\n\n'
css+=theme.rstrip()+'\n'
index_p.write_text(index,encoding='utf-8'); js_p.write_text(js,encoding='utf-8'); css_p.write_text(css,encoding='utf-8'); api_p.write_text(api,encoding='utf-8')
print('V4.42.1 tiedostot päivitetty')
