#!/usr/bin/env bash
set -Eeuo pipefail
BASE=/opt/nspire-ui/static
API=/opt/nspire-v4/nspire_v4_api.py
SELF="$(cd "$(dirname "$0")" && pwd)"
for f in "$BASE/index.html" "$BASE/v4/app.js" "$BASE/v4/app.css" "$API"; do test -f "$f" || { echo "VIRHE: puuttuu $f"; exit 1; }; done
if [[ "${NSPIRE_PREFLIGHT_ONLY:-0}" == 1 ]]; then
  TMP=$(mktemp -d -t nspire-v4421-preflight-XXXXXX); trap 'rm -rf "$TMP"' EXIT
  cp "$BASE/index.html" "$TMP/index.html"; cp "$BASE/v4/app.js" "$TMP/app.js"; cp "$BASE/v4/app.css" "$TMP/app.css"; cp "$API" "$TMP/api.py"
  python3 "$SELF/patch.py" "$TMP/index.html" "$TMP/app.js" "$TMP/app.css" "$TMP/api.py" "$SELF/theme-v4421.css"
  node --check "$TMP/app.js" >/dev/null
  python3 -m py_compile "$TMP/api.py"
  echo 'V4.42.1 OTA-esitarkistus OK'; exit 0
fi
STAMP=$(date +%Y%m%d-%H%M%S); BACK=/root/nspire-backup/ota_before_4_42_0_$STAMP
mkdir -p "$BACK/static/v4" "$BACK/api"
cp -a "$BASE/index.html" "$BACK/static/index.html"; cp -a "$BASE/v4/app.js" "$BACK/static/v4/app.js"; cp -a "$BASE/v4/app.css" "$BACK/static/v4/app.css"; cp -a "$API" "$BACK/api/nspire_v4_api.py"
rollback(){
  echo 'VIRHE: palautetaan edellinen versio'
  cp -a "$BACK/static/index.html" "$BASE/index.html"; cp -a "$BACK/static/v4/app.js" "$BASE/v4/app.js"; cp -a "$BACK/static/v4/app.css" "$BASE/v4/app.css"; cp -a "$BACK/api/nspire_v4_api.py" "$API"
  systemctl restart nspire-v4.service || true; systemctl restart kiosk-cog.service || true
}
trap rollback ERR
python3 "$SELF/patch.py" "$BASE/index.html" "$BASE/v4/app.js" "$BASE/v4/app.css" "$API" "$SELF/theme-v4421.css"
node --check "$BASE/v4/app.js" >/dev/null
python3 -m py_compile "$API"
systemctl restart nspire-v4.service
sleep 4
curl -fsS --max-time 12 http://127.0.0.1:8093/health | grep -Eq '"version"[[:space:]]*:[[:space:]]*"4\.42\.0"'
systemctl restart kiosk-cog.service || true
sleep 3
systemctl is-active --quiet kiosk-cog.service
trap - ERR
echo 'V4.42.1 OTA-asennus OK'
