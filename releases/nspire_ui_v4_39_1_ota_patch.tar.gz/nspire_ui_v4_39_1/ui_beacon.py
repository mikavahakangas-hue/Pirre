#!/usr/bin/env python3
from __future__ import annotations

import argparse
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--marker', required=True)
    parser.add_argument('--port', type=int, default=8094)
    args = parser.parse_args()
    marker = Path(args.marker)

    class Handler(BaseHTTPRequestHandler):
        def do_GET(self) -> None:  # noqa: N802
            if self.path.startswith('/ready'):
                marker.parent.mkdir(parents=True, exist_ok=True)
                marker.write_text('4.39.1\n', encoding='utf-8')
                self.send_response(204)
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()
                return
            self.send_response(404)
            self.end_headers()

        def log_message(self, _format: str, *_args: object) -> None:
            return

    class ReusableHTTPServer(HTTPServer):
        allow_reuse_address = True

    server = ReusableHTTPServer(('127.0.0.1', args.port), Handler)
    server.timeout = 90
    while not marker.exists():
        server.handle_request()
    server.server_close()
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
