#!/usr/bin/env python3
from __future__ import annotations

import os
import subprocess
import sys
import tempfile
import time
import urllib.request
from pathlib import Path

PKG = Path(__file__).resolve().parent


def make_root(root: Path, version: str = '4.38.2') -> None:
    static = root / 'opt/nspire-ui/static'
    v4 = static / 'v4'
    api = root / 'opt/nspire-v4'
    v4.mkdir(parents=True)
    api.mkdir(parents=True)
    (static / 'index.html').write_text(
        f'''<!doctype html><html><head><title>NSPIRE V{version}</title></head><body>
<div id="app"><section id="updates"><strong>V{version} · PÄIVITYSKANAVA OK</strong>
<button id="check">TARKISTA</button><button id="download">LATAA</button><button id="install" disabled>ASENNA</button>
</section><div id="screensaver" class="screensaver active">SAVER</div><button>AI</button><button>ASETUKSET</button></div>
<script src="/v4/app.js"></script></body></html>''',
        encoding='utf-8',
    )
    (v4 / 'app.js').write_text(
        f"var APP_VERSION='{version}';\nvar RELEASES=[];\nfunction showSaver(){{}}\nfunction hideSaver(){{}}\nfunction activity(){{}}\n",
        encoding='utf-8',
    )
    (api / 'nspire_v4_api.py').write_text(
        f"APP_VERSION='{version}'\nprint('Nspire V{version} API listening')\n",
        encoding='utf-8',
    )


def run_installer(root: Path) -> subprocess.CompletedProcess[str]:
    env = os.environ.copy()
    env['NSPIRE_OTA_TEST_ROOT'] = str(root)
    return subprocess.run(
        ['bash', str(PKG / 'install.sh')],
        env=env,
        text=True,
        capture_output=True,
        check=False,
    )


def assert_installed(root: Path) -> None:
    index = (root / 'opt/nspire-ui/static/index.html').read_text(encoding='utf-8')
    app = (root / 'opt/nspire-ui/static/v4/app.js').read_text(encoding='utf-8')
    api = (root / 'opt/nspire-v4/nspire_v4_api.py').read_text(encoding='utf-8')
    assert '<title>NSPIRE V4.39.1</title>' in index
    assert index.count('/v4/v4391-update-ui.js?v=4.39.1') == 1
    assert index.count('/v4/v4391-update-ui.css?v=4.39.1') == 1
    assert "APP_VERSION='4.39.1'" in app
    assert "APP_VERSION='4.39.1'" in api
    assert (root / 'opt/nspire-ui/static/v4/v4391-update-ui.js').is_file()
    assert (root / 'opt/nspire-ui/static/v4/v4391-update-ui.css').is_file()


def test_clean_install() -> None:
    with tempfile.TemporaryDirectory(prefix='nspire-v4391-clean-') as tmp:
        root = Path(tmp)
        make_root(root)
        result = run_installer(root)
        assert result.returncode == 0, result.stdout + result.stderr
        assert_installed(root)


def test_idempotent() -> None:
    with tempfile.TemporaryDirectory(prefix='nspire-v4391-idempotent-') as tmp:
        root = Path(tmp)
        make_root(root)
        first = run_installer(root)
        assert first.returncode == 0, first.stdout + first.stderr
        second = run_installer(root)
        assert second.returncode == 0, second.stdout + second.stderr
        assert_installed(root)


def test_wrong_base_rejected() -> None:
    with tempfile.TemporaryDirectory(prefix='nspire-v4391-wrong-') as tmp:
        root = Path(tmp)
        make_root(root, '4.37.1')
        before = (root / 'opt/nspire-ui/static/index.html').read_bytes()
        result = run_installer(root)
        assert result.returncode != 0
        assert (root / 'opt/nspire-ui/static/index.html').read_bytes() == before


def test_cog_compatible_source() -> None:
    script = (PKG / 'v4391-update-ui.js').read_text(encoding='utf-8')
    forbidden = ['=>', '?.', '??', 'async function', 'await ', '`']
    for token in forbidden:
        assert token not in script, f'Cog-yhteensopivuus: vältettävä rakenne löytyi: {token}'
    result = subprocess.run(['node', '--check', str(PKG / 'v4391-update-ui.js')], text=True, capture_output=True)
    assert result.returncode == 0, result.stdout + result.stderr


def test_update_logic_with_dom_stub() -> None:
    harness = r'''
const path = process.argv[2];
class Classes {
  constructor(names) { this.s = new Set(names || []); }
  add(n) { this.s.add(n); }
  remove(n) { this.s.delete(n); }
  contains(n) { return this.s.has(n); }
  toggle(n, force) { if (force === undefined) force = !this.s.has(n); force ? this.s.add(n) : this.s.delete(n); }
}
function button(text, disabled) {
  return {
    textContent: text, disabled: !!disabled, hidden: false, classList: new Classes(), attrs: {}, listeners: [],
    parentElement: null, tabIndex: 0,
    setAttribute(k,v){this.attrs[k]=String(v)}, getAttribute(k){return this.attrs[k] || null},
    addEventListener(t,f){if(t==='click') this.listeners.push(f)},
    click(){this.listeners.slice().forEach(f=>f.call(this,{type:'click'}))}
  };
}
const check=button('TARKISTA',false), download=button('LATAA',false), install=button('ASENNA',true), ai=button('AI',false), settings=button('ASETUKSET',false);
const saver={classList:new Classes(['active']),attrs:{},setAttribute(k,v){this.attrs[k]=v}};
const status={textContent:'NSPIRE V4.38.2 PÄIVITYSKANAVA OK'};
const root={parentElement:null,contains(e){return e===install},get textContent(){return status.textContent+' '+check.textContent+' '+download.textContent+' '+install.textContent}};
[check,download,install].forEach(b=>b.parentElement=root);
const all=[check,download,install,ai,settings];
global.window=global;
window.__NSPIRE_OTA_BUSY__=false;
window.addEventListener=function(){};
window.getComputedStyle=function(e){return {display:e.classList&&e.classList.contains('nspire-secondary-install')?'none':'block',visibility:'visible',opacity:'1'}};
window.hideSaver=function(){saver.classList.remove('active')};
window.showSaver=function(){saver.classList.add('active')};
window.activity=function(){};
global.document={
 readyState:'complete', body:{innerText:'NSPIRE AI SETTINGS UPDATES PÄIVITYSKANAVA TARKISTA LATAA ASENNA ASETUKSET KAMERA AKKU SÄÄ KALENTERI'},
 documentElement:{classList:new Classes()}, addEventListener(){}, removeEventListener(){},
 querySelectorAll(sel){ if(sel==='button, [role="button"]') return all; if(sel.indexOf('screensaver')>=0) return [saver]; return []; }
};
global.Image=function(){Object.defineProperty(this,'src',{set(v){global.beacon=v}})};
download.addEventListener('click',function(){
  download.disabled=true;
  setTimeout(function(){ status.textContent='PAKETTI LADATTU · VALMIS ASENNETTAVAKSI'; install.disabled=false; },180);
});
global.installCount=0;
install.addEventListener('click',function(){global.installCount++;status.textContent='ASENNETAAN';});
require(path);
setTimeout(function(){
  try {
    if(download.textContent!=='LATAA JA PÄIVITÄ') throw new Error('painikkeen nimi');
    download.click();
    window.showSaver();
  } catch(e) { console.error(e); process.exit(1); }
},50);
setTimeout(function(){
  try {
    if(global.installCount!==1) throw new Error('automaattinen asennus ei käynnistynyt kerran');
    if(saver.classList.contains('active')) throw new Error('näytönsäästäjä aktivoitui päivityksen aikana');
    process.exit(0);
  } catch(e) { console.error(e); process.exit(1); }
},1400);
'''
    with tempfile.TemporaryDirectory(prefix='nspire-v4391-node-') as tmp:
        harness_path = Path(tmp) / 'harness.js'
        harness_path.write_text(harness, encoding='utf-8')
        result = subprocess.run(
            ['node', str(harness_path), str(PKG / 'v4391-update-ui.js')],
            text=True,
            capture_output=True,
            timeout=10,
        )
        assert result.returncode == 0, result.stdout + result.stderr


def test_beacon_server() -> None:
    with tempfile.TemporaryDirectory(prefix='nspire-v4391-beacon-') as tmp:
        marker = Path(tmp) / 'ready'
        process = subprocess.Popen(
            [sys.executable, str(PKG / 'ui_beacon.py'), '--marker', str(marker), '--port', '18094'],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )
        try:
            for _ in range(40):
                try:
                    urllib.request.urlopen('http://127.0.0.1:18094/ready?v=4.39.1', timeout=1).read()
                    break
                except Exception:
                    time.sleep(0.05)
            process.wait(timeout=5)
            assert process.returncode == 0
            assert marker.read_text(encoding='utf-8').strip() == '4.39.1'
        finally:
            if process.poll() is None:
                process.terminate()
                process.wait(timeout=5)


def main() -> int:
    test_clean_install()
    print('TESTI 1/6 OK: puhdas V4.38.2 -> V4.39.1')
    test_idempotent()
    print('TESTI 2/6 OK: uudelleenasennus ei tuplaa linkityksiä')
    test_wrong_base_rejected()
    print('TESTI 3/6 OK: väärä pohjaversio hylätään muuttamatta tiedostoja')
    test_cog_compatible_source()
    print('TESTI 4/6 OK: Cog/WPE-yhteensopiva JavaScript-profiili')
    test_update_logic_with_dom_stub()
    print('TESTI 5/6 OK: yhden painalluksen päivityslogiikka ja näytönsäästäjän esto')
    test_beacon_server()
    print('TESTI 6/6 OK: Cog-käynnistystestin valmis-signaali toimii')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
