#!/usr/bin/env python3
from __future__ import annotations

import re
import sys
from pathlib import Path

TARGET = '4.39.1'
BASE = '4.38.2'
CSS_TAG = '<link rel="stylesheet" href="/v4/v4391-update-ui.css?v=4.39.1">'
JS_TAG = '<script defer src="/v4/v4391-update-ui.js?v=4.39.1"></script>'


def extract(pattern: str, text: str, label: str) -> str:
    match = re.search(pattern, text, flags=re.MULTILINE)
    if not match:
        raise RuntimeError(f'{label}-versionumeroa ei löytynyt')
    return match.group(1)


def replace_once(pattern: str, replacement: str, text: str, label: str) -> str:
    result, count = re.subn(pattern, replacement, text, count=1, flags=re.MULTILINE)
    if count != 1:
        raise RuntimeError(f'{label}: odotettua kohtaa ei löytynyt täsmälleen kerran')
    return result


def patch(index: str, app: str, api: str) -> tuple[str, str, str]:
    index_version = extract(r'<title>NSPIRE V([0-9]+\.[0-9]+\.[0-9]+)</title>', index, 'index.html')
    app_version = extract(r'(?:var|let|const)\s+APP_VERSION\s*=\s*[\'\"]([0-9]+\.[0-9]+\.[0-9]+)[\'\"]', app, 'frontend')
    api_version = extract(r'^APP_VERSION\s*=\s*[\'\"]([0-9]+\.[0-9]+\.[0-9]+)[\'\"]', api, 'backend')
    versions = {index_version, app_version, api_version}
    if len(versions) != 1:
        raise RuntimeError(f'Versiot eivät täsmää: index={index_version}, frontend={app_version}, backend={api_version}')
    current = versions.pop()
    if current not in {BASE, TARGET}:
        raise RuntimeError(f'V{TARGET} vaatii V{BASE}-pohjan, laitteessa on V{current}')

    if current == BASE:
        index = replace_once(r'<title>NSPIRE V4\.38\.2</title>', f'<title>NSPIRE V{TARGET}</title>', index, 'index.html')
        app = replace_once(
            r'((?:var|let|const)\s+APP_VERSION\s*=\s*[\'\"])4\.38\.2([\'\"]\s*;)',
            rf'\g<1>{TARGET}\g<2>', app, 'frontend APP_VERSION'
        )
        api = replace_once(
            r'(^APP_VERSION\s*=\s*[\'\"])4\.38\.2([\'\"])',
            rf'\g<1>{TARGET}\g<2>', api, 'backend APP_VERSION'
        )
        api = re.sub(r'Nspire V4\.38\.2 API listening', f'Nspire V{TARGET} API listening', api, count=1)

    if CSS_TAG not in index:
        if '</head>' in index:
            index = index.replace('</head>', f'  {CSS_TAG}\n</head>', 1)
        else:
            raise RuntimeError('index.html: </head> puuttuu')
    if JS_TAG not in index:
        if '</body>' in index:
            index = index.replace('</body>', f'  {JS_TAG}\n</body>', 1)
        else:
            raise RuntimeError('index.html: </body> puuttuu')

    if index.count(CSS_TAG) != 1 or index.count(JS_TAG) != 1:
        raise RuntimeError('Erillisten V4.39.1-resurssien linkitys ei ole yksikäsitteinen')
    return index, app, api


def main(argv: list[str]) -> int:
    if len(argv) != 5:
        raise SystemExit('usage: install_patch.py index.html app.js nspire_v4_api.py output_dir')
    index_path, app_path, api_path, output_dir = map(Path, argv[1:])
    output_dir.mkdir(parents=True, exist_ok=True)
    index, app, api = patch(
        index_path.read_text(encoding='utf-8'),
        app_path.read_text(encoding='utf-8'),
        api_path.read_text(encoding='utf-8'),
    )
    (output_dir / 'index.html').write_text(index, encoding='utf-8')
    (output_dir / 'app.js').write_text(app, encoding='utf-8')
    (output_dir / 'nspire_v4_api.py').write_text(api, encoding='utf-8')
    return 0


if __name__ == '__main__':
    raise SystemExit(main(sys.argv))
