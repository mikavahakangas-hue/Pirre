#!/usr/bin/env bash
set -Eeuo pipefail

PKG="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VERSION="$(tr -d '[:space:]' < "$PKG/VERSION")"
[[ "$VERSION" == "4.39.1" ]] || { echo "VIRHE: väärä OTA-versio: $VERSION" >&2; exit 1; }

cd "$PKG"
sha256sum -c --quiet SHA256SUMS
python3 -m py_compile "$PKG/install_patch.py" "$PKG/ui_beacon.py"
if command -v node >/dev/null 2>&1; then node --check "$PKG/v4391-update-ui.js"; fi

if [[ "${NSPIRE_PREFLIGHT_ONLY:-0}" == "1" ]]; then
  echo "V4.39.1 OTA-esitarkistus OK"
  exit 0
fi

ROOT="${NSPIRE_OTA_TEST_ROOT:-}"
STATIC="$ROOT/opt/nspire-ui/static"
V4STATIC="$STATIC/v4"
APPDIR="$ROOT/opt/nspire-v4"
BACKUP_ROOT="$ROOT/root/nspire-backup"
BACKUP="$BACKUP_ROOT/ota_before_4_39_1_$(date +%F-%H%M%S)"

if [[ -z "$ROOT" && "${EUID:-$(id -u)}" -ne 0 ]]; then
  exec sudo -E bash "$0"
fi

[[ -f "$STATIC/index.html" ]] || { echo "VIRHE: index.html puuttuu" >&2; exit 1; }
[[ -f "$V4STATIC/app.js" ]] || { echo "VIRHE: app.js puuttuu" >&2; exit 1; }
[[ -f "$APPDIR/nspire_v4_api.py" ]] || { echo "VIRHE: backend puuttuu" >&2; exit 1; }

grep -q '<title>NSPIRE V4.38.2</title>\|<title>NSPIRE V4.39.1</title>' "$STATIC/index.html" || {
  echo "VIRHE: V4.39.1 vaatii toimivan V4.38.2-pohjan" >&2
  exit 1
}

mkdir -p "$BACKUP" "$V4STATIC"
cp -a "$STATIC/index.html" "$BACKUP/index.html"
cp -a "$V4STATIC/app.js" "$BACKUP/app.js"
cp -a "$APPDIR/nspire_v4_api.py" "$BACKUP/nspire_v4_api.py"
[[ -e "$V4STATIC/v4391-update-ui.js" ]] && cp -a "$V4STATIC/v4391-update-ui.js" "$BACKUP/" || true
[[ -e "$V4STATIC/v4391-update-ui.css" ]] && cp -a "$V4STATIC/v4391-update-ui.css" "$BACKUP/" || true

TMP="$(mktemp -d -t nspire-ota4391-XXXXXX)"
MARKER="$TMP/cog-ui-ready"
BEACON_PID=""

clear_cog_cache() {
  rm -rf /home/*/.cache/cog \
         /home/*/.cache/wpewebkit \
         /home/*/.cache/WebKit 2>/dev/null || true
}

cleanup() {
  if [[ -n "$BEACON_PID" ]]; then kill "$BEACON_PID" 2>/dev/null || true; fi
  rm -rf "$TMP"
}

rollback() {
  local rc=${1:-1}
  echo "VIRHE: V4.39.1 ei läpäissyt Cog-käynnistystestiä, palautetaan V4.38.2" >&2
  install -m 0644 "$BACKUP/index.html" "$STATIC/index.html" 2>/dev/null || true
  install -m 0644 "$BACKUP/app.js" "$V4STATIC/app.js" 2>/dev/null || true
  install -m 0644 "$BACKUP/nspire_v4_api.py" "$APPDIR/nspire_v4_api.py" 2>/dev/null || true
  if [[ -e "$BACKUP/v4391-update-ui.js" ]]; then
    install -m 0644 "$BACKUP/v4391-update-ui.js" "$V4STATIC/v4391-update-ui.js" 2>/dev/null || true
  else
    rm -f "$V4STATIC/v4391-update-ui.js"
  fi
  if [[ -e "$BACKUP/v4391-update-ui.css" ]]; then
    install -m 0644 "$BACKUP/v4391-update-ui.css" "$V4STATIC/v4391-update-ui.css" 2>/dev/null || true
  else
    rm -f "$V4STATIC/v4391-update-ui.css"
  fi
  if [[ -z "$ROOT" ]]; then
    systemctl restart nspire-v4.service 2>/dev/null || true
    clear_cog_cache
    systemctl restart kiosk-cog.service 2>/dev/null || true
  fi
  cleanup
  exit "$rc"
}
trap 'rollback $?' ERR
trap cleanup EXIT

python3 "$PKG/install_patch.py" \
  "$STATIC/index.html" "$V4STATIC/app.js" "$APPDIR/nspire_v4_api.py" "$TMP"
python3 -m py_compile "$TMP/nspire_v4_api.py"
if command -v node >/dev/null 2>&1; then node --check "$TMP/app.js"; fi

grep -q '<title>NSPIRE V4.39.1</title>' "$TMP/index.html"
grep -Eq "APP_VERSION[[:space:]]*=[[:space:]]*['\"]4\.39\.1['\"]" "$TMP/app.js"
grep -Eq "^APP_VERSION[[:space:]]*=[[:space:]]*['\"]4\.39\.1['\"]" "$TMP/nspire_v4_api.py"
grep -q '/v4/v4391-update-ui.js?v=4.39.1' "$TMP/index.html"
grep -q '/v4/v4391-update-ui.css?v=4.39.1' "$TMP/index.html"

install -m 0644 "$TMP/index.html" "$STATIC/index.html"
install -m 0644 "$TMP/app.js" "$V4STATIC/app.js"
install -m 0644 "$TMP/nspire_v4_api.py" "$APPDIR/nspire_v4_api.py"
install -m 0644 "$PKG/v4391-update-ui.js" "$V4STATIC/v4391-update-ui.js"
install -m 0644 "$PKG/v4391-update-ui.css" "$V4STATIC/v4391-update-ui.css"

if [[ -z "$ROOT" ]]; then
  python3 "$PKG/ui_beacon.py" --marker "$MARKER" --port 8094 &
  BEACON_PID=$!

  systemctl restart nspire-v4.service
  backend_ok=0
  for _ in $(seq 1 60); do
    if python3 - <<'PY' >/dev/null 2>&1
import json
import urllib.request
with urllib.request.urlopen('http://127.0.0.1:8093/health', timeout=2) as response:
    data = json.load(response)
assert data.get('ok') and data.get('version') == '4.39.1'
PY
    then
      backend_ok=1
      break
    fi
    sleep 0.5
  done
  [[ "$backend_ok" == "1" ]] || rollback 1

  clear_cog_cache
  systemctl restart kiosk-cog.service
  systemctl is-active --quiet kiosk-cog.service || rollback 1

  ui_ok=0
  for _ in $(seq 1 360); do
    [[ -s "$MARKER" ]] && { ui_ok=1; break; }
    systemctl is-active --quiet kiosk-cog.service || rollback 1
    sleep 0.5
  done
  [[ "$ui_ok" == "1" ]] || rollback 1
fi

trap - ERR
cleanup
echo "V4.39.1 OTA-asennus ja Cog-käyttöliittymän käynnistystesti OK"
