#!/usr/bin/env bash
set -Eeuo pipefail
PKG="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VERSION="$(tr -d '[:space:]' < "$PKG/VERSION")"
[[ "$VERSION" == "4.40.1" ]] || { echo "VIRHE: väärä OTA-versio: $VERSION" >&2; exit 1; }
cd "$PKG"
sha256sum -c --quiet SHA256SUMS
bash -n "$PKG/install.sh"

ROOT="${NSPIRE_OTA_TEST_ROOT:-}"
STATIC="$ROOT/opt/nspire-ui/static"
CSS="$STATIC/v4/app.css"
JS="$STATIC/v4/app.js"
INDEX="$STATIC/index.html"
API="$ROOT/opt/nspire-v4/nspire_v4_api.py"
BACKUP_ROOT="$ROOT/root/nspire-backup"
BACKUP="$BACKUP_ROOT/ota_before_4_40_1_$(date +%F-%H%M%S)-$$"

for file in "$CSS" "$JS" "$INDEX" "$API"; do
  [[ -f "$file" ]] || { echo "VIRHE: tiedosto puuttuu: $file" >&2; exit 1; }
done

grep -q "APP_VERSION='4.40.0'" "$JS" || { echo "VIRHE: nykyinen frontend ei ole V4.40.0" >&2; exit 1; }
grep -q 'APP_VERSION = "4.40.0"' "$API" || { echo "VIRHE: nykyinen backend ei ole V4.40.0" >&2; exit 1; }
grep -q 'font-weight:780!important' "$CSS" || { echo "VIRHE: odotettua SOHVA-kellon sääntöä ei löytynyt" >&2; exit 1; }
grep -q 'font-size:52px!important' "$CSS" || { echo "VIRHE: odotettua SOHVA-lämpötilan sääntöä ei löytynyt" >&2; exit 1; }

python3 -m py_compile "$API"
if command -v node >/dev/null 2>&1; then node --check "$JS"; fi

echo "V4.40.1 OTA-esitarkistus OK"
[[ "${NSPIRE_PREFLIGHT_ONLY:-0}" == "1" ]] && exit 0

if [[ -z "$ROOT" && "${EUID:-$(id -u)}" -ne 0 ]]; then
  exec sudo -E bash "$0"
fi

mkdir -p "$BACKUP"
cp -a "$CSS" "$JS" "$INDEX" "$API" "$BACKUP/"
printf '%s\n' "$BACKUP" > "$BACKUP_ROOT/ui_v4_last_backup.txt"

rollback(){
  local rc=$?
  if [[ $rc -ne 0 ]]; then
    echo "VIRHE: V4.40.1 epäonnistui, palautetaan V4.40.0" >&2
    cp -a "$BACKUP/app.css" "$CSS" 2>/dev/null || true
    cp -a "$BACKUP/app.js" "$JS" 2>/dev/null || true
    cp -a "$BACKUP/index.html" "$INDEX" 2>/dev/null || true
    cp -a "$BACKUP/nspire_v4_api.py" "$API" 2>/dev/null || true
    if [[ -z "$ROOT" ]]; then
      systemctl restart nspire-v4.service 2>/dev/null || true
      systemctl restart kiosk-cog.service 2>/dev/null || true
    fi
  fi
  exit "$rc"
}
trap rollback ERR

python3 - "$CSS" "$JS" "$INDEX" "$API" <<'PY'
from pathlib import Path
import sys
css_p, js_p, index_p, api_p = map(Path, sys.argv[1:])
css = css_p.read_text(encoding='utf-8')
js = js_p.read_text(encoding='utf-8')
index = index_p.read_text(encoding='utf-8')
api = api_p.read_text(encoding='utf-8')

clock_old = '.saver-sofa .sofa-clock strong{font-size:126px!important;line-height:.78!important;font-weight:780!important;letter-spacing:-.082em!important;'
clock_new = '.saver-sofa .sofa-clock strong{font-size:126px!important;line-height:.78!important;font-weight:520!important;letter-spacing:-.065em!important;'
temp_old = '.saver-sofa .sofa-metric>strong{font-size:52px!important;'
temp_new = '.saver-sofa .sofa-metric>strong{font-size:64px!important;'

if css.count(clock_old) != 1: raise SystemExit('SOHVA-kellon sääntö ei täsmää')
if css.count(temp_old) != 1: raise SystemExit('SOHVA-lämpötilan sääntö ei täsmää')
css = css.replace(clock_old, clock_new, 1).replace(temp_old, temp_new, 1)
css = css.replace('V4.40.0', 'V4.40.1')
js = js.replace('4.40.0', '4.40.1')
index = index.replace('4.40.0', '4.40.1')
api = api.replace('4.40.0', '4.40.1')

css_p.write_text(css, encoding='utf-8')
js_p.write_text(js, encoding='utf-8')
index_p.write_text(index, encoding='utf-8')
api_p.write_text(api, encoding='utf-8')
PY

python3 -m py_compile "$API"
if command -v node >/dev/null 2>&1; then node --check "$JS"; fi
grep -q "APP_VERSION='4.40.1'" "$JS"
grep -q 'APP_VERSION = "4.40.1"' "$API"
grep -q 'font-weight:520!important' "$CSS"
grep -q 'font-size:64px!important' "$CSS"

if [[ -z "$ROOT" ]]; then
  systemctl restart nspire-v4.service
  ok=0
  for _ in $(seq 1 40); do
    if python3 - <<'PY' >/dev/null 2>&1
import json, urllib.request
with urllib.request.urlopen('http://127.0.0.1:8093/health', timeout=2) as r:
    data=json.load(r)
assert data.get('ok') and data.get('version') == '4.40.1'
PY
    then ok=1; break; fi
    sleep 0.5
  done
  [[ "$ok" == 1 ]] || { echo "VIRHE: V4.40.1 backend ei käynnistynyt" >&2; exit 1; }
  systemctl restart kiosk-cog.service
fi

trap - ERR
echo "V4.40.1 OTA-asennus OK"
