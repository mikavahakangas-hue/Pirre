#!/usr/bin/env bash
set -Eeuo pipefail
umask 077

VERSION="7.1.2"
URL="https://raw.githubusercontent.com/mikavahakangas-hue/Pirre/db05190b496f18b8eafe40dc24d6be25a351cd46/releases/nspire_v7_1_0_v42_rebuild.tar.gz"
EXPECTED_SHA="68ca0732f09ee35766379bc4399489bef154f5108496a39adde19e9f267e6b7b"
EXPECTED_SIZE="83074"
WORK="$(mktemp -d /tmp/nspire-v712-bootstrap.XXXXXX)"
ARCHIVE="$WORK/v710.tar.gz"
EXTRACT="$WORK/extract"
LOG="${NSPIRE_LOG:-/var/log/nspire-v6-update.log}"
SOURCE_FILE="${NSPIRE_SOURCE_FILE:-}"
TEST_ONLY="${NSPIRE_BOOTSTRAP_TEST_ONLY:-0}"
PHASE="alustus"

say(){ printf '%s [V%s bootstrap · %s] %s\n' "$(date -Is)" "$VERSION" "$PHASE" "$*" | tee -a "$LOG"; }
cleanup(){ rm -rf "$WORK"; }
trap cleanup EXIT INT TERM

[[ ${EUID:-$(id -u)} -eq 0 ]] || { echo "Aja päivitys root-oikeuksilla." >&2; exit 1; }
for cmd in python3 sha256sum tar sed grep find sort xargs bash tee date cp stat; do
  command -v "$cmd" >/dev/null 2>&1 || { echo "Komento puuttuu: $cmd" >&2; exit 1; }
done
mkdir -p "$(dirname "$LOG")" "$EXTRACT"

PHASE="lataus"
if [[ -n "$SOURCE_FILE" ]]; then
  say "Käytetään paikallista varmennettua pohjapakettia"
  cp -f "$SOURCE_FILE" "$ARCHIVE"
else
  say "Ladataan varmennettu 0,08 Mt pohjapaketti (pitkä aikakatkaisu)"
  python3 - "$URL" "$ARCHIVE" "$LOG" <<'PY'
import os, sys, time, urllib.request
url, out, log = sys.argv[1:]
last = None
for attempt in range(1, 4):
    tmp = out + '.part'
    try:
        req = urllib.request.Request(
            url + ('?' if '?' not in url else '&') + 'nspire_v712=' + str(int(time.time())),
            headers={'User-Agent':'NSPIRE-V7.1.2-Updater','Cache-Control':'no-cache'}
        )
        with urllib.request.urlopen(req, timeout=300) as src, open(tmp, 'wb') as dst:
            total = 0
            while True:
                block = src.read(16384)
                if not block:
                    break
                dst.write(block)
                total += len(block)
        os.replace(tmp, out)
        with open(log, 'a', encoding='utf-8') as fh:
            fh.write(f"{time.strftime('%Y-%m-%dT%H:%M:%S%z')} [V7.1.2 bootstrap · lataus] Ladattu {total} tavua yrityksellä {attempt}\n")
        break
    except Exception as exc:
        last = exc
        try: os.remove(tmp)
        except FileNotFoundError: pass
        with open(log, 'a', encoding='utf-8') as fh:
            fh.write(f"{time.strftime('%Y-%m-%dT%H:%M:%S%z')} [V7.1.2 bootstrap · lataus] Yritys {attempt}/3 epäonnistui: {type(exc).__name__}: {exc}\n")
        if attempt < 3:
            time.sleep(5)
else:
    raise SystemExit(f"Pohjapaketin lataus epäonnistui: {type(last).__name__}: {last}")
PY
fi

PHASE="tarkistus"
ACTUAL_SIZE="$(stat -c '%s' "$ARCHIVE")"
[[ "$ACTUAL_SIZE" == "$EXPECTED_SIZE" ]] || { say "VIRHE: koko $ACTUAL_SIZE, odotettiin $EXPECTED_SIZE"; exit 1; }
echo "$EXPECTED_SHA  $ARCHIVE" | sha256sum -c -
python3 - "$ARCHIVE" <<'PY'
import sys, tarfile
p=sys.argv[1]
with tarfile.open(p,'r:gz') as tf:
    for m in tf.getmembers():
        n=m.name
        if n.startswith('/') or '..' in n.split('/') or m.issym() or m.islnk():
            raise SystemExit('Turvaton arkistopolku: '+n)
PY

tar -xzf "$ARCHIVE" -C "$EXTRACT"
PKG="$(find "$EXTRACT" -mindepth 1 -maxdepth 1 -type d | head -n1)"
[[ -n "$PKG" && -x "$PKG/install.sh" && -x "$PKG/selftest.sh" ]] || { say "VIRHE: pohjapaketin rakenne ei kelpaa"; exit 1; }

PHASE="version muunnos"
while IFS= read -r -d '' file; do
  sed -i 's/7\.1\.0/7.1.2/g; s/v7_1_0_v42_rebuild_before_/v7_1_2_v42_rebuild_before_/g' "$file"
done < <(grep -RIlZ --exclude='SHA256SUMS' '7\.1\.0\|v7_1_0_v42_rebuild_before_' "$PKG")
printf '7.1.2\n' > "$PKG/VERSION"
find "$PKG" -type d -name __pycache__ -prune -exec rm -rf {} +
find "$PKG" -type f -name '*.pyc' -delete
(
  cd "$PKG"
  find . -type f ! -name SHA256SUMS -printf '%P\0' | sort -z | xargs -0 sha256sum > SHA256SUMS
)

PHASE="selftest"
(cd "$PKG" && ./selftest.sh)
grep -q '__version__ = "7.1.2"' "$PKG/payload/__init__.py"
grep -q 'VERSION="7.1.2"' "$PKG/install.sh"

if [[ "$TEST_ONLY" == "1" ]]; then
  say "TESTI OK · lataus, SHA-256, arkistoturva, version muunnos ja selftest"
  exit 0
fi

PHASE="asennus"
exec "$PKG/install.sh"
