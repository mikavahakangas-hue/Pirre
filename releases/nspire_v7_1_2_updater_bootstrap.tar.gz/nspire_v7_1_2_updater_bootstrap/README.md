# NSPIRE V7.1.2 updater bootstrap

Lataa V7.1-pohjapaketin Pythonin pitkällä aikakatkaisulla, tarkistaa koon ja SHA-256:n, muuntaa sisäisen version V7.1.2:ksi, ajaa selftestit ja käynnistää varsinaisen asentimen.
