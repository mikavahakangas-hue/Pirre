#!/usr/bin/env bash
set -Eeuo pipefail
umask 022
export PYTHONDONTWRITEBYTECODE=1

PKG_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
LIVE=/opt/nspire-v6
TARGET="$LIVE/nspire/__init__.py"
USER_NAME=mavks
USER_HOME=/home/mavks
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP="/root/nspire-backup/v6_0_7_desktop_before_${STAMP}"
LOG=/var/log/nspire-v6-update.log
REPORT="$USER_HOME/NSPIRE-v6-desktop-recovery-${STAMP}.txt"
REPORT_LATEST="$USER_HOME/NSPIRE-v6-desktop-recovery-latest.txt"
SUCCESS=0
BACKEND_WAS_ACTIVE=0
KIOSK_WAS_ACTIVE=0
CURRENT_VERSION="tuntematon"
PHASE="alustus"
STATE_LIST=""

say(){
  local line
  line="$(date -Is) [$PHASE] $*"
  printf '%s\n' "$line" | tee -a "$LOG"
  printf '%s\n' "$line" >> "$REPORT" 2>/dev/null || true
}
fail(){ say "VIRHE: $*"; return 1; }

[[ ${EUID:-$(id -u)} -eq 0 ]] || { echo "Aja asennin root-oikeuksilla." >&2; exit 1; }
for cmd in python3 systemctl curl sha256sum find sort cp rm mkdir chown awk grep; do
  command -v "$cmd" >/dev/null 2>&1 || { echo "Komento puuttuu: $cmd" >&2; exit 1; }
done
[[ -f "$TARGET" ]] || { echo "V6-runtimea ei löytynyt: $TARGET" >&2; exit 1; }
mkdir -p "$USER_HOME"
: > "$REPORT"

cd "$PKG_DIR"
PHASE="paketin tarkistus"
sha256sum -c SHA256SUMS
bash -n install.sh

CURRENT_VERSION="$(python3 - "$TARGET" <<'PY'
from pathlib import Path
import re, sys
text = Path(sys.argv[1]).read_text(encoding='utf-8')
m = re.search(r'(?m)^\s*__version__\s*=\s*["\']([^"\']+)["\']', text)
print(m.group(1) if m else '')
PY
)"
case "$CURRENT_VERSION" in
  6.0.4|6.0.5|6.0.6) ;;
  6.0.7) say "V6.0.7 on jo asennettu"; exit 0 ;;
  *) fail "Päivitys vaatii V6.0.4–V6.0.6:n. Nykyinen: ${CURRENT_VERSION:-tuntematon}" ;;
esac

systemctl is-active --quiet nspire-v6.service && BACKEND_WAS_ACTIVE=1 || true
systemctl is-active --quiet nspire-kiosk.service && KIOSK_WAS_ACTIVE=1 || true
mkdir -p "$BACKUP/browser-state"
cp -a "$TARGET" "$BACKUP/__init__.py"

stop_unit(){
  local unit="$1"
  systemctl stop "$unit" >/dev/null 2>&1 || true
  for _ in $(seq 1 20); do
    systemctl is-active --quiet "$unit" || return 0
    sleep 0.5
  done
  systemctl kill --kill-who=all --signal=SIGKILL "$unit" >/dev/null 2>&1 || true
  systemctl stop "$unit" >/dev/null 2>&1 || true
  systemctl is-active --quiet "$unit" && return 1 || return 0
}

collect_state_dirs(){
  {
    for p in \
      "$USER_HOME/.cache/cog" \
      "$USER_HOME/.cache/wpe" \
      "$USER_HOME/.cache/wpe-webkit" \
      "$USER_HOME/.cache/WebKit" \
      "$USER_HOME/.local/share/cog" \
      "$USER_HOME/.local/share/wpe" \
      "$USER_HOME/.local/share/wpe-webkit" \
      "$USER_HOME/.local/share/WebKit" \
      "$USER_HOME/.local/share/webkitgtk"; do
      [[ -e "$p" ]] && printf '%s\n' "$p"
    done
    for root in "$USER_HOME/.cache" "$USER_HOME/.local/share"; do
      [[ -d "$root" ]] || continue
      find "$root" -mindepth 1 -maxdepth 2 -type d \
        \( -iname 'cog' -o -iname 'cog-*' -o -iname 'wpe' -o -iname 'wpe-*' \
           -o -iname 'webkit' -o -iname 'webkit-*' -o -iname 'webkitgtk' \) -print 2>/dev/null || true
    done
  } | sort -u
}

backup_state_dirs(){
  local p rel dst
  STATE_LIST="$BACKUP/browser-state-paths.txt"
  : > "$STATE_LIST"
  while IFS= read -r p; do
    [[ -n "$p" && -e "$p" ]] || continue
    rel="${p#/}"
    dst="$BACKUP/browser-state/$rel"
    mkdir -p "$(dirname "$dst")"
    cp -a "$p" "$dst"
    printf '%s\n' "$p" >> "$STATE_LIST"
  done < <(collect_state_dirs)
}

restore_state_dirs(){
  local p rel src
  [[ -n "$STATE_LIST" && -f "$STATE_LIST" ]] || return 0
  while IFS= read -r p; do
    [[ -n "$p" ]] || continue
    rel="${p#/}"
    src="$BACKUP/browser-state/$rel"
    rm -rf "$p"
    [[ -e "$src" ]] || continue
    mkdir -p "$(dirname "$p")"
    cp -a "$src" "$p"
  done < "$STATE_LIST"
}

restore(){
  local code=$?
  [[ "$SUCCESS" -eq 1 ]] && return 0
  trap - ERR INT TERM EXIT
  PHASE="palautus"
  say "Asennus epäonnistui — palautetaan V$CURRENT_VERSION ja selaintila"
  stop_unit nspire-kiosk.service || true
  stop_unit nspire-v6.service || true
  cp -a "$BACKUP/__init__.py" "$TARGET"
  rm -rf "$LIVE/nspire/__pycache__" >/dev/null 2>&1 || true
  restore_state_dirs || true
  systemctl daemon-reload || true
  systemctl reset-failed nspire-v6.service nspire-kiosk.service >/dev/null 2>&1 || true
  [[ "$BACKEND_WAS_ACTIVE" -eq 1 ]] && systemctl start nspire-v6.service >/dev/null 2>&1 || true
  [[ "$KIOSK_WAS_ACTIVE" -eq 1 ]] && systemctl start nspire-kiosk.service >/dev/null 2>&1 || true
  chown "$USER_NAME:$USER_NAME" "$REPORT" >/dev/null 2>&1 || true
  cp -f "$REPORT" "$REPORT_LATEST" >/dev/null 2>&1 || true
  chown "$USER_NAME:$USER_NAME" "$REPORT_LATEST" >/dev/null 2>&1 || true
  say "Palautus valmis: $BACKUP"
  exit "$code"
}
trap restore ERR INT TERM EXIT

PHASE="diagnostiikka ennen muutosta"
{
  echo "NSPIRE V6.0.7 työpöydän palautus"
  echo "Aika: $(date -Is)"
  echo "Lähtöversio: $CURRENT_VERSION"
  echo "Backend aktiivinen ennen: $BACKEND_WAS_ACTIVE"
  echo "Kioski aktiivinen ennen: $KIOSK_WAS_ACTIVE"
  echo
  echo "Kioskipalvelu:"
  systemctl cat nspire-kiosk.service 2>&1 || true
  echo
  echo "Frontend-ehdokkaat:"
  find "$LIVE" -maxdepth 5 -type f \( -name '*.html' -o -name '*.css' -o -name '*.js' \) -printf '%p %s bytes\n' 2>/dev/null | sort || true
  echo
  echo "Juurisivun merkit ennen:"
  curl -fsS --noproxy '*' --connect-timeout 2 --max-time 8 http://127.0.0.1:8765/ 2>/dev/null \
    | grep -Eo 'app-grid|app-tile|data-view=["'\'' ]*home|NSPIRE 6' \
    | sort | uniq -c || true
  echo
} >> "$REPORT"

PHASE="varmuuskopio"
backup_state_dirs
say "Varmuuskopioitiin $(wc -l < "$STATE_LIST" | tr -d ' ') selaintilakohdetta"

PHASE="palvelujen pysäytys"
[[ "$KIOSK_WAS_ACTIVE" -eq 1 ]] && stop_unit nspire-kiosk.service || true
[[ "$BACKEND_WAS_ACTIVE" -eq 1 ]] && stop_unit nspire-v6.service || true

PHASE="Cog/WPE-tilan nollaus"
while IFS= read -r p; do
  [[ -n "$p" ]] || continue
  say "Poistetaan vanha selaintila: $p"
  rm -rf "$p"
done < "$STATE_LIST"
find /tmp -mindepth 1 -maxdepth 1 -user "$USER_NAME" \
  \( -name 'cog-*' -o -name 'wpe-*' -o -name 'webkit-*' \) \
  -exec rm -rf {} + 2>/dev/null || true

PHASE="version päivitys"
python3 - "$TARGET" <<'PY'
from pathlib import Path
import os, re, sys, tempfile
path = Path(sys.argv[1])
text = path.read_text(encoding='utf-8')
pattern = re.compile(r'(?m)^(\s*__version__\s*=\s*)["\'][^"\']+["\'](\s*)$')
new_text, count = pattern.subn(r'\1"6.0.7"\2', text, count=1)
if count != 1:
    raise SystemExit("__version__-riviä ei löytynyt yksikäsitteisesti")
fd, tmp = tempfile.mkstemp(prefix=path.name + '.', dir=str(path.parent))
try:
    with os.fdopen(fd, 'w', encoding='utf-8', newline='') as f:
        f.write(new_text)
        f.flush()
        os.fsync(f.fileno())
    os.chmod(tmp, 0o644)
    os.chown(tmp, 0, 0)
    os.replace(tmp, path)
finally:
    if os.path.exists(tmp):
        os.unlink(tmp)
PY
rm -rf "$LIVE/nspire/__pycache__" >/dev/null 2>&1 || true
python3 -m py_compile "$TARGET"

PHASE="backendin käynnistys"
systemctl daemon-reload
systemctl reset-failed nspire-v6.service nspire-kiosk.service >/dev/null 2>&1 || true
systemctl start nspire-v6.service
for _ in $(seq 1 60); do
  systemctl is-active --quiet nspire-v6.service && \
    curl -fsS --noproxy '*' --connect-timeout 2 --max-time 5 http://127.0.0.1:8765/api/health >/dev/null 2>&1 && break
  sleep 1
done
systemctl is-active --quiet nspire-v6.service || fail "Backend ei käynnistynyt"
curl -fsS --noproxy '*' --connect-timeout 2 --max-time 5 http://127.0.0.1:8765/api/health >/dev/null || fail "Health-tarkistus epäonnistui"

PHASE="OTA-version tarkistus"
update_json="$(curl -fsS --noproxy '*' --connect-timeout 2 --max-time 8 http://127.0.0.1:8765/api/update)" || fail "OTA-tilaa ei saatu"
printf '%s' "$update_json" | python3 -c 'import json,sys; d=json.load(sys.stdin); v=str(d.get("current_version", "")); sys.exit(0 if v == "6.0.7" else 1)' \
  || fail "OTA-palvelu ei ilmoita nykyversioksi V6.0.7"

PHASE="juurisivun tarkistus"
root_tmp="$(mktemp)"
curl -fsS --noproxy '*' --connect-timeout 2 --max-time 8 http://127.0.0.1:8765/ > "$root_tmp" || fail "Juurisivua ei saatu"
python3 - "$root_tmp" <<'PY'
from pathlib import Path
import sys
text = Path(sys.argv[1]).read_text(encoding='utf-8', errors='replace')
if len(text.strip()) < 200:
    raise SystemExit("Juurisivu on poikkeuksellisen lyhyt")
if "NSPIRE" not in text.upper():
    raise SystemExit("Juurisivulta puuttuu NSPIRE-tunniste")
PY
{
  echo
  echo "Juurisivun merkit jälkeen:"
  grep -Eo 'app-grid|app-tile|data-view=["'\'' ]*home|NSPIRE 6' "$root_tmp" | sort | uniq -c || true
  echo "Juurisivun koko: $(wc -c < "$root_tmp" | tr -d ' ') tavua"
} >> "$REPORT"
rm -f "$root_tmp"

PHASE="kioskin käynnistys"
systemctl start nspire-kiosk.service
for _ in $(seq 1 40); do
  systemctl is-active --quiet nspire-kiosk.service && break
  sleep 1
done
systemctl is-active --quiet nspire-kiosk.service || fail "Cog-kioski ei käynnistynyt"

PHASE="vakaustarkistus"
for _ in 1 2 3 4; do
  systemctl is-active --quiet nspire-v6.service || fail "Backend pysähtyi vakaustarkistuksessa"
  systemctl is-active --quiet nspire-kiosk.service || fail "Kioski pysähtyi vakaustarkistuksessa"
  curl -fsS --noproxy '*' --connect-timeout 2 --max-time 5 http://127.0.0.1:8765/api/health >/dev/null \
    || fail "Health epäonnistui vakaustarkistuksessa"
  sleep 3
done

SUCCESS=1
trap - ERR INT TERM EXIT
PHASE="valmis"
say "V6.0.7 asennus OK · Cog/WPE-tila nollattu · varmuuskopio=$BACKUP"
cp -f "$REPORT" "$REPORT_LATEST"
chown "$USER_NAME:$USER_NAME" "$REPORT" "$REPORT_LATEST" >/dev/null 2>&1 || true
