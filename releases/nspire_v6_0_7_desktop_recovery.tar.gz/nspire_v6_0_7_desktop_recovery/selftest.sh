#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"
sha256sum -c SHA256SUMS
bash -n install.sh
python3 - "$ROOT/install.sh" <<'PY'
from pathlib import Path
import re, sys, tempfile
text = Path(sys.argv[1]).read_text(encoding='utf-8')
required = (
    '6.0.4|6.0.5|6.0.6',
    'Cog/WPE-tilan nollaus',
    'restore_state_dirs',
    'NSPIRE-v6-desktop-recovery-latest.txt',
    'json.load(sys.stdin)',
    'V6.0.7 asennus OK',
)
for marker in required:
    assert marker in text, marker
sample='''"""NSPIRE V6 clean runtime."""\n__version__ = "6.0.6"\n'''
pat=re.compile(r'(?m)^(\s*__version__\s*=\s*)["\'][^"\']+["\'](\s*)$')
out,count=pat.subn(r'\1"6.0.7"\2', sample, count=1)
assert count == 1 and '__version__ = "6.0.7"' in out
print('V6.0.7 DESKTOP RECOVERY SELFTEST OK')
PY
