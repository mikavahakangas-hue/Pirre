# NSPIRE V6.0.7 – työpöydän palautus

Rajattu korjauspäivitys tilanteeseen, jossa työpöytä/kotinäkymä jää mustaksi mutta muut näkymät ja OTA toimivat. Paketti ei tee sokkomuutoksia käyttöliittymän HTML-, CSS- tai JavaScript-lähteisiin. Se nollaa Cog/WPE WebKitin välimuistin ja sivustotilan, päivittää runtime-version 6.0.7:ään, käynnistää palvelut uudelleen ja tallentaa diagnostiikkaraportin polkuun `/home/mavks/NSPIRE-v6-desktop-recovery-latest.txt`.
