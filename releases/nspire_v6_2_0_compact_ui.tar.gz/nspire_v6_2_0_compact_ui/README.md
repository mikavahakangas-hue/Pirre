# NSPIRE V6.2.0 – kompakti käyttöliittymä

Tämä päivitys suunnittelee Unikellon ja Sää-sovelluksen uudelleen käyttäjän aiempien vaatimusten mukaisesti sekä poistaa sovellusnäkymien sivuttaisvierityksen 640×480-näytöllä.

## Unikello

- puhtaat punainen, keltainen ja vihreä tausta
- ei tilatekstejä unikellon varsinaisessa näyttötilassa
- valittavat 24 h kellonaika, sisälämpötila ja sisäkosteus
- suuret, kaukaa luettavat arvot
- koko näytön tila, josta palataan koskettamalla mitä tahansa kohtaa
- yö-, herätys-, keltainen vaihe- ja päiväuniasetukset säilyvät

## Sää

- tumma moderni sääasematyylinen päänäkymä
- nykyinen ulkolämpötila, säätila, tuntuma, kosteus, tuuli ja sade
- BME680:n sisälämpötila ja kosteus samassa näkymässä
- seuraavat kuusi tuntia kiinteässä ruudukossa
- seitsemän vuorokauden ennuste ilman sivuttaisvieritystä

## Kaikki sovellukset

- sivuttaisvieritys poistettu
- sisältö rajataan näytön leveyteen
- pitkät tekstit rivittyvät
- pörssisähkön tuntihinnat ja sääennusteet käyttävät kiinteitä ruudukoita
- vain pystysuuntainen vieritys jää käyttöön

Asennin varmuuskopioi muutettavat tiedostot ja palauttaa V6.1.2:n automaattisesti virheessä.
