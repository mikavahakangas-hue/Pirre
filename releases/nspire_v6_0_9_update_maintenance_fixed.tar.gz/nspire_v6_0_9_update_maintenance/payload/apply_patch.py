#!/usr/bin/env python3
"""Apply and verify the NSPIRE V6.0.9 update-maintenance patch safely."""

from __future__ import annotations

import argparse
import os
import re
import stat
import tempfile
from pathlib import Path

VERSION = "6.0.9"
CACHE_KEY = "609"
CSS_START = "/* NSPIRE V6.0.9 UPDATE UX START */"
CSS_END = "/* NSPIRE V6.0.9 UPDATE UX END */"
JS_START = "/* NSPIRE V6.0.9 UPDATE UX START */"
JS_END = "/* NSPIRE V6.0.9 UPDATE UX END */"
DESKTOP_START = "/* NSPIRE V6.0.8 DESKTOP VISIBILITY START */"
DESKTOP_END = "/* NSPIRE V6.0.8 DESKTOP VISIBILITY END */"

CSS_BLOCK = r'''/* NSPIRE V6.0.9 UPDATE UX START */
.v609-update-primary {
  width: 100% !important;
  min-height: 52px !important;
  font-weight: 800 !important;
}

.v609-update-secondary-hidden {
  display: none !important;
}

.v609-update-panel {
  margin-top: 12px;
  padding: 10px;
  border: 1px solid var(--line, #253243);
  border-radius: 10px;
  background: rgba(9, 17, 27, .78);
}

.v609-update-steps {
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 5px;
}

.v609-update-step {
  min-width: 0;
  padding: 7px 3px;
  border: 1px solid var(--line, #253243);
  border-radius: 7px;
  color: var(--muted, #9aa8b8);
  background: var(--panel, #111a25);
  font-size: 11px;
  line-height: 1.15;
  text-align: center;
}

.v609-update-step.is-active {
  border-color: var(--accent, #5aa7ff);
  color: #fff;
  box-shadow: inset 0 0 0 1px rgba(90, 167, 255, .22);
}

.v609-update-step.is-done {
  border-color: #2f8052;
  color: #8ee3ad;
}

.v609-update-step.is-error {
  border-color: #a83a3a;
  color: #ffaaaa;
}

.v609-update-message {
  margin-top: 8px;
  min-height: 20px;
  color: var(--muted, #a8b3c0);
  font-size: 13px;
  overflow-wrap: anywhere;
}

.v609-update-message.is-error {
  color: #ff9292;
}

.v609-update-log-toggle {
  width: 100%;
  margin-top: 8px;
  min-height: 38px;
}

.v609-update-log {
  display: none;
  max-height: 180px;
  margin: 8px 0 0;
  padding: 8px;
  overflow: auto;
  white-space: pre-wrap;
  overflow-wrap: anywhere;
  border: 1px solid var(--line, #253243);
  border-radius: 7px;
  background: #07101a;
  color: #c7d3df;
  font: 11px/1.35 monospace;
}

.v609-update-log.is-open {
  display: block;
}

body.nspire-update-busy .appbar button,
body.nspire-update-busy .app-tile,
body.nspire-update-busy #homeButton,
body.nspire-update-busy #backButton {
  pointer-events: none;
}
/* NSPIRE V6.0.9 UPDATE UX END */
'''

JS_BLOCK = r'''/* NSPIRE V6.0.9 UPDATE UX START */
(function () {
  'use strict';

  if (window.__nspireV609UpdateUx) return;
  window.__nspireV609UpdateUx = true;

  var PHASES = ['download', 'verify', 'install', 'restart'];
  var LABELS = {
    download: 'Ladataan',
    verify: 'Tarkistetaan',
    install: 'Asennetaan',
    restart: 'Käynnistetään'
  };
  var state = {
    busy: false,
    phase: '',
    target: '',
    pulseTimer: 0,
    log: []
  };

  function now() {
    try { return new Date().toLocaleTimeString('fi-FI', {hour12: false}); }
    catch (_) { return new Date().toISOString().slice(11, 19); }
  }

  function logEvent(message, data) {
    var line = now() + '  ' + String(message || '');
    if (data !== undefined) {
      try {
        var serialized = typeof data === 'string' ? data : JSON.stringify(data);
        if (serialized.length > 1400) serialized = serialized.slice(0, 1400) + '…';
        line += ' · ' + serialized;
      } catch (_) {}
    }
    state.log.push(line);
    if (state.log.length > 120) state.log.splice(0, state.log.length - 120);
    try { localStorage.setItem('nspireV609UpdateLog', state.log.join('\n')); } catch (_) {}
    renderLog();
  }

  function loadStoredLog() {
    try {
      var stored = localStorage.getItem('nspireV609UpdateLog');
      if (stored) state.log = stored.split('\n').slice(-120);
    } catch (_) {}
  }

  function updateRoot() {
    var content = document.getElementById('viewContent');
    var title = document.getElementById('viewTitle');
    if (!content) return null;
    var text = (title ? title.textContent : '') + ' ' + content.textContent;
    if (text.indexOf('Päivitykset') < 0 && text.indexOf('Turvallinen asennus') < 0 && text.indexOf('Uutta versiota') < 0) return null;
    return content;
  }

  function findButton(root, phrases) {
    if (!root) return null;
    var buttons = root.querySelectorAll('button');
    for (var i = 0; i < buttons.length; i += 1) {
      var text = (buttons[i].textContent || '').trim().toLowerCase();
      for (var j = 0; j < phrases.length; j += 1) {
        if (text.indexOf(phrases[j]) >= 0) return buttons[i];
      }
    }
    return null;
  }

  function ensurePanel(root) {
    if (!root) return null;
    var panel = document.getElementById('v609UpdatePanel');
    if (panel && root.contains(panel)) return panel;
    panel = document.createElement('section');
    panel.id = 'v609UpdatePanel';
    panel.className = 'v609-update-panel';
    panel.innerHTML =
      '<div class="v609-update-steps" aria-label="Päivityksen vaiheet">' +
      PHASES.map(function (name) {
        return '<div class="v609-update-step" data-v609-step="' + name + '">' + LABELS[name] + '</div>';
      }).join('') +
      '</div>' +
      '<div id="v609UpdateMessage" class="v609-update-message">Valmis päivityksen tarkistukseen.</div>' +
      '<button id="v609UpdateLogToggle" class="secondary v609-update-log-toggle" type="button">Näytä tapahtumaloki</button>' +
      '<pre id="v609UpdateLog" class="v609-update-log" aria-live="polite"></pre>';
    root.appendChild(panel);
    var toggle = document.getElementById('v609UpdateLogToggle');
    if (toggle) toggle.addEventListener('click', function () {
      var pre = document.getElementById('v609UpdateLog');
      if (!pre) return;
      var open = pre.classList.toggle('is-open');
      toggle.textContent = open ? 'Piilota tapahtumaloki' : 'Näytä tapahtumaloki';
      renderLog();
    });
    renderLog();
    renderPhase();
    return panel;
  }

  function renderLog() {
    var pre = document.getElementById('v609UpdateLog');
    if (pre) {
      pre.textContent = state.log.length ? state.log.join('\n') : 'Ei tapahtumia.';
      pre.scrollTop = pre.scrollHeight;
    }
  }

  function setMessage(message, isError) {
    var node = document.getElementById('v609UpdateMessage');
    if (!node) return;
    node.textContent = message || '';
    node.classList.toggle('is-error', !!isError);
  }

  function renderPhase(error) {
    var current = PHASES.indexOf(state.phase);
    for (var i = 0; i < PHASES.length; i += 1) {
      var node = document.querySelector('[data-v609-step="' + PHASES[i] + '"]');
      if (!node) continue;
      node.classList.remove('is-active', 'is-done', 'is-error');
      if (error && i === Math.max(current, 0)) node.classList.add('is-error');
      else if (i < current) node.classList.add('is-done');
      else if (i === current) node.classList.add('is-active');
    }
  }

  function startPulse() {
    if (state.pulseTimer) return;
    state.pulseTimer = window.setInterval(function () {
      try {
        document.dispatchEvent(new MouseEvent('mousemove', {bubbles: true, clientX: 1, clientY: 1}));
      } catch (_) {
        try { document.dispatchEvent(new Event('mousemove', {bubbles: true})); } catch (__) {}
      }
    }, 5000);
  }

  function stopPulse() {
    if (state.pulseTimer) window.clearInterval(state.pulseTimer);
    state.pulseTimer = 0;
  }

  function setBusy(busy) {
    state.busy = !!busy;
    document.body.classList.toggle('nspire-update-busy', state.busy);
    if (state.busy) startPulse(); else stopPulse();
  }

  function setPhase(phase, message) {
    if (PHASES.indexOf(phase) < 0) return;
    state.phase = phase;
    setBusy(true);
    renderPhase(false);
    setMessage(message || LABELS[phase] + '…', false);
    logEvent(message || LABELS[phase]);
  }

  function finishSuccess(message) {
    state.phase = 'restart';
    renderPhase(false);
    var nodes = document.querySelectorAll('[data-v609-step]');
    for (var i = 0; i < nodes.length; i += 1) {
      nodes[i].classList.remove('is-active', 'is-error');
      nodes[i].classList.add('is-done');
    }
    setMessage(message || 'Päivitys asennettu onnistuneesti.', false);
    logEvent(message || 'Päivitys onnistui');
    setBusy(false);
  }

  function finishError(message, payload) {
    var detail = message || 'Päivitys epäonnistui.';
    renderPhase(true);
    setMessage(detail, true);
    logEvent('VIRHE: ' + detail, payload);
    setBusy(false);
    var pre = document.getElementById('v609UpdateLog');
    var toggle = document.getElementById('v609UpdateLogToggle');
    if (pre) pre.classList.add('is-open');
    if (toggle) toggle.textContent = 'Piilota tapahtumaloki';
  }

  function deepValue(value, keys, depth) {
    if (depth > 4 || value === null || value === undefined) return '';
    if (typeof value === 'string') return value;
    if (typeof value !== 'object') return '';
    for (var i = 0; i < keys.length; i += 1) {
      if (typeof value[keys[i]] === 'string' && value[keys[i]].trim()) return value[keys[i]].trim();
    }
    var names = Object.keys(value);
    for (var j = 0; j < names.length; j += 1) {
      var found = deepValue(value[names[j]], keys, depth + 1);
      if (found) return found;
    }
    return '';
  }

  function extractError(payload, fallback) {
    var text = deepValue(payload, ['error', 'detail', 'reason', 'stderr', 'last_error', 'message'], 0);
    if (text) return text;
    return fallback || 'Päivitys epäonnistui ilman tarkempaa virheilmoitusta.';
  }

  function phaseFromPayload(payload) {
    var errorText = deepValue(payload, ['error', 'reason', 'stderr', 'last_error'], 0);
    if (errorText) return 'error';
    var raw = deepValue(payload, ['phase', 'status', 'state', 'status_text', 'message', 'detail'], 0).toLowerCase();
    if (!raw) return '';
    if (/virhe|failed|failure|palaut/.test(raw)) return 'error';
    if (/onnist|success|complete|valmis/.test(raw)) return 'success';
    if (/käynnist|restart|reboot|starting/.test(raw)) return 'restart';
    if (/asen|install|applying|unpack/.test(raw)) return 'install';
    if (/tarkist|verify|sha|checksum/.test(raw)) return 'verify';
    if (/lataa|download|fetch/.test(raw)) return 'download';
    return '';
  }

  function handlePayload(payload, source) {
    if (!payload || typeof payload !== 'object') return;
    var phase = phaseFromPayload(payload);
    if (source) logEvent(source, payload);
    if (phase === 'error') {
      finishError(extractError(payload), payload);
      return;
    }
    if (phase === 'success' && state.busy) {
      finishSuccess(deepValue(payload, ['message', 'status_text', 'detail'], 0) || 'Päivitys asennettu onnistuneesti.');
      return;
    }
    if (phase && PHASES.indexOf(phase) >= 0 && state.busy) {
      var msg = deepValue(payload, ['message', 'status_text', 'detail', 'phase'], 0);
      setPhase(phase, msg || LABELS[phase] + '…');
    }
  }

  function enhanceUpdateView() {
    var root = updateRoot();
    if (!root) return;
    ensurePanel(root);
    var install = findButton(root, ['lataa ja asenna', 'lataa ja päivitä']);
    var check = findButton(root, ['tarkista nyt', 'tarkista päivitykset']);
    if (install) {
      if ((install.textContent || '').trim() !== 'Lataa ja päivitä') install.textContent = 'Lataa ja päivitä';
      install.classList.add('v609-update-primary');
      if (check) check.classList.add('v609-update-secondary-hidden');
      if (!install.dataset.v609Bound) {
        install.dataset.v609Bound = '1';
        install.addEventListener('click', function () {
          state.target = '';
          setPhase('download', 'Ladataan päivityspakettia…');
          logEvent('Päivitys käynnistetty käyttäjän toimesta');
        }, true);
      }
    } else if (check) {
      check.classList.remove('v609-update-secondary-hidden');
    }
  }

  var originalFetch = window.fetch;
  if (typeof originalFetch === 'function') {
    window.fetch = function () {
      var args = arguments;
      var request = args[0];
      var url = typeof request === 'string' ? request : (request && request.url) || '';
      var options = args[1] || {};
      var method = String(options.method || (request && request.method) || 'GET').toUpperCase();
      var isInstall = url.indexOf('/api/update/install') >= 0;
      var isUpdateStatus = url.indexOf('/api/update') >= 0 && !isInstall && method === 'GET';
      if (isInstall && !state.busy) setPhase('download', 'Ladataan päivityspakettia…');
      return originalFetch.apply(this, args).then(function (response) {
        if (isInstall || isUpdateStatus) {
          try {
            response.clone().text().then(function (text) {
              var payload = text;
              try { payload = text ? JSON.parse(text) : {}; } catch (_) {}
              if (!response.ok) {
                finishError(extractError(payload, 'HTTP ' + response.status + ' ' + response.statusText), payload);
                return;
              }
              if (isInstall) {
                logEvent('Asennuspyyntö hyväksytty (HTTP ' + response.status + ')', payload);
                if (state.busy) setPhase('verify', 'Paketti ladattu, tarkistetaan eheys…');
              }
              handlePayload(payload, isUpdateStatus ? 'Päivitystila' : 'Asennusvastaus');
            }).catch(function (error) {
              if (isInstall) finishError('Asennusvastauksen lukeminen epäonnistui: ' + error.message);
            });
          } catch (error) {
            if (isInstall) finishError('Asennusvastauksen käsittely epäonnistui: ' + error.message);
          }
        }
        return response;
      }).catch(function (error) {
        if (isInstall || (isUpdateStatus && state.busy)) finishError('Verkkovirhe: ' + error.message);
        throw error;
      });
    };
  }

  loadStoredLog();
  document.addEventListener('DOMContentLoaded', enhanceUpdateView);
  window.addEventListener('popstate', function () { window.setTimeout(enhanceUpdateView, 0); });
  var observer = new MutationObserver(function () { enhanceUpdateView(); });
  observer.observe(document.documentElement, {subtree: true, childList: true});
  window.setInterval(function () {
    enhanceUpdateView();
    if (state.busy) {
      var healthVersion = document.body && document.body.textContent ? document.body.textContent : '';
      if (/NSPIRE\s+6\.0\.9/.test(healthVersion) || /V6\.0\.9\b/.test(healthVersion)) {
        finishSuccess('V6.0.9 käynnistyi ja käyttöliittymä vastaa.');
      }
    }
  }, 1500);
})();
/* NSPIRE V6.0.9 UPDATE UX END */
'''

VERSION_RE = re.compile(r'(?m)^(\s*__version__\s*=\s*)["\'][^"\']+["\'](\s*)$')
CSS_MANAGED_RE = re.compile(re.escape(CSS_START) + r".*?" + re.escape(CSS_END) + r"\s*", re.S)
JS_MANAGED_RE = re.compile(re.escape(JS_START) + r".*?" + re.escape(JS_END) + r"\s*", re.S)
CSS_HREF_RE = re.compile(r'(?P<prefix>href=["\']/app\.css)(?:\?v=[^"\']*)?(?P<suffix>["\'])')
JS_SRC_RE = re.compile(r'(?P<prefix>src=["\']/app\.js)(?:\?v=[^"\']*)?(?P<suffix>["\'])')


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def atomic_write(path: Path, text: str) -> None:
    st = path.stat()
    fd, tmp_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as handle:
            handle.write(text)
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(tmp_name, stat.S_IMODE(st.st_mode))
        try:
            os.chown(tmp_name, st.st_uid, st.st_gid)
        except PermissionError:
            pass
        os.replace(tmp_name, path)
        dir_fd = os.open(path.parent, os.O_DIRECTORY)
        try:
            os.fsync(dir_fd)
        finally:
            os.close(dir_fd)
    finally:
        if os.path.exists(tmp_name):
            os.unlink(tmp_name)


def validate_source(init_text: str, css_text: str, index_text: str, js_text: str) -> None:
    if len(VERSION_RE.findall(init_text)) != 1:
        raise ValueError("runtime-tiedostossa ei ole yksikäsitteistä __version__-riviä")
    for marker in (".view", ".app-grid", ".app-tile"):
        if marker not in css_text:
            raise ValueError(f"CSS-rakenne ei vastaa odotettua: {marker} puuttuu")
    if css_text.count(DESKTOP_START) != 1 or css_text.count(DESKTOP_END) != 1:
        raise ValueError("V6.0.8 työpöydän näkyvyyskorjaus ei ole yksikäsitteinen")
    for marker in ('id="homeView"', 'id="viewContent"', 'class="app-grid"', 'class="app-tile"'):
        if marker not in index_text:
            raise ValueError(f"etusivun rakenne ei vastaa odotettua: {marker} puuttuu")
    if index_text.count('class="app-tile"') < 8:
        raise ValueError("etusivulla on odotettua vähemmän sovelluslaattoja")
    for marker in ("showHome", "homeView", "viewContent", "/api/update"):
        if marker not in js_text:
            raise ValueError(f"app.js-rakenne ei vastaa odotettua: {marker} puuttuu")


def append_managed(text: str, managed_re: re.Pattern[str], block: str) -> str:
    return managed_re.sub("", text).rstrip() + "\n\n" + block.rstrip() + "\n"


def update_cache_key(index_text: str, pattern: re.Pattern[str], key: str, label: str) -> str:
    patched, count = pattern.subn(lambda m: f"{m.group('prefix')}?v={key}{m.group('suffix')}", index_text, count=1)
    if count != 1:
        raise ValueError(f"{label}-linkkiä ei löytynyt yksikäsitteisesti index.html-tiedostosta")
    return patched


def build_patched(init_text: str, css_text: str, index_text: str, js_text: str) -> tuple[str, str, str, str]:
    patched_init, count = VERSION_RE.subn(rf'\1"{VERSION}"\2', init_text, count=1)
    if count != 1:
        raise ValueError("runtime-version päivitys epäonnistui")
    patched_css = append_managed(css_text, CSS_MANAGED_RE, CSS_BLOCK)
    patched_js = append_managed(js_text, JS_MANAGED_RE, JS_BLOCK)
    patched_index = update_cache_key(index_text, CSS_HREF_RE, CACHE_KEY, "app.css")
    patched_index = update_cache_key(patched_index, JS_SRC_RE, CACHE_KEY, "app.js")
    return patched_init, patched_css, patched_index, patched_js


def verify_final(init_text: str, css_text: str, index_text: str, js_text: str) -> None:
    validate_source(init_text, css_text, index_text, js_text)
    match = VERSION_RE.search(init_text)
    if not match or VERSION not in match.group(0):
        raise ValueError("runtime-versiona ei ole V6.0.9")
    if css_text.count(CSS_START) != 1 or css_text.count(CSS_END) != 1:
        raise ValueError("V6.0.9 CSS-lohko ei esiinny täsmälleen kerran")
    if js_text.count(JS_START) != 1 or js_text.count(JS_END) != 1:
        raise ValueError("V6.0.9 JavaScript-lohko ei esiinny täsmälleen kerran")
    for marker in ("v609-update-steps", "nspire-update-busy", "v609-update-log"):
        if marker not in css_text:
            raise ValueError(f"V6.0.9 CSS-lohko on puutteellinen: {marker}")
    for marker in (
        "Lataa ja päivitä",
        "Päivitys käynnistetty käyttäjän toimesta",
        "nspireV609UpdateLog",
        "new MutationObserver",
        "/api/update/install",
        "MouseEvent('mousemove'",
    ):
        if marker not in js_text:
            raise ValueError(f"V6.0.9 JavaScript-lohko on puutteellinen: {marker}")
    if f'/app.css?v={CACHE_KEY}' not in index_text:
        raise ValueError("index.html ei käytä V6.0.9 CSS-välimuistiavainta")
    if f'/app.js?v={CACHE_KEY}' not in index_text:
        raise ValueError("index.html ei käytä V6.0.9 JavaScript-välimuistiavainta")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=("apply", "verify"))
    parser.add_argument("--init", required=True, type=Path)
    parser.add_argument("--css", required=True, type=Path)
    parser.add_argument("--index", required=True, type=Path)
    parser.add_argument("--js", required=True, type=Path)
    args = parser.parse_args()

    for path in (args.init, args.css, args.index, args.js):
        if not path.is_file():
            raise SystemExit(f"tiedosto puuttuu: {path}")

    init_text = read_text(args.init)
    css_text = read_text(args.css)
    index_text = read_text(args.index)
    js_text = read_text(args.js)

    if args.mode == "apply":
        validate_source(init_text, css_text, index_text, js_text)
        patched = build_patched(init_text, css_text, index_text, js_text)
        verify_final(*patched)
        for path, text in zip((args.init, args.css, args.index, args.js), patched):
            atomic_write(path, text)
        init_text, css_text, index_text, js_text = patched

    verify_final(init_text, css_text, index_text, js_text)
    print("V6.0.9 update-maintenance patch OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
