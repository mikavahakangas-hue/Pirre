# NSPIRE V6.0.9 – päivitysjärjestelmän viimeistely

Tämä päivitys viimeistelee V6-sarjan OTA-päivitysnäkymän muuttamatta työpöydän rakennetta, näyttöä, kosketusta, VNC:tä, verkkoa tai sovellusten sisältöä.

Päivityssivulla asennuspainikkeen nimi on **Lataa ja päivitä**. Asennuksen aikana näytetään vaiheet Ladataan, Tarkistetaan, Asennetaan ja Käynnistetään. Frontend ylläpitää aikaleimattua tapahtumalokia ja näyttää backendin palauttaman virheen mahdollisimman tarkasti. Päivityksen aikana käyttöliittymä lähettää aktiivisuuspulssin, jotta näytönsäästäjä ei katkaise näkyvyyttä kesken asennuksen.

V6.0.8:n työpöydän näkyvyyskorjaus säilytetään muuttumattomana. Kaikki muokattavat tiedostot ja mahdollinen aiempi systemd-pysäytysasetus varmuuskopioidaan ja palautetaan automaattisesti, jos tarkistus epäonnistuu.
