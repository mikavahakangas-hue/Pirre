#!/usr/bin/env bash
set -Eeuo pipefail
ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
MODE="${1:-normal}"
cd "$ROOT"
sha256sum -c SHA256SUMS
bash -n install.sh
python3 -m py_compile payload/apply_patch.py

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

python3 - "$ROOT" "$TMP" <<'PY'
from pathlib import Path
import importlib.util
import sys

root=Path(sys.argv[1]); tmp=Path(sys.argv[2])
spec=importlib.util.spec_from_file_location('patch', root/'payload/apply_patch.py')
mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)

desktop='''/* NSPIRE V6.0.8 DESKTOP VISIBILITY START */
#homeView.is-active { display:block !important; }
#homeView.is-active .home-heading { display:flex !important; }
#homeView.is-active .app-grid { display:grid !important; }
#homeView.is-active .app-tile { display:flex !important; }
.view:not(.is-active) { display:none !important; }
/* NSPIRE V6.0.8 DESKTOP VISIBILITY END */
'''
base_css='''body { color:white; }\n.view { display:none; }\n.view-home { overflow:auto; }\n.app-grid { display:grid; }\n.app-tile { display:flex; }\n''' + desktop
index='''<!doctype html><html><head><link rel="stylesheet" href="/app.css?v=608"></head><body><main id="homeView" class="view view-home is-active"><section class="app-grid">''' + ''.join('<button class="app-tile"></button>' for _ in range(10)) + '''</section></main><main id="detailView"><section id="viewContent"></section></main><script src="/app.js?v=608"></script></body></html>'''
js='''function showHome(){ document.getElementById("homeView").classList.add("is-active"); }\nvar homeView=document.getElementById("homeView");\nvar viewContent=document.getElementById("viewContent");\nfetch("/api/update");\n'''
init='__version__ = "6.0.8"\n'

patched=mod.build_patched(init,base_css,index,js)
mod.verify_final(*patched)
# Idempotence: second transform is byte-identical.
patched2=mod.build_patched(*patched)
assert patched == patched2
assert patched[1].count(mod.DESKTOP_START) == 1
assert patched[1].count(mod.CSS_START) == 1
assert patched[3].count(mod.JS_START) == 1
(tmp/'app.js').write_text(patched[3], encoding='utf-8')
(tmp/'app.css').write_text(patched[1], encoding='utf-8')
(tmp/'index.html').write_text(patched[2], encoding='utf-8')
print('V6.0.9 PATCH IDEMPOTENCE OK')
PY

node --check "$TMP/app.js"

grep -q 'Lataa ja päivitä' "$TMP/app.js"
grep -q 'MouseEvent' "$TMP/app.js"
grep -q 'nspireV609UpdateLog' "$TMP/app.js"
grep -q '/app.css?v=609' "$TMP/index.html"
grep -q '/app.js?v=609' "$TMP/index.html"

make_fixture(){
  local target="$1"
  mkdir -p "$target/live/nspire" "$target/live/static" "$target/systemd" "$target/bin" "$target/state" "$target/backups"
  cat > "$target/live/nspire/__init__.py" <<'EOF'
__version__ = "6.0.8"
EOF
  cat > "$target/live/static/app.css" <<'EOF'
body { color:white; }
.view { display:none; }
.view-home { overflow:auto; }
.app-grid { display:grid; }
.app-tile { display:flex; }
/* NSPIRE V6.0.8 DESKTOP VISIBILITY START */
#homeView.is-active { display:block !important; }
#homeView.is-active .home-heading { display:flex !important; }
#homeView.is-active .app-grid { display:grid !important; }
#homeView.is-active .app-tile { display:flex !important; }
.view:not(.is-active) { display:none !important; }
/* NSPIRE V6.0.8 DESKTOP VISIBILITY END */
EOF
  {
    printf '%s' '<!doctype html><html><head><link rel="stylesheet" href="/app.css?v=608"></head><body><main id="homeView" class="view view-home is-active"><section class="app-grid">'
    for _ in $(seq 1 10); do printf '%s' '<button class="app-tile"></button>'; done
    printf '%s\n' '</section></main><main id="detailView"><section id="viewContent"></section></main><script src="/app.js?v=608"></script></body></html>'
  } > "$target/live/static/index.html"
  cat > "$target/live/static/app.js" <<'EOF'
function showHome(){ document.getElementById("homeView").classList.add("is-active"); }
var homeView=document.getElementById("homeView");
var viewContent=document.getElementById("viewContent");
fetch("/api/update");
EOF
  printf 'inactive\n' > "$target/state/nspire-v6.service"
  printf 'inactive\n' > "$target/state/nspire-kiosk.service"
  cat > "$target/bin/systemctl" <<'EOF'
#!/usr/bin/env bash
set -eu
state="${FAKE_SYSTEMCTL_STATE:?}"
cmd="${1:-}"; shift || true
unit="${*: -1}"
case "$cmd" in
  is-active)
    [ "$(cat "$state/$unit" 2>/dev/null || echo inactive)" = active ]
    ;;
  start)
    printf 'active\n' > "$state/$unit"
    ;;
  stop|kill)
    printf 'inactive\n' > "$state/$unit"
    ;;
  daemon-reload|reset-failed)
    :
    ;;
  *)
    :
    ;;
esac
EOF
  chmod +x "$target/bin/systemctl"
  cat > "$target/bin/curl" <<'EOF'
#!/usr/bin/env bash
set -eu
url="${*: -1}"
live="${FAKE_NSPIRE_LIVE:?}"
case "$url" in
  *'/api/health')
    version="$(sed -n 's/^__version__ = "\([^"]*\)"/\1/p' "$live/nspire/__init__.py")"
    printf '{"ok":true,"version":"%s"}\n' "$version"
    ;;
  *'/app.css'*) cat "$live/static/app.css" ;;
  *'/app.js'*)
    if [ "${FAIL_FRONTEND:-0}" = 1 ]; then exit 22; fi
    cat "$live/static/app.js"
    ;;
  *'127.0.0.1:8765/'*) cat "$live/static/index.html" ;;
  *) printf '{}\n' ;;
esac
EOF
  chmod +x "$target/bin/curl"
}

run_mock_install(){
  local target="$1" fail="${2:-0}"
  FAKE_SYSTEMCTL_STATE="$target/state" \
  FAKE_NSPIRE_LIVE="$target/live" \
  FAIL_FRONTEND="$fail" \
  NSPIRE_LIVE="$target/live" \
  NSPIRE_SYSTEMD_ROOT="$target/systemd" \
  NSPIRE_BACKUP_ROOT="$target/backups" \
  NSPIRE_LOG="$target/update.log" \
  SYSTEMCTL="$target/bin/systemctl" \
  CURL="$target/bin/curl" \
  SLEEP=/bin/true \
  NSPIRE_STABILITY_LOOPS=1 \
  NSPIRE_STABILITY_DELAY=0 \
  "$ROOT/install.sh"
}

if [[ "$MODE" != "rollback" ]]; then
  GOOD="$TMP/good"
  make_fixture "$GOOD"
  run_mock_install "$GOOD"
  grep -q '__version__ = "6.0.9"' "$GOOD/live/nspire/__init__.py"
  [ "$(grep -c 'NSPIRE V6.0.9 UPDATE UX START' "$GOOD/live/static/app.css")" -eq 1 ]
  [ "$(grep -c 'NSPIRE V6.0.9 UPDATE UX START' "$GOOD/live/static/app.js")" -eq 1 ]
  grep -q 'TimeoutStopSec=8s' "$GOOD/systemd/nspire-kiosk.service.d/60-v609-update-stop.conf"
  node --check "$GOOD/live/static/app.js"
  echo 'V6.0.9 MOCK INSTALL OK'
  echo 'V6.0.9 PACKAGE SELFTEST OK'
  exit 0
fi

BAD="$TMP/bad"
make_fixture "$BAD"
sha256sum "$BAD/live/nspire/__init__.py" "$BAD/live/static/app.css" "$BAD/live/static/index.html" "$BAD/live/static/app.js" > "$BAD/before"
if run_mock_install "$BAD" 1; then
  echo 'Pakotettu virhe ei pysäyttänyt asennusta' >&2
  exit 1
fi
sha256sum -c "$BAD/before"
[ ! -e "$BAD/systemd/nspire-kiosk.service.d/60-v609-update-stop.conf" ]
grep -q 'Palautus valmis' "$BAD/update.log"
echo 'V6.0.9 FORCED FAILURE ROLLBACK OK'

echo 'V6.0.9 ROLLBACK SELFTEST OK'
