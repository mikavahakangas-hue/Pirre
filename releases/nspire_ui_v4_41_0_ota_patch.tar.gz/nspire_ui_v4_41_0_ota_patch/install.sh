#!/usr/bin/env bash
set -Eeuo pipefail
PKG="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VERSION="$(tr -d '[:space:]' < "$PKG/VERSION")"
[[ "$VERSION" == "4.41.0" ]] || { echo "VIRHE: väärä versio: $VERSION" >&2; exit 1; }
cd "$PKG"
sha256sum -c --quiet SHA256SUMS
python3 -m py_compile "$PKG/patch.py"
bash -n "$PKG/install.sh"
[[ -s "$PKG/theme-v441.css" ]] || { echo "VIRHE: teemakartta puuttuu" >&2; exit 1; }
if [[ "${NSPIRE_PREFLIGHT_ONLY:-0}" == "1" ]]; then echo "V4.41.0 esitarkistus OK"; exit 0; fi

ROOT="${NSPIRE_OTA_TEST_ROOT:-}"
STATIC="$ROOT/opt/nspire-ui/static"
V4="$STATIC/v4"
APPDIR="$ROOT/opt/nspire-v4"
BACKUP_ROOT="$ROOT/root/nspire-backup"
BACKUP="$BACKUP_ROOT/ota_before_4_41_0_$(date +%F-%H%M%S)-$$"

if [[ -z "$ROOT" && "${EUID:-$(id -u)}" -ne 0 ]]; then exec sudo -E bash "$0"; fi
for f in "$STATIC/index.html" "$V4/app.js" "$V4/app.css" "$APPDIR/nspire_v4_api.py"; do [[ -f "$f" ]] || { echo "VIRHE: puuttuu $f" >&2; exit 1; }; done
mkdir -p "$BACKUP"
cp -a "$STATIC/index.html" "$BACKUP/index.html"
cp -a "$V4/app.js" "$BACKUP/app.js"
cp -a "$V4/app.css" "$BACKUP/app.css"
cp -a "$APPDIR/nspire_v4_api.py" "$BACKUP/nspire_v4_api.py"
printf '%s\n' "$BACKUP" > "$BACKUP_ROOT/ui_v4_last_backup.txt"
rollback(){ rc=$?; if [[ $rc -ne 0 ]]; then
  echo "VIRHE: V4.41.0 epäonnistui, palautetaan V4.40.1" >&2
  cp -a "$BACKUP/index.html" "$STATIC/index.html" || true
  cp -a "$BACKUP/app.js" "$V4/app.js" || true
  cp -a "$BACKUP/app.css" "$V4/app.css" || true
  cp -a "$BACKUP/nspire_v4_api.py" "$APPDIR/nspire_v4_api.py" || true
  if [[ -z "$ROOT" ]]; then systemctl restart nspire-v4.service || true; systemctl restart kiosk-cog.service || true; fi
fi; exit "$rc"; }
trap rollback ERR
python3 "$PKG/patch.py" "$STATIC/index.html" "$V4/app.js" "$V4/app.css" "$APPDIR/nspire_v4_api.py" "$PKG/theme-v441.css"
python3 -m py_compile "$APPDIR/nspire_v4_api.py"
if command -v node >/dev/null 2>&1; then node --check "$V4/app.js"; fi
grep -q '<title>NSPIRE V4.41.0</title>' "$STATIC/index.html"
grep -q "APP_VERSION='4.41.0'" "$V4/app.js"
grep -q 'APP_VERSION = "4.41.0"' "$APPDIR/nspire_v4_api.py"
grep -q 'data-theme="win-light"' "$V4/app.css"
if [[ -z "$ROOT" ]]; then
  systemctl restart nspire-v4.service
  ok=0
  for _ in $(seq 1 40); do
    if python3 - <<'PY' >/dev/null 2>&1
import json,urllib.request
with urllib.request.urlopen('http://127.0.0.1:8093/health',timeout=2) as r: d=json.load(r)
assert d.get('ok') and d.get('version')=='4.41.0'
PY
    then ok=1; break; fi
    sleep .5
  done
  [[ "$ok" == 1 ]] || { echo "VIRHE: backend ei käynnistynyt" >&2; exit 1; }
  systemctl restart kiosk-cog.service
fi
trap - ERR
echo "V4.41.0 teemapäivitys asennettu"
