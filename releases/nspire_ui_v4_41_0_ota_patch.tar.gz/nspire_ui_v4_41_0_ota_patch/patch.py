#!/usr/bin/env python3
from pathlib import Path
import sys

index_p, js_p, css_p, api_p, theme_p = map(Path, sys.argv[1:])
index=index_p.read_text(encoding='utf-8')
js=js_p.read_text(encoding='utf-8')
css=css_p.read_text(encoding='utf-8')
api=api_p.read_text(encoding='utf-8')
theme=theme_p.read_text(encoding='utf-8')

# Require the known-good installed base; allow safe re-run only when already complete.
if "APP_VERSION='4.41.0'" in js and 'data-theme="win-light"' in css:
    print('V4.41.0 on jo asennettu')
    raise SystemExit(0)
if "APP_VERSION='4.40.1'" not in js or 'APP_VERSION = "4.40.1"' not in api:
    raise SystemExit('VIRHE: päivitys vaatii toimivan V4.40.1-pohjan')

index=index.replace('V4.40.1','V4.41.0').replace('v=4.40.1','v=4.41.0')
index=index.replace('data-theme="redline"','data-theme="win-dark"')
js=js.replace("APP_VERSION='4.40.1'","APP_VERSION='4.41.0'",1)
entry="  {version:'4.41.0',date:'14.07.2026',title:'Windows-henkinen värikarttajärjestelmä ja vaaleat teemat',items:['Teemat käyttävät erillisiä tausta-, pinta-, teksti-, reuna-, korostus-, info-, onnistumis-, varoitus- ja virhevärejä.','Mukana neljä tummaa ja neljä oikeasti vaaleaa teemaa.','Päätekstit ja suuret arvot pysyvät neutraaleina; teemaväri korostaa vain aktiivisia kohteita.','SOHVA 2.1 käyttää semanttisia lämpötila-, kosteus- ja akkuvärejä.']},\n"
needle='var RELEASES=[\n'
if entry not in js:
    if needle not in js: raise SystemExit('VIRHE: RELEASES-rakenne puuttuu')
    js=js.replace(needle,needle+entry,1)
start="theme:[{label:'Redline',value:'redline'}"
i=js.find(start); j=js.find('],gemini_model:',i)
if i<0 or j<0: raise SystemExit('VIRHE: vanhaa teemaluetteloa ei löytynyt')
choices="theme:[{label:'Windows Dark Blue',value:'win-dark'},{label:'Graphite',value:'graphite'},{label:'Forest',value:'forest-ui'},{label:'Warm Dark',value:'warm-dark'},{label:'Windows Light',value:'win-light'},{label:'Warm Light',value:'warm-light'},{label:'Cool Light',value:'cool-light'},{label:'High Contrast Light',value:'contrast-light'}]"
js=js[:i]+choices+js[j+1:]
mi=js.find('var THEME_SWATCHES='); me=js.find(';\nfunction renderThemeSwatches',mi)
if mi<0 or me<0: raise SystemExit('VIRHE: teemojen esikatselurakenne puuttuu')
newmap="var THEME_SWATCHES={'win-dark':['#202020','#2b2b2b','#60a5fa'],graphite:['#18191b','#27282b','#a7b0bd'],'forest-ui':['#101714','#1b2821','#4cc38a'],'warm-dark':['#1b1510','#2b2119','#e9a25f'],'win-light':['#f3f3f3','#ffffff','#0067c0'],'warm-light':['#f7f1e8','#fffaf2','#b85c00'],'cool-light':['#edf4f8','#ffffff','#0078d4'],'contrast-light':['#ffffff','#ffffff','#0000cc']}"
js=js[:mi]+newmap+js[me:]
oldinfo='Käyttöliittymä käyttää puhdasta mustaa taustaa. Teema vaihtaa vain korostus- ja reunavärit, jotta pieni näyttö pysyy selkeänä.'
newinfo='Jokainen teema käyttää omaa Windows-tyylistä värikarttaa: neutraalit taustat ja tekstit sekä erilliset korostus-, info-, onnistumis-, varoitus- ja virhevärit. Vaaleat teemat vaihtavat pinnat ja tekstikontrastin oikeasti vaaleiksi.'
if oldinfo not in js: raise SystemExit('VIRHE: vanhaa teemakuvausta ei löytynyt')
js=js.replace(oldinfo,newinfo,1).replace("config.theme||'redline'","config.theme||'win-dark'")

api=api.replace('APP_VERSION = "4.40.1"','APP_VERSION = "4.41.0"',1)
api=api.replace('Nspire V4.40.1 API','Nspire V4.41.0 API')
api=api.replace('"theme": "redline"','"theme": "win-dark"')
old_validator='config["theme"] = choice(config.get("theme"), {"redline", "cyan", "amber", "green", "oled", "ultraviolet", "ice", "copper", "titanium", "cyberglass", "ember", "auroragreen", "violetpulse", "midnight", "nebularose", "solargold", "arcticglass", "matrixrain", "obsidian", "hologram", "sunset", "mintglass", "royal", "monored"}, "redline")'
new_validator='config["theme"] = choice(config.get("theme"), {"win-dark", "graphite", "forest-ui", "warm-dark", "win-light", "warm-light", "cool-light", "contrast-light"}, "win-dark")'
if old_validator not in api: raise SystemExit('VIRHE: backendin teemavalidaattoria ei löytynyt')
api=api.replace(old_validator,new_validator,1)
marker='/* NSPIRE UI V4.41.0 — Windows-henkinen semanttinen värikarttajärjestelmä */'
if marker in css: css=css.split(marker,1)[0].rstrip()+"\n\n"
css+=theme.rstrip()+"\n"

index_p.write_text(index,encoding='utf-8')
js_p.write_text(js,encoding='utf-8')
css_p.write_text(css,encoding='utf-8')
api_p.write_text(api,encoding='utf-8')
print('V4.41.0 tiedostot päivitetty')
