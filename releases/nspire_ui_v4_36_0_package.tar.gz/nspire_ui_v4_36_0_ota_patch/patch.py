#!/usr/bin/env python3
from __future__ import annotations
import os, tempfile
from pathlib import Path

ROOT=Path(os.environ.get('NSPIRE_ROOT','/'))
UI=ROOT/'opt/nspire-ui/static'
V4=ROOT/'opt/nspire-v4'

def atomic_write(path:Path,text:str,mode:int|None=None)->None:
    fd,tmp=tempfile.mkstemp(prefix=path.name+'.',dir=str(path.parent))
    try:
        with os.fdopen(fd,'w',encoding='utf-8',newline='') as f:
            f.write(text); f.flush(); os.fsync(f.fileno())
        if mode is not None: os.chmod(tmp,mode)
        os.replace(tmp,path)
    finally:
        try: os.unlink(tmp)
        except FileNotFoundError: pass

def replace_once(text:str,old:str,new:str,label:str)->str:
    count=text.count(old)
    if count!=1: raise RuntimeError(f'{label}: odotettiin 1 osumaa, löytyi {count}')
    return text.replace(old,new,1)

index=UI/'index.html'; app=UI/'v4/app.js'; css=UI/'v4/app.css'; api=V4/'nspire_v4_api.py'
for p in (index,app,css,api):
    if not p.is_file(): raise RuntimeError(f'puuttuva asennustiedosto: {p}')

app_text=app.read_text(encoding='utf-8')
if "var APP_VERSION='4.36.0'" in app_text and 'function otaStateInfo(ota)' in app_text:
    print('V4.36.0 on jo asennettu')
    raise SystemExit(0)
if "var APP_VERSION='4.35.0'" not in app_text:
    raise RuntimeError('OTA-paikkaus vaatii NSPIRE V4.35.0:n')

# index.html version and cache-busting tags
idx=index.read_text(encoding='utf-8')
idx=idx.replace('4.35.0','4.36.0')

# Frontend release entry and update UI.
s=app_text
s=replace_once(s,"var APP_VERSION='4.35.0';","var APP_VERSION='4.36.0';",'frontend-versio')
old="var RELEASES=[\n  {version:'4.35.0',date:'13.07.2026',title:'AI-keskus, projektit, näppäimistöprofiilit ja OTA-päivityspohja'"
new="var RELEASES=[\n  {version:'4.36.0',date:'13.07.2026',title:'Selkeä pilvipäivityksen tila ja näkyvä manifestiosoite',items:['Päivitykset-välilehden yläosassa näkyy nyt suuri vihreä AJANTASALLA-, keltainen PÄIVITYS SAATAVILLA- tai punainen VIRHE-ilmoitus.','Päivitysmanifestin tekstikenttä on siirretty oman laatikkonsa alaosaan ja osoite näkyy kokonaan usealle riville taitettuna.','Julkinen Pirre-päivityskanava on oletuksena valmiina ja aiempi tyhjä manifestiasetus korjataan automaattisesti.','Päivitysten avaaminen tarkistaa pilvikanavan automaattisesti ja näyttää tarkistusajan.','Tallenna päivityskanava -painike tarkistaa osoitteen heti tallennuksen jälkeen.']},\n  {version:'4.35.0',date:'13.07.2026',title:'AI-keskus, projektit, näppäimistöprofiilit ja OTA-päivityspohja'"
s=replace_once(s,old,new,'julkaisutiedot')
helpers=r'''function otaStateInfo(ota){
  ota=ota||{};
  if(ota.error||ota.ok===false)return{label:'VIRHE',detail:ota.error||'Päivityskanavaa ei voitu tarkistaa',klass:'bad'};
  if(!ota.checked_ts)return{label:'EI TARKISTETTU',detail:'Pilvikanavaa ei ole vielä tarkistettu',klass:'neutral'};
  if(ota.newer)return{label:'PÄIVITYS SAATAVILLA',detail:'Versio V'+String(ota.available_version||'?')+' voidaan ladata',klass:'warn'};
  return{label:'AJANTASALLA',detail:'Asennettu V'+String(ota.current_version||APP_VERSION)+' on uusin versio',klass:'good'};
}
function otaCheckedText(ts){if(!ts)return'ei vielä';try{return new Date(Number(ts)*1000).toLocaleString('fi-FI',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'})}catch(e){return'--'}}
function otaHeroHtml(){var ota=(maintenanceData||{}).ota||{},state=otaStateInfo(ota);return '<section class="ota-hero '+state.klass+'"><div><span>PILVIPÄIVITYKSEN TILA</span><strong>'+esc(state.label)+'</strong><small>'+esc(state.detail)+'</small></div><aside><b>V'+esc(ota.current_version||APP_VERSION)+'</b><small>Tarkistettu '+esc(otaCheckedText(ota.checked_ts))+'</small></aside></section>'}
function updateManifestEditorHtml(){var url=String(config.update_manifest_url||'https://raw.githubusercontent.com/mikavahakangas-hue/Pirre/main/update-manifest.json');return '<section class="update-manifest-card"><div><strong>Päivitysmanifesti</strong><small>HTTPS-osoite update-manifest.json-tiedostoon. Osoite näkyy alla kokonaan.</small></div><textarea class="text-input update-manifest-input" data-config-input="update_manifest_url" rows="3" spellcheck="false" autocomplete="off">'+esc(url)+'</textarea><code class="update-manifest-preview">'+esc(url)+'</code></section>'}
'''
s=replace_once(s,'function maintenanceHtml(){',helpers+'function maintenanceHtml(){','päivitys-UI-apurit')
old="html+='<div class=\"settings-section-title\">PILVIPÄIVITYS</div><div class=\"ota-card '+maintenanceStateClass(ota.newer,ota.ok)+'\"><div><span>ASENNETTU</span><b>V'+esc(ota.current_version||APP_VERSION)+'</b></div><div><span>SAATAVILLA</span><b>'+(ota.available_version?'V'+esc(ota.available_version):(ota.manifest_url?'EI TIETOA':'KANAVA PUUTTUU'))+'</b></div><div><span>TILA</span><b>'+esc(ota.error||((ota.downloaded_path?'LADATTU':(ota.newer?'PÄIVITYS SAATAVILLA':'AJANTASALLA'))))+'</b></div></div>';"
new="var otaInfo=otaStateInfo(ota);html+='<div class=\"settings-section-title\">PILVIPÄIVITYS</div><div class=\"ota-card '+otaInfo.klass+'\"><div><span>ASENNETTU</span><b>V'+esc(ota.current_version||APP_VERSION)+'</b></div><div><span>SAATAVILLA</span><b>'+(ota.available_version?'V'+esc(ota.available_version):(ota.manifest_url?'EI TIETOA':'KANAVA PUUTTUU'))+'</b></div><div><span>TILA</span><b>'+esc(ota.downloaded_path?'LADATTU':otaInfo.label)+'</b></div></div>';"
s=replace_once(s,old,new,'pilvipäivityskortti')
old="function otaCheck(){text('settingsStatus','tarkistetaan pilvestä…');return post('/update/check',{}).then(function(r){maintenanceData.ota=r;renderSettings();toast(r.newer?'Uusi versio V'+r.available_version:'Päivityksiä ei löytynyt')}).catch(function(e){toast('Päivitys: '+e.message)})}"
new="function refreshUpdatesPanel(){return refreshMaintenance().then(function(){if(currentView==='settings'&&settingsTab==='updates'&&String(config.update_manifest_url||'').trim())return otaCheck(true);return (maintenanceData||{}).ota||{}})}\nfunction otaCheck(silent){if(!silent)text('settingsStatus','tarkistetaan pilvestä…');return post('/update/check',{}).then(function(r){maintenanceData.ota=r;renderSettings();if(!silent)toast(r.newer?'Uusi versio V'+r.available_version:'AJANTASALLA · V'+(r.current_version||APP_VERSION));return r}).catch(function(e){maintenanceData.ota={ok:false,error:e.message,current_version:APP_VERSION,manifest_url:config.update_manifest_url||''};renderSettings();if(!silent)toast('Päivitys: '+e.message);return maintenanceData.ota})}"
s=replace_once(s,old,new,'pilvitarkistus')
old="function saveUpdateChannel(){var input=q('[data-config-input=\"update_manifest_url\"]');saveConfigPatch({update_manifest_url:(input&&input.value||'').trim()}).then(refreshMaintenance)}"
new="function saveUpdateChannel(){var input=q('[data-config-input=\"update_manifest_url\"]');saveConfigPatch({update_manifest_url:(input&&input.value||'').trim()}).then(function(){return refreshMaintenance()}).then(function(){return otaCheck(false)})}"
s=replace_once(s,old,new,'kanavan tallennus')
old="  }else if(settingsTab==='updates'){\n    html+=settingRow('Päivitysmanifesti','HTTPS-osoite update-manifest.json-tiedostoon. Tyhjänä käytetään vain paikallisia paketteja.',inputControl('update_manifest_url',config.update_manifest_url||'','text'));"
new="  }else if(settingsTab==='updates'){\n    html+=otaHeroHtml();\n    html+=updateManifestEditorHtml();"
s=replace_once(s,old,new,'päivitys-välilehti')
s=replace_once(s,'Ensimmäinen OTA-versio asennetaan vielä SSH:lla. Sen jälkeen laite voi ladata ja asentaa tulevat paketit suoraan tästä näkymästä.','Pirren julkinen päivityskanava on valmiina. TARKISTA PILVESTÄ näyttää heti, onko laite ajan tasalla tai onko uusi versio saatavilla.','ohjeteksti')
s=replace_once(s,"if(name==='settings'&&settingsTab==='updates')refreshMaintenance();","if(name==='settings'&&settingsTab==='updates')refreshUpdatesPanel();",'näkymän automaattitarkistus')
s=replace_once(s,"if(tab){settingsTab=tab.dataset.settingsTab;renderSettings();if(settingsTab==='updates')refreshMaintenance();if(settingsTab==='network')refreshWifi(true);return}","if(tab){settingsTab=tab.dataset.settingsTab;renderSettings();if(settingsTab==='updates')refreshUpdatesPanel();if(settingsTab==='network')refreshWifi(true);return}",'välilehden automaattitarkistus')

# CSS appended once.
css_text=css.read_text(encoding='utf-8')
# Keep version comments in sync with the complete V4.36.0 package.
css_text=css_text.replace('/* NSPIRE UI V4.35.0 — AI-keskus, projektit, historia ja säädettävä näppäimistö */','/* NSPIRE UI V4.36.0 — AI-keskus, projektit, historia ja säädettävä näppäimistö */')
css_text=css_text.replace('/* V4.35.0: näppäimistö omaksi ruudukon riviksi, jotta lähetyspainike ei jää sen alle. */','/* V4.36.0: näppäimistö omaksi ruudukon riviksi, jotta lähetyspainike ei jää sen alle. */')
css_text=css_text.replace('/* V4.35.0: kaikki kahdeksan AI-keskuksen valintaa mahtuvat 640x480-ruudulle. */','/* V4.36.0: kaikki kahdeksan AI-keskuksen valintaa mahtuvat 640x480-ruudulle. */')
marker='/* V4.36.0: päivitystila on heti näkyvä ja manifestiosoite mahtuu kokonaan. */'
if marker not in css_text:
    css_text += r'''

/* V4.36.0: päivitystila on heti näkyvä ja manifestiosoite mahtuu kokonaan. */
.ota-hero{display:grid;grid-template-columns:minmax(0,1fr) 92px;gap:8px;align-items:center;min-height:74px;margin:0 0 7px;padding:9px 11px;border:2px solid var(--line);border-radius:13px;background:linear-gradient(145deg,var(--surface2),var(--surface));box-shadow:inset 0 1px rgba(255,255,255,.05)}
.ota-hero>div span{display:block;font-size:7px;font-weight:950;letter-spacing:.13em;color:var(--muted)}.ota-hero strong{display:block;margin-top:2px;font-size:19px;line-height:1;color:var(--text)}.ota-hero small{display:block;margin-top:5px;font-size:8px;line-height:1.25;color:var(--muted)}
.ota-hero aside{text-align:right;border-left:1px solid var(--line);padding-left:8px}.ota-hero aside b{display:block;font-size:13px}.ota-hero aside small{font-size:7px}
.ota-hero.good{border-color:var(--good);box-shadow:inset 4px 0 var(--good),0 0 15px color-mix(in srgb,var(--good) 20%,transparent)}.ota-hero.good strong{color:var(--good)}
.ota-hero.warn{border-color:var(--warn);box-shadow:inset 4px 0 var(--warn),0 0 15px color-mix(in srgb,var(--warn) 18%,transparent)}.ota-hero.warn strong{color:var(--warn);font-size:16px}
.ota-hero.bad{border-color:var(--bad);box-shadow:inset 4px 0 var(--bad),0 0 15px color-mix(in srgb,var(--bad) 18%,transparent)}.ota-hero.bad strong{color:var(--bad)}
.ota-hero.neutral strong{color:var(--accent2);font-size:16px}
.update-manifest-card{display:grid;grid-template-columns:minmax(0,1fr);gap:6px;margin-bottom:7px;padding:8px 9px;border:1px solid color-mix(in srgb,var(--line) 70%,transparent);border-radius:11px;background:linear-gradient(145deg,rgba(9,24,36,.86),rgba(3,11,18,.86))}
.update-manifest-card strong{display:block;font-size:12px}.update-manifest-card small{display:block;margin-top:3px;font-size:8px;line-height:1.25;color:var(--muted)}
.update-manifest-input{display:block;min-height:55px;height:55px;padding:7px;resize:none;overflow:hidden;white-space:pre-wrap;overflow-wrap:anywhere;word-break:break-all;font-size:8px;line-height:1.35;font-family:ui-monospace,SFMono-Regular,Consolas,monospace;font-weight:700}
.update-manifest-preview{display:block;max-width:100%;padding:6px 7px;border:1px dashed var(--line);border-radius:7px;background:#020506;color:var(--accent2);font-size:7px;line-height:1.35;white-space:normal;overflow-wrap:anywhere;word-break:break-all}
.ota-card.good>div{border-color:var(--good)}.ota-card.warn>div{border-color:var(--warn)}.ota-card.bad>div{border-color:var(--bad)}
'''

# Backend public channel and migration.
a=api.read_text(encoding='utf-8')
a=replace_once(a,'APP_VERSION = "4.35.0"','APP_VERSION = "4.36.0"\nPUBLIC_UPDATE_MANIFEST = "https://raw.githubusercontent.com/mikavahakangas-hue/Pirre/main/update-manifest.json"','backend-versio')
a=replace_once(a,'    "update_manifest_url": "",','    "update_manifest_url": PUBLIC_UPDATE_MANIFEST,','manifestin oletus')
old='''            if legacy_saver_off:\n                config["screensaver_enabled"] = False\n                config["screensaver_delay_s"] = 60\n    except Exception:\n        pass\n    return config\n'''
new='''            if legacy_saver_off:\n                config["screensaver_enabled"] = False\n                config["screensaver_delay_s"] = 60\n    except Exception:\n        pass\n    # V4.36: public Pirre channel is the safe default and also repairs an\n    # earlier empty value without overwriting a custom URL.\n    if not str(config.get("update_manifest_url") or "").strip():\n        config["update_manifest_url"] = PUBLIC_UPDATE_MANIFEST\n    return config\n'''
a=replace_once(a,old,new,'manifestin migraatio')
a=a.replace('Nspire V4.35.0 API listening','Nspire V4.36.0 API listening')

atomic_write(index,idx,0o644)
atomic_write(app,s,0o644)
atomic_write(css,css_text,0o644)
atomic_write(api,a,0o755)
print('NSPIRE V4.36.0 tiedostot paikattu')
