#!/usr/bin/env bash
set -euo pipefail
PKG="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VERSION="$(tr -d '[:space:]' < "$PKG/VERSION")"
fail(){ printf 'VIRHE: %s\n' "$*"; exit 1; }
[[ "$VERSION" == "4.36.0" ]] || fail "versionumero"
(cd "$PKG" && sha256sum -c --quiet SHA256SUMS) || fail "tarkistussummat"
python3 -m py_compile "$PKG/patch.py" || fail "paikkausskriptin tarkistus"
if [[ "${NSPIRE_PREFLIGHT_ONLY:-0}" == "1" ]]; then printf 'NSPIRE V%s OTA PREFLIGHT OK\n' "$VERSION"; exit 0; fi
[[ "$(id -u)" -eq 0 ]] || fail "asennus vaatii root-oikeudet"
[[ -x /usr/local/sbin/nspire-v4-system ]] || fail "NSPIRE-järjestelmäapuri puuttuu"
/usr/local/sbin/nspire-v4-system backup-create || fail "varmuuskopiointi"
python3 "$PKG/patch.py"
python3 -m py_compile /opt/nspire-v4/nspire_v4_api.py || fail "backend"
if command -v node >/dev/null 2>&1; then node --check /opt/nspire-ui/static/v4/app.js >/dev/null || fail "frontend"; fi
systemctl restart nspire-v4.service
for _ in $(seq 1 30); do curl -fsS --max-time 2 http://127.0.0.1:8093/health 2>/dev/null | grep -q '4.36.0' && break; sleep 1; done
curl -fsS --max-time 3 http://127.0.0.1:8093/health | grep -q '4.36.0' || fail "API ei käynnistynyt"
systemctl restart kiosk-cog.service >/dev/null 2>&1 || systemctl restart kiosk-cog >/dev/null 2>&1 || true
printf 'NSPIRE V%s OTA INSTALL OK\n' "$VERSION"
