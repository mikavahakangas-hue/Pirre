"""NSPIRE V6 clean runtime."""
__version__ = "6.0.4"
