# NSPIRE V6.0.4 OTA-varmistus

Minimaalinen päivitys V6.0.3:n päälle. Se päivittää vain runtime-version ja testaa laitteen suoran OTA-ketjun muuttamatta käyttöliittymää, näytönsäästäjää, VNC:tä, näyttöä, kosketusta tai palvelurakennetta.
