#!/usr/bin/env bash
set -euo pipefail
PKG="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
(cd "$PKG" && sha256sum -c --quiet SHA256SUMS)
COMMIT='1b885abd037db13f547941d4140e52b4c9af10f9'
BASE="https://raw.githubusercontent.com/mikavahakangas-hue/Pirre/${COMMIT}"
TMP="$(mktemp -d -t pirre-v438-fetch-XXXXXX)"
trap 'rm -rf "$TMP"' EXIT
fetch(){
  local name="$1"
  if command -v curl >/dev/null 2>&1; then
    curl -fsSL --retry 3 --connect-timeout 15 "$BASE/$name" -o "$TMP/$name"
  elif command -v wget >/dev/null 2>&1; then
    wget -q --tries=3 --timeout=20 -O "$TMP/$name" "$BASE/$name"
  else
    echo 'VIRHE: curl tai wget puuttuu' >&2
    exit 1
  fi
}
files=(VERSION install.sh SHA256SUMS payload.b64.part00 payload.b64.part01 payload.b64.part02 payload.b64.part03_00 payload.b64.part03_01 payload.b64.part03_02 payload.b64.part03_03 payload.b64.part04_00 payload.b64.part04_01 payload.b64.part04_02)
for f in "${files[@]}"; do fetch "$f"; done
(cd "$TMP" && sha256sum -c --quiet SHA256SUMS)
chmod +x "$TMP/install.sh"
exec bash "$TMP/install.sh"
